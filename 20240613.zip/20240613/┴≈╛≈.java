package 용사키우기;

interface 직업 {
	
}
