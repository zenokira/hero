package 용사키우기;

public interface 상태이상 {
	void 독상태가됨();
}
