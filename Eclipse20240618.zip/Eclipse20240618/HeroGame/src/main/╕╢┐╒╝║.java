package main;

public class 마왕성 {

}
