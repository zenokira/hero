package main;

public class 아이템 {
	protected String name;
	protected 시스템.아이템종류 type;
	protected int count;

	
	public 아이템()
	{
		
	}
	public 아이템(String n, 시스템.아이템종류 type, int count)
	{
		this.name = n;
		this.type = type;
		this.count = count;
	}
	
	public 아이템 getItem()
	{
		return this;
	}
	
	public 시스템.아이템종류 getTypeID()
	{
		return type;
	}
	
	public void setTypeID(시스템.아이템종류 id)
	{
		type = id;
	}
	
	public String getName() {
		return this.name;
	}
	
	public void setName(String str) {
		this.name = str;
	}
	
	public int getCount() {
		return this.count;
	}
	public void setCount(int c) {
		this.count = c;
	}
	
	public void changeCount(int c) {
		this.count += c;
	}
	
	public void 아이템수량변경(int c)
	{
		this.count += c;
	}
	
	public boolean 소비아이템여부()
	{
		if( type == 시스템.아이템종류.소비)	return true;
		else				return false;
	}
	
	public boolean 사용가능여부(아이템 item)
	{
		시스템.아이템종류 id = item.getTypeID();
		if ( id == 시스템.아이템종류.소비 || id == 시스템.아이템종류.포션 )
			return true;
		else 
			return false;
	}
	public boolean 사용가능여부()
	{
		if ( type == 시스템.아이템종류.소비 || type == 시스템.아이템종류.포션)
			return true;
		else 
			return false;
	}
	
	public boolean 포션아이템인지여부(아이템 item)
	{
		if (item.getTypeID() == 시스템.아이템종류.포션) 
			return true;
		else 
			return false;
	}
	
	public boolean 포션아이템인지여부()
	{
		if (type == 시스템.아이템종류.포션) 
			return true;
		else 
			return false;
	}
	
	public void 아이템사용하기()
	{
		아이템수량변경(-1);
	}
	
	public void 아이템정보보이기() {
		System.out.println("\n아이템 이름 : " + name + "\t\t보유수량 : " + count );
	}
	

	
	@Override
	public String toString()
	{
		return this.name;
	}

}