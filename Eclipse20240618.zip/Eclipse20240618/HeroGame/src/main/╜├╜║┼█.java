package main;

import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

public class 시스템 {
	시스템() {
		strEtcList[0] = "고구마씨앗"; 	strEtcList[1] = "싹이난감자";
		strEtcList[2] = "슬라임의방울";	strEtcList[3] = "토끼가죽";
		strEtcList[4] = "여우의송곳니";
		
		
		strEquipList[0] = "단검";		strEquipList[1] = "롱소드";
		strEquipList[2] = "레이피어";	strEquipList[3] = "방패";
		strEquipList[4] = "갑옷";
		
		strConsumList[0] = "숫돌";	strConsumList[1] = "물";
		strConsumList[2] = "감자";	strConsumList[3] = "해독제";
		strConsumList[4] = "육포";
		
		strPotionList[0] = "하급힐링포션"; strPotionList[1] = "하급마나포션";
		strPotionList[2] = "중급힐링포션";	strPotionList[3] = "중급마나포션";
		strPotionList[4] = "활력포션";
		

	}
	static enum 포션종류 { 힐링,마나,활력 }
	static enum 아이템종류 { 기타, 장비,소비, 포션 }
	private static Random rand = new Random();
	private static final int typeIdx = 4;
	private static final int itemIdx = 5;
	private static String[] strEtcList = new String[itemIdx];
	private static String[] strEquipList = new String[itemIdx];
	private static String[] strConsumList = new String[itemIdx];
	private static String[] strPotionList = new String[itemIdx];
	

	
	private static Scanner sc = new Scanner(System.in);

	public static String getInputString() {
		String str = "";
		try {
			str = sc.nextLine();
		} catch (InputMismatchException e) {
			System.out.println("문자를 입력해주세요");
		}
		return str;
	}

	public static int getInputInt() {
		int n = -1;
		try {
			n = sc.nextInt();
		} catch (InputMismatchException e) {
			System.out.println("숫자를 입력해주세요");
		}
		sc.nextLine();
		return n;
	}

	public static int getRandInt(int n) {
		return rand.nextInt(n);
	}
	
	
	public static 아이템 랜덤아이템생성() {
		아이템 item ;
		int type_id = getRandInt(typeIdx);

		if (type_id == 아이템종류.기타.ordinal()) {
			item = 기타아이템생성하기();
		}
		else if (type_id == 아이템종류.장비.ordinal()) {
			item = 장비아이템생성하기();
		}
		else if (type_id == 아이템종류.소비.ordinal()) {
			item = 소비아이템생성하기();
		}
		else {
			item = 포션아이템생성하기();
		}
		/*
		 * if (strItemList[id].contains("포션")) { type = strItemType[3]; count =
		 * rand.nextInt(3) + 1;
		 * 
		 * if (strItemList[id].equals("힐링포션")) { Item.setHP(30); type_id = 2; } else if
		 * (strItemList[id].equals("마나포션")) { Item.setMP(30); type_id = 3; } }
		 */
		
		return item;
	}

	/*
	 * 기타아이템 기타아이템생성하기() {
	 * 
	 * } 장비아이템 장비아이템생성하기() {
	 * 
	 * } 소비아이템 소비아이템생성하기() {
	 * 
	 * }
	 */
	
	public static 기타아이템 기타아이템생성하기() {
		int nidx = getRandInt(itemIdx);
		아이템종류 type_id = 아이템종류.기타; // 0 기타, 1 장비, 2 소비, 3 포션
		int count = getRandInt(3) + 1;

		기타아이템 item =
				new 기타아이템	(strPotionList[nidx], type_id, count);
		
		return item;
	}
	public static 장비아이템 장비아이템생성하기() {
		int nidx = getRandInt(itemIdx);
		아이템종류 type_id = 아이템종류.장비; // 0 기타, 1 장비, 2 소비, 3 포션
		int count = getRandInt(3) + 1;
		
		
		장비아이템 item =
				new 장비아이템	(strEquipList[nidx], type_id, count);
		
		return item;
	}
	public static 소비아이템 소비아이템생성하기() {
		int nidx = getRandInt(itemIdx);
		아이템종류 type_id = 아이템종류.소비; // 0 기타, 1 장비, 2 소비, 3 포션
		int count = getRandInt(3) + 1;
		
		소비아이템 item =
				new 소비아이템	(strConsumList[nidx], type_id, count);
		
		return item;
	}
	public static 포션아이템 포션아이템생성하기() {
		int nidx = getRandInt(itemIdx);
		아이템종류 type_id = 아이템종류.포션; // 0 기타, 1 장비, 2 소비, 3 포션
		int count = getRandInt(3) + 1;
		int type_po = getRandInt(3) + 1;
		int recovery = 30 * (nidx % 2 + 1);
		
		
		포션아이템 item =
				new 포션아이템	(strPotionList[nidx], type_id, count,type_po, recovery);
		
		return item;
	}

	public static int getItemidx() {
		return itemIdx;
	}

}