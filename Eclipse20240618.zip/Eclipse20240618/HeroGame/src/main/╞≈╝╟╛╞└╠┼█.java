package main;

public class 포션아이템 extends 아이템 {
	private int recovery;
	private int potion_type;
	
	public 포션아이템()
	{
		
	}
		
	public 포션아이템(String n, 시스템.아이템종류 type_id, int count, int type_po, int recovery)
	{
		super(n,type_id,count);
		this.recovery = recovery;
		this.potion_type = type_po;
	}
}
