package main;

public abstract class 사람 {
	protected String name;
	protected 스탯 status;
	protected 소지품 inv;
	
	public String getName() { return name; }
}
