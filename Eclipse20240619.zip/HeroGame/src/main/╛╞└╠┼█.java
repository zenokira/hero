package main;

public class 아이템 {
	private String name;
	private 시스템.아이템종류 type;
		

	// ===== 포션 변수 ===== //
	private int recovery;
	private int potion_type;
	// =================== //
	
	// ===== 소비 변수 ===== //
	// =================== //
	
	
	// ===== 장비 변수 ===== //
	// =================== //
	
	// ===== 기타 변수 ===== //
	// =================== //
	
	public 아이템()
	{
		
	}
	public 아이템(String n, 시스템.아이템종류 type)
	{
		this.name = n;
		this.type = type;
	}
	
	public 아이템(String n, 시스템.아이템종류 type, int type_po, int recovery)
	{
		this.name = n;
		this.type = type;
		this.potion_type = type_po;
		this.recovery = recovery;
	}
	
	
	public 아이템 getItem()
	{
		return this;
	}
	
	public 시스템.아이템종류 getTypeID()
	{
		return type;
	}
	
	public void setTypeID(시스템.아이템종류 id)
	{
		type = id;
	}
	
	public String getName() {
		return this.name;
	}
	
	public void setName(String str) {
		this.name = str;
	}
	
	public boolean 소비아이템여부()
	{
		if( type == 시스템.아이템종류.소비)	return true;
		else				return false;
	}
	
	public boolean 사용가능여부(아이템 item)
	{
		시스템.아이템종류 id = item.getTypeID();
		if ( id == 시스템.아이템종류.소비 || id == 시스템.아이템종류.포션 )
			return true;
		else 
			return false;
	}
	public boolean 사용가능여부()
	{
		if ( type == 시스템.아이템종류.소비 || type == 시스템.아이템종류.포션)
			return true;
		else 
			return false;
	}
	
	public boolean 포션아이템인지여부(아이템 item)
	{
		if (item.getTypeID() == 시스템.아이템종류.포션) 
			return true;
		else 
			return false;
	}
	
	public boolean 포션아이템인지여부()
	{
		if (type == 시스템.아이템종류.포션) 
			return true;
		else 
			return false;
	}
	
	public void 보유아이템정보보이기(int n) {
		System.out.println("\n아이템 이름 : " + name + "\t보유수량 : " + n );
	}
	
	public void 아이템정보보이기(int n) {
		System.out.println("\n아이템 이름 : " + name + "\t수량 : " + n );
	}
	
	
	// ======= 포션 ======= //
	public 아이템(int type_po, int recovery)
	{
		this.recovery = recovery;
		this.potion_type = type_po;
	}
	
	public void 포션아이템사용하기(스탯 status)
	{
		status.아이템사용으로회복하기(recovery, potion_type);
	}
	// =================== //
	
	
	
	// ======= 소비 ======= //
	// =================== //
	
	
	// ======= 장비 ======= //
	// =================== //
	
	// ======= 기타 ======= //
	// =================== //
	@Override
	public String toString()
	{
		return this.name;
	}

}