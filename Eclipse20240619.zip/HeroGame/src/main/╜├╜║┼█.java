package main;

import java.util.InputMismatchException;
import java.util.Vector;
import java.util.Random;
import java.util.Scanner;

public class 시스템 {
	
	시스템() {

	}
	
	static enum 포션종류 { 힐링,마나,활력 }
	static enum 아이템종류 { 기타, 장비,소비, 포션 }
	private static Random rand = new Random();
	private static final int typeIdx = 4;
	private static final int itemIdx = 5;
	private static String[] strEtcList = {"고구마씨앗","싹이난감자","슬라임의방울","토끼가죽","여우의송곳니"};
	private static String[] strEquipList = {"단검","롱소드","레이피어","방패","갑옷"};
	private static String[] strConsumList = {"숫돌","물","감자","해독제","육포"};
	private static String[] strPotionList = {"하급힐링포션","하급마나포션","중급힐링포션","중급마나포션","활력포션"};
	

	
	private static Scanner sc = new Scanner(System.in);

	public static String getInputString() {
		String str = "";
		try {
			str = sc.nextLine();
		} catch (InputMismatchException e) {
			System.out.println("문자를 입력해주세요");
		}
		return str;
	}

	public static int getInputInt() {
		int n = -1;
		try {
			n = sc.nextInt();
		} catch (InputMismatchException e) {
			System.out.println("숫자를 입력해주세요");
		}
		sc.nextLine();
		return n;
	}

	public static int getRandInt(int n) {
		return rand.nextInt(n);
	}
	
	
	public static 아이템 랜덤아이템생성() {
		아이템 item ;
		int type_id = getRandInt(typeIdx);

		if (type_id == 아이템종류.기타.ordinal()) {
			item = 기타아이템생성하기();
		}
		else if (type_id == 아이템종류.장비.ordinal()) {
			item = 장비아이템생성하기();
		}
		else if (type_id == 아이템종류.소비.ordinal()) {
			item = 소비아이템생성하기();
		}
		else {
			item = 포션아이템생성하기();
		}
		/*
		 * if (strItemList[id].contains("포션")) { type = strItemType[3]; count =
		 * rand.nextInt(3) + 1;
		 * 
		 * if (strItemList[id].equals("힐링포션")) { Item.setHP(30); type_id = 2; } else if
		 * (strItemList[id].equals("마나포션")) { Item.setMP(30); type_id = 3; } }
		 */
		
		return item;
	}

	/*
	 * 기타아이템 기타아이템생성하기() {
	 * 
	 * } 장비아이템 장비아이템생성하기() {
	 * 
	 * } 소비아이템 소비아이템생성하기() {
	 * 
	 * }
	 */
	
	public static 아이템 기타아이템생성하기() {
		int nidx = getRandInt(itemIdx);
		아이템종류 type_id = 아이템종류.기타; // 0 기타, 1 장비, 2 소비, 3 포션
		int count = getRandInt(3) + 1;

		아이템 item =	new 아이템(strEtcList[nidx], type_id);
		
		return item;
	}
	public static 아이템 장비아이템생성하기() {
		int nidx = getRandInt(itemIdx);
		아이템종류 type_id = 아이템종류.장비; // 0 기타, 1 장비, 2 소비, 3 포션
		int count = getRandInt(3) + 1;
		
		
		아이템 item =	new 아이템(strEquipList[nidx], type_id);
		
		return item;
	}
	public static 아이템 소비아이템생성하기() {
		int nidx = getRandInt(itemIdx);
		아이템종류 type_id = 아이템종류.소비; // 0 기타, 1 장비, 2 소비, 3 포션
		int count = getRandInt(3) + 1;
		
		아이템 item =	new 아이템(strConsumList[nidx], type_id);
		
		return item;
	}
	public static 아이템 포션아이템생성하기() {
		int nidx = getRandInt(itemIdx);
		아이템종류 type_id = 아이템종류.포션; // 0 기타, 1 장비, 2 소비, 3 포션
		int recovery = 30 * (nidx % 2 + 1);
		
		int type_po = (nidx+2) / 2 - 1;
		
		
		아이템 item =
				new 아이템(strPotionList[nidx], type_id, type_po, recovery);
		
		return item;
	}

	public static int 아이템수량생성(아이템 item)
	{
		int r = 5;
		if ( item.getTypeID() == 아이템종류.장비) r = 1;
		else if( item.getTypeID() == 아이템종류.포션 ) r = 3;
		
		int n = getRandInt(r) + 1;
		
		return n;
	}
	
	public static int getItemidx() {
		return itemIdx;
	}

}