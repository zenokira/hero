package main;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Vector;
import java.util.Set;

public class 소지품 {
	private HashMap<아이템, Integer> inv;

	소지품() {
		inv = new HashMap<아이템, Integer>();
	}
	
	void 아이템획득(아이템 item, int n) {
		if (해당아이템보유여부(item))	
		{
			int i = inv.get(item).intValue();
			inv.put(item, i + n);
			
		}
		else
			inv.put(item, n);
		
		System.out.println(item.getName() + "를 " + n + "개 획득했다");
	}

	boolean 아이템보유여부() {
		return !(inv.isEmpty());

	}

	boolean 해당아이템보유여부(아이템 item) {
		
		for (아이템 i : inv.keySet() )
		{
			if (i.getName().equals(item.getName()))	return true;
		}
		return false;	
	}
	
	boolean 해당아이템보유여부(String name)
	{
		for (아이템 item : inv.keySet())
		{
			if(item.getName().equals(name) ) return true;
		}
		return false;
	}

	void showItem() {
		System.out.println();
		System.out.print("---------------<보유중>---------------");
		for (Entry<아이템, Integer> s : inv.entrySet())
			s.getKey().보유아이템정보보이기(s.getValue());
		
		/*
		 * for (아이템 item : inv.keySet()) { item.아이템정보보이기(inv.get(item)); }
		 */
		
		System.out.print("-------------------------------------");
		System.out.println();
	}

	public int 아이템사용하기(String name) {
		/*
		 * 아이템 item = inven.get(name); if (item.사용가능여부()) {
		 * 
		 * } else n = -1;
		 */
		return 0;
	}
	
	public boolean 아이템사용가능여부(String name)
	{
		try {
			아이템 item = getItem(name);
			if(item.사용가능여부()) return true;
		}
		catch(NullPointerException e)
		{
			return false;
		}
		return false;
	}
	
	아이템 getItem(String name)
	{	
		for ( 아이템 item : inv.keySet())
		{
			if(item.getName().equals(name))
			{
				if(item.사용가능여부()) return item;
			}
		}
		return null;
	}
		

	
	
	
	
	
	
	
	
	

}