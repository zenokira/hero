package main;

public class 용사키우기MAIN {
	private 용사 player;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		용사키우기MAIN st = new 용사키우기MAIN();
		st.Start();
	}
	
	void Start() {
//		String name = Intro();
		String name = "용사";
		시스템 s = new 시스템();
		
		
		Initialize(name);
		
		System.out.println(player.getName() + "의 모험을 시작합니다.");
				
		while ( true )
		{
			boolean flag = player.용사의선택();
			
			if (flag == true)
			{
				player.이벤트발생(시스템.getRandInt(4));
				System.out.print("목적지에 도착했다. \n\n다음 행동을 ");
			}
			else
			{
				System.out.println(player.getName() +" 이 정비를 마쳤습니다");
			}

		}
	}
	
	void Initialize(String name)
	{
		player = new 용사(name);
	}
	
	String Intro()
	{
		System.out.println("-마왕군과 대치중이던 용사가 단말마의 비명을 질렀다-");
		sleep(2000);
		System.out.println("-그와 함께 마왕 한마디 말을 내뱉으며 쓰러졌다-");
		sleep(2000);
		System.out.println("마왕 : I will be back");
		sleep(2000);
		System.out.println("-마왕이 쓰러지자 마왕군은 후퇴했고-");
		sleep(2000);
		System.out.println("-다시금 평화를 되찾았다.-");
		sleep(2000);
		System.out.println("-평화롭게 지내는 500년의 시간이 흐르자 용사는 잊혀져갔다.-");
		sleep(2000);
		System.out.println("-평화가 찾아오고 생산력이 복구되자 지배층의 욕심은 다시 생겨났다");
		sleep(2000);
		System.out.println("-그로인해 다시금 전쟁이 시작되었고 전쟁은 150년간 지속되었고-");
		sleep(2000);
		System.out.println("-마왕군과 전쟁했던 시대만큼 인구가 줄어버렸다.-");
		sleep(2000);
		System.out.println("-심지어 마왕의 부활 필요한 대량의 피가 대지를 적셨고-");
		sleep(2000);
		System.out.println("-마왕의 부활이 임박했다.-");
		sleep(2000);
		System.out.println("--------------------------");
		sleep(2000);	
		System.out.println("용사가 마왕을 물리친지 666년이 지났다.");
		sleep(2000);
		System.out.println("그동안의 거듭된 인간들의 전쟁으로 결국 마왕은 부활했고");
		sleep(2000);
		System.out.println("인간들은 전쟁을 멈추고 마왕군과 대적했다.");
		sleep(2000);
		System.out.println("하지만 너무 많은 사람들이 전쟁으로 죽어버렸고,");
		sleep(2000);
		System.out.println("마왕군과의 전투에서 항상 선두에서 싸우던 용사조차 없었다.");
		sleep(2000);
		System.out.println("불리한 싸움을 거듭하던 그때 수도에 있던 성녀가 신탁을 받았다.");
		sleep(2000);
		System.out.println("'지난번 마왕과 대적했던 용사 역시도 다시 태어났고");
		sleep(2000);
		System.out.println("다시금 그의 각성이 이루어져 인간들을 구원하리라' 라고");
		sleep(2000);
		System.out.println("신탁이 있은 후로부터 2년이 지났다.");
		sleep(2000);
		System.out.println("사람들은 신탁의 용사가 나타나기를 손꼽아 기다렸다.");
		sleep(2000);
		System.out.println("어느날 산골짜기 어느 마을에 하늘에서 강렬한 빛이 내려와 한 사람에게 말을 걸었다-");
		sleep(2000);
		System.out.println("당신의 이름은 무엇인가요? ");
		
		return 시스템.getInputString();
	}
	
	void sleep(int m)
	{
		try {
			Thread.sleep(m);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	void Ending용사의죽음() {
		System.out.println("용사가 죽어 마왕군이 득세합니다");
		System.out.println("-----< The End >-----");
		System.exit(0);
	}

	

}