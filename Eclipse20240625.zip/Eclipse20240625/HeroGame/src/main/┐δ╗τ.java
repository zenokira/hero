package main;

public class 용사 extends 사람 implements 상태이상, 감정표현 {

	용사() {

	}

	용사(String name) {
		this.name = name;
		Initialize();
	}

	public void Initialize() {
		status = new 스탯();
	}

	public 스탯 get스탯() {
		return status;
	}

	void 스탯창보기() {
		status.스탯창보기();
	}

	void 정비시간() {
		System.out.println(getName() + "가 자리에 앉아 정비합니다.");
		System.out.println("정비활동 ( 1. 스탯확인  2. 소지품확인  3. 소지품사용  4. 장비착용 ) : ");
		int c = 시스템.getInputInt();
		switch (c) {
		case 1: // 스탯 확인
			스탯창보기();
			break;
		case 2: // 소지품 확인
			if (아이템소지여부())
				인벤토리보기();
			else
				System.out.println("소지품이 없습니다.");
			break;
		case 3: // 소지품 사용
			if (아이템소지여부())
				아이템사용하기();
			else
				System.out.println("소지품이 없습니다.");
			break;
		case 4: // 장비 착용
			장비착용하기();
			break;
		}
	}

	public boolean 용사의선택() {

		System.out.println("입력해주세요 ( 1. 모험을 계속한다.  2. 정비시간을 갖는다 ) : ");
		int c = 시스템.getInputInt();
		System.out.println();

		if (c == 1) {
			System.out.println("모험을 계속한다.\n");
			sleep(1500);
			return true;
		} else {
			정비시간();
			return false;
		}
	}

	public void 이벤트발생(int event) {

		int e = event;

		if (e == 0)
			마왕성발견();
		else if (e > 40 && e <= 100)
			몬스터발견(); // 몬스터 발견
		else if (e > 20 && e <= 40)
			아이템발견(); // 아이템 발견
		else if (e > 10 && e <= 20)
			마을발견();// 마을 발견
		else if ( e > 0 && e <= 10)
			던전발견();

		if (!용사죽음여부()) {
			System.out.println("다음 행동을 결정해주세요");
		}
	}

	/////////////////////////////////////////////
	////////////// 메인 이벤트 처리 ////////////////
	/////////////////////////////////////////////
	void 아이템발견() {
		int iN = 시스템.랜덤아이템생성();
		int n = 시스템.아이템수량생성(iN);
		아이템을발견해서기쁨();

		sleep(1500);

		아이템 item = 시스템.get샘플아이템(iN);
		item.발견아이템정보보이기(n);

		System.out.println("\n선택해주세요 ( 1. 획득 , 2. 포기 ) : ");
		int choice = 시스템.getInputInt();

		if (choice == 1)
			아이템획득(iN, n);
		else {
			System.out.println("아이템을 포기했다.\n");
		}
	}

	public void 몬스터발견() {
		// TODO Auto-generated method stub
		int type = 시스템.get랜덤몬스터종류();
		int src = 시스템.get랜덤몬스터();
		몬스터 mon = 시스템.get샘플몬스터(type * 시스템.getmtypeIdx() + src);
		mon.몬스터생성();

		몬스터를발견해서놀람(mon);
		sleep(1500);
		mon.스탯창보기();

		System.out.println("\n선택해주세요 ( 1. 싸운다 , 2. 도망간다 ) : ");
		int choice = 시스템.getInputInt();
		System.out.println();
		if (choice == 1) {
			배틀시작(mon);
		} else {
			System.out.println("싸움을 포기하고 도망쳤다.\n");
		}

	}

	void 마을발견() {
		System.out.println("마을을 발견했다!!!");
		System.out.println("\n선택해주세요 ( 1. 휴식을 취한다  2. 그냥 지나간다 ) : ");
		int choice = 시스템.getInputInt();

		if (choice == 1) {
			int r = 시스템.getRandInt(100);

			if (r % 10 == 5)
				온천에서회복한다();
			else
				마을에서회복한다();
		} else {
			System.out.println("\n마을을 그냥 지나쳐다.\n");
		}
	}

	private void 던전발견() {
		// TODO Auto-generated method stub

		int t = 0;
		int idx = 0;
		int choice = 0;

		t = 시스템.getRandInt(시스템.getMonIdx() - 1);
		idx = 시스템.getmtypeIdx();
		
		while (true) {
			System.out.println(시스템.get샘플몬스터(t * idx).getName() + "던전(난이도 : " + (t + 1) + " )을 발견했다.");
			System.out.println("\n*주의* 입장시 포기 할 수 없습니다. (권장레벨 : " + (t * idx + 5) + " )");
			System.out.println("입장여부를 선택해주세요 ( 1. 입장  2. 포기  3. 스탯확인) : ");
			choice = 시스템.getInputInt();

			if (choice == 3)
				스탯창보기();
			else if (choice == 2) {
				System.out.println("던전입장을 포기하셨습니다.\n");
				return;
			}
			else 
				break;
			
		}

		int r = 시스템.getRandInt(8) + 2;
		몬스터[] m = new 몬스터[r];

		for (int i = 0; i < r - 1; i++) {
			if (i % idx != 5)
				m[i] = new 몬스터(시스템.get샘플몬스터(t * idx + i % idx));
			else
				m[i] = new 몬스터(시스템.get샘플몬스터(t * idx + t));
			m[i].몬스터생성();

		}
		m[r - 1] = new 몬스터(시스템.get샘플몬스터(t * 시스템.getMonIdx() + 시스템.getMonIdx() - 1));
		m[r - 1].던전보스몬스터생성();

		int c = 0;
		for (int i = 0; i < r; i++) {
			몬스터를발견해서놀람(m[i]);
//			sleep(1500);
			m[i].스탯창보기();
//			sleep(1500);
			c = 던전배틀시작(m[i]);
			if (용사죽음여부()) break;
		}

		if (c == 3 && !용사죽음여부()) {
			System.out.println("던전을 클리어하였습니다.\n");
		}
	}

	private void 마왕성발견() {
		// TODO Auto-generated method stub

		System.out.println("마왕성을 발견했다.\n");
		sleep(1500);
		System.out.println("*경고* 입장시 도망 갈 수 없습니다.\n");
		sleep(1000);
		System.out.println("도전하시겠습니까? ( 1. 도전한다  2. 포기한다 ) :");
		int c = 시스템.getInputInt();

		if (c == 1) {
			마왕성 BC = new 마왕성();
			System.out.println("마왕성의 문을 열고 들어갔다.\n");
			sleep(1500);

			for (int i = 0; i < BC.getNmonSize(); i++) {
				몬스터 m = BC.getNormal몬스터()[i];
				몬스터를발견해서놀람(m);
//				sleep(1500);
				m.스탯창보기();
//				sleep(1500);
				c = 던전배틀시작(m);
				if (용사죽음여부()) break;
			}
			if (c == 3 && !용사죽음여부()) {
				System.out.println("마왕성 입구의 적을 모두 물리쳤습니다.\n");
				sleep(1500);
				
				while(!용사의선택());
			}
			else return ;
			
			System.out.println("마왕성 오르기 시작했다.\n");
			sleep(1500);

			for (int i = 0; i < BC.getNmonSize(); i++) {
				몬스터 m = BC.getHell몬스터()[i];
				몬스터를발견해서놀람(m);
				sleep(1500);
				m.스탯창보기();
				sleep(1500);
				c = 던전배틀시작(m);
				if (용사죽음여부()) break;
			}
			if (c == 3 && !용사죽음여부()) {
				System.out.println("마왕성 내부의 적을 모두 물리쳤습니다.\n");
				sleep(1500);
				
				while(!용사의선택());
			}
			else return ;
			
			System.out.println("마왕이 등장했다.\n");
			sleep(1500);

			몬스터 m = BC.get보스몬스터();
			m.스탯창보기();
			sleep(1500);
			c = 던전배틀시작(m);
			
			if (c == 3 && !용사죽음여부()) {
				System.out.println("마왕을 물리쳤습니다.\n");
				sleep(1500);
			}
			else return ;
		} else
			System.out.println("마왕성 도전을 포기했다.\n");

	}

	/////////////////////////////////////////////
	/////////////////////////////////////////////
	/////////////////////////////////////////////

	private void 온천에서회복한다() {
		// TODO Auto-generated method stub
		System.out.println("마을에서 온천을 발견했다!!\n");
		sleep(1500);
		System.out.println("휴식을 취한다.... 몸이 회복되고 있다.\n");
		sleep(1500);
		System.out.println("피로가 많이 가시는 것 같다.\n");
		sleep(1500);

		int r = 시스템.getRandInt(100) + 50;
		status.휴식으로회복(r);
	}

	private void 마을에서회복한다() {
		// TODO Auto-generated method stub
		System.out.println("휴식을 취한다.... 몸이 회복되고 있다.\n");
		sleep(1500);
		System.out.println("피로가 조금 가시는 것 같다.\n");
		sleep(1500);

		int r = 시스템.getRandInt(50) + 30;
		status.휴식으로회복(r);
	}

	/////////////////////////////////////////////
	/////////////////// 던전 /////////////////////
	/////////////////////////////////////////////
	int 던전배틀시작(몬스터 mon) {
		int turn = 1;
		int c = 1;
		while (true) {
			if (turn % 2 == 1)
				c = 던전용사턴(mon);
			else
				c = 던전몬스터턴(mon);
			turn++;
			if (c == 3)
				break;
			//sleep(1500);
		}
		return c;
	}

	private int 던전몬스터턴(몬스터 mon) {
		// TODO Auto-generated method stub
		int dmg = mon.몬스터턴(this);

		용사의피격(dmg);

		if (용사죽음여부()) {
			System.out.println(getName() + " 이 쓰러졌습니다. \n<배틀종료>");
			return 3;
		}

		return 1;

	}

	int 던전용사턴(몬스터 mon) {
		용사의공격(mon);
		if (mon.몬스터죽음여부()) {
			System.out.println(mon.getName() + " 이(가) 쓰러졌습니다.");
			status.레벨업여부(mon);
			System.out.println("\n<배틀종료>\n");

			return 3; // 몬스터가 죽음
		}
		return 1; // 싸움중
	}

	int 배틀시작(몬스터 mon) {

		int turn = 1;
		int c = 3;
		boolean flag = true;

		while (flag) {
			if (turn % 2 == 1)
				c = 용사턴(mon);
			else
				c = 몬스터턴(mon);
			if (c == 2 || c == 3)
				flag = false;
			turn++;
		}
		return c;
	}

	int 용사턴(몬스터 mon) {
		System.out.println("선택해주세요 ( 1. 공격 , 2. 도망 ) : ");
		int choice = 시스템.getInputInt();
		boolean flag = true;
		switch (choice) {
		case 1:
			용사의공격(mon);
			flag = mon.몬스터죽음여부();
			if (flag) {
				System.out.println(mon.getName() + " 이(가) 쓰러졌습니다.");
				status.레벨업여부(mon);
				System.out.println("\n<배틀종료>\n");
				return 3;
			}
			break;
		case 2:
			System.out.println("성공적으로 도망쳤다");
			return 2;

		}
		return 1;
	}

	void 용사의공격(몬스터 mon) {
		int dmg = status.물리데미지계산(mon.get합산물리방어력());
		mon.몬스터의피격(dmg);
	}

	int 몬스터턴(몬스터 mon) {
		int dmg = mon.몬스터턴(this);

		용사의피격(dmg);

		if (용사죽음여부()) {
			System.out.println(getName() + " 이 쓰러졌습니다. \n<배틀종료>");
			return 3;
		}

		return 1;
	}

	void 용사의피격(int dmg) {
		int hp = status.mHP(dmg);

		if (hp < 0)
			status.setHP(0);

		System.out.printf("%s 이(가) %d 의 데미지를 받았습니다.  ", getName(), dmg);
		System.out.printf("%s ( %d / %d )\n\n", getName(), status.getHP(), status.getMaxHP());
	}

	boolean 용사죽음여부() {
		if (status.getHP() <= 0)
			return true;
		else
			return false;
	}

	/////////////////////////////////////////////
	/////////////////////////////////////////////
	/////////////////////////////////////////////

	/////////////////////////////////////////////
	//////////////// 아이템 및 장비//////////////////
	/////////////////////////////////////////////

	void 아이템사용하기() {
		인벤토리보기();
		System.out.println("사용하고자 하는 아이템 이름을 입력해주세요 : ");
		String strName = 시스템.getInputString();

		아이템 item = 시스템.get샘플아이템(strName);

		if (item.사용가능여부()) {
			int iNum = item.getItemNumber();
			int n = get해당아이템개수(iNum);

			if (item.포션아이템인지여부()) {
				item.포션아이템사용하기(status);
			} else {

			}
			아이템개수변경(iNum, -1);
		}
	}

	void 장비착용하기() {
		장비인벤토리보기();
		System.out.println("착용하고자 하는 아이템 이름을 입력해주세요 : ");
		String strName = 시스템.getInputString();

		아이템 item = 시스템.get샘플아이템(strName);

		if (item.장비아이템인지여부()) {
			int iNumNow = item.getItemNumber();
			int nNow = get해당아이템개수(iNumNow);
			int iNumPast = 0;
			int nPast = 0;

			
			if (착용중인장비여부(item.getETypeID())) {
				iNumPast = equip[item.getETypeID().ordinal()];
				아이템 item2 = 시스템.get샘플아이템(iNumPast);
				아이템개수변경(iNumPast, 1);
				status.change장비스탯(item.getETypeID(), -item2.get물리());
			}
			equip[item.getETypeID().ordinal()] = item.getItemNumber();
			아이템개수변경(iNumNow, -1);
			status.change장비스탯(item.getETypeID(), item.get물리());
		}
	}

	boolean 착용중인장비여부(시스템.장비종류 etype) {
		if (equip[etype.ordinal()] != -1)
			return true;
		else
			return false;
	}

	/////////////////////////////////////////////
	/////////////////////////////////////////////
	/////////////////////////////////////////////

	void sleep(int m) {
		try {
			Thread.sleep(m);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void 독상태가됨() {
		// TODO Auto-generated method stub
		System.out.println("독에 당했다!!!");
	}

	@Override
	public void 기쁨() {
		// TODO Auto-generated method stub
		System.out.println("기쁘다");
	}

	public void 아이템을발견해서기쁨() {
		// TODO Auto-generated method stub
		System.out.println("아이템을 발견해서 기쁘다!!\n");
	}

	public void 레벨업기쁨() {
		// TODO Auto-generated method stub
		System.out.println("레벨이 올랐다!!! 기쁘다");
	}

	@Override
	public void 놀람() {
		// TODO Auto-generated method stub
		System.out.println("!!! 놀랐다 !!!");
	}

	public void 몬스터를발견해서놀람(몬스터 mon) {
		// TODO Auto-generated method stub
		System.out.println("갑자기 " + mon.getName() + "이(가) 튀어나왔다!!!");

	}

	@Override
	public void 황당함() {
		// TODO Auto-generated method stub
		System.out.println("??? 황당하다 ???");
	}
}

class 마왕성 extends 몬스터 {
	몬스터[] normal;
	몬스터[] hell;
	몬스터 boss;

	마왕성() {
		init();
	}

	void init() {
		int nR = 시스템.getRandInt(10) + 1;
		int hR = 시스템.getRandInt(10) + 1;

		for (int i = 0; i < nR; i++) {
			int nRsam = 시스템.getRandInt(시스템.get랜덤몬스터종류() * 시스템.getMonIdx());
			normal[i] = new 몬스터(시스템.get샘플몬스터(nRsam));
		}
		for (int i = 0; i < hR; i++) {
			int hRsam = 시스템.getRandInt(시스템.get랜덤몬스터());
			normal[i] = new 몬스터(시스템.get샘플몬스터(시스템.getmlistIdx() - 시스템.getMonIdx() + hRsam));
		}

		boss = new 몬스터(시스템.get샘플몬스터(시스템.getmlistIdx() - 1));
	}

	public 마왕성 get마왕성() {
		return this;
	}

	public 몬스터[] getNormal몬스터() {
		return normal;
	}

	public 몬스터[] getHell몬스터() {
		return hell;
	}

	public 몬스터 get보스몬스터() {
		return boss;
	}

	public int getNmonSize() {
		return normal.length;
	}

	public int getHmonSize() {
		return hell.length;
	}
	
	public boolean 마왕죽음여부()
	{
		return boss.몬스터죽음여부();
	}
}
