package main;

public class 용사키우기MAIN {
	private 용사 player;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		용사키우기MAIN st = new 용사키우기MAIN();
		st.Start();
	}

	void Start() {
//		String name = Intro();
		String name = "용사";
		시스템 s = new 시스템();

		Initialize(name);

		System.out.println(player.getName() + "의 모험을 시작합니다.");

		while (true) {
			boolean flag = player.용사의선택();

			if (flag == true) {
				player.이벤트발생(시스템.getRandInt(101));
				if (player.용사죽음여부())
					Ending용사의죽음();
			} else {
				System.out.println(player.getName() + " 이 정비를 마쳤습니다");
			}

		}
	}

	void Initialize(String name) {
		player = new 용사(name);
	}

	String Intro() {
		스토리String("마왕군과 대치중이던 용사가 단말마의 비명을 질렀다");
		스토리String("그와 함께 마왕 한마디 말을 내뱉으며 쓰러졌다");
		스토리String("마왕 : I will be back");
		스토리String("마왕이 쓰러지자 마왕군은 후퇴했고");
		스토리String("다시금 평화를 되찾았다.");
		스토리String("평화롭게 지내는 500년의 시간이 흐르자 용사는 잊혀져갔다.");
		스토리String("평화가 찾아오고 생산력이 복구되자 지배층의 욕심은 다시 생겨났다");
		스토리String("그로인해 다시금 전쟁이 시작되었다.");
		스토리String("전쟁은 150년간 지속되었고");
		스토리String("인구는 마왕군과 전쟁했던 시대만큼 줄어버렸다.");
		스토리String("심지어 마왕의 부활 필요한 대량의 피가 대지를 적셨고");
		스토리String("마왕의 부활이 임박해졌다.");
		System.out.println("--------------------------");
		
		스토리String("용사가 마왕을 물리친지 666년이 지났다.");
		스토리String("그동안의 거듭된 인간들의 전쟁으로 피가 필요했던 마왕은 결국 부활했고");
		스토리String("인간들은 전쟁을 멈추고 마왕군과 대적했다.");
		스토리String("하지만 너무 많은 사람들이 전쟁으로 죽어버렸고,");
		스토리String("마왕군과의 전투에서 항상 선두에서 싸우던 용사조차 이제는 없었다.");
		스토리String("불리한 싸움을 거듭하던 그때 수도에 있던 성녀가 신탁을 받았다.");
		스토리String("'지난번 마왕과 대적했던 용사 역시도 다시 태어났고");
		스토리String("다시금 그의 각성이 이루어져 인간들을 구원하리라' 라고");
		System.out.println("--------------------------");
		
		스토리String("신탁이 있은 후로부터 2년이 지났다.");
		스토리String("사람들은 신탁의 용사가 나타나기를 손꼽아 기다렸다.");
		스토리String("이미 포기한 자들도 생겨났다.");
		스토리String("성녀를 욕하는 자들 역시 날이 갈수록 늘어만 갔다.");
		스토리String("절망의 나날이 흐르던 그때 다시금 성녀에게 신탁이 내려왔다.");
		스토리String("'용사는 이미 각성하였고, 스스로 성장해나가고 있다' 라고");
		System.out.println("--------------------------");
		
		
		스토리String("어느 산골짜기 마을에 오크무리가 지나가고");
		스토리String("마을의 모든 것이 부서져버린 그때 하늘에서 강렬한 빛이 내려와");
		스토리String("마을의 유일한 생존자인 당신에게 말을 걸었다");

		System.out.println("당신의 이름은 무엇인가요? ");

		return 시스템.getInputString();
	}

	void sleep(int m) {
		try {
			Thread.sleep(m);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	void Ending용사의죽음() {
		System.out.println("-용사가 죽어 마왕군이 득세합니다-");
		System.out.println("----------< The End >----------");
		System.exit(0);
	}

	void 스토리String(String str) {
		System.out.println("-" + str + "-");
		sleep(2000);
	}

}