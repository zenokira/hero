package main;

public class 용사 extends 사람 implements 상태이상, 감정표현 {

	용사() {

	}

	용사(String name) {
		this.name = name;
		Initialize();
	}

	public void Initialize() {
		status = new 스탯();
	}

	public int 용사의선택() {

		System.out.println("입력해주세요 ( 1. 모험을 계속한다.  2. 정비시간을 갖는다.  3. 마왕성으로 간다. ) : ");
		int c = 시스템.getInputInt();
		System.out.println();

		if (c == 1) {
			System.out.println("모험을 계속한다.\n");
			sleep(1500);
		}
		return c;
	}

	/////////////////////////////////////////////
	////////////// 메인 이벤트 처리 ////////////////
	/////////////////////////////////////////////
	
	public int 아이템발견(아이템 item, int n) {
		
		아이템을발견해서기쁨();
		item.발견아이템정보보이기(n);
		
		System.out.println("\n선택해주세요 ( 1. 획득 , 2. 포기 ) : ");
		int choice = 시스템.getInputInt();

		return choice;
	}

	public int 몬스터발견(몬스터 mon) {
		// TODO Auto-generated method stub
		몬스터를발견해서놀람(mon);
		sleep(1500);
		mon.스탯창보기();

		System.out.println("\n선택해주세요 ( 1. 싸운다 , 2. 도망간다  3. 죽기살기로 싸운다 ) : ");
		int choice = 시스템.getInputInt();
		System.out.println();
	
		return choice;
	}

	public int 마을발견() {
		System.out.println("마을을 발견했다!!!");
		System.out.println("\n선택해주세요 ( 1. 휴식을 취한다  2. 그냥 지나간다 ) : ");
		int choice = 시스템.getInputInt();

		return choice;
	}
	
	public void 온천에서회복한다() {
		// TODO Auto-generated method stub
		System.out.println("마을에서 온천을 발견했다!!\n");
		sleep(1500);
		System.out.println("휴식을 취한다.... 몸이 회복되고 있다.\n");
		sleep(1500);
		System.out.println("피로가 많이 가시는 것 같다.\n");
		sleep(1500);

		int r = 시스템.getRandInt(100) + 50;
		status.휴식으로회복(r);
	}

	public void 마을에서회복한다() {
		// TODO Auto-generated method stub
		System.out.println("휴식을 취한다.... 몸이 회복되고 있다.\n");
		sleep(1500);
		System.out.println("피로가 조금 가시는 것 같다.\n");
		sleep(1500);

		int r = 시스템.getRandInt(50) + 30;
		status.휴식으로회복(r);
	}

	private void 던전발견() {
		// TODO Auto-generated method stub
		int t = 시스템.getRandInt(시스템.getMonIdx() - 1);
		int idx = 시스템.getmtypeIdx();

		while (true) {
			System.out.println(시스템.get샘플몬스터(t * idx).getName() + "던전(난이도 : " + (t + 1) + " )을 발견했다.");
			System.out.println("\n*주의* 입장시 포기 할 수 없습니다. (권장레벨 : " + ((t + 1) * 10) + " )");
			System.out.println("입장여부를 선택해주세요 ( 1. 입장  2. 포기  3. 스탯확인) : ");
			int choice = 시스템.getInputInt();

			if (choice == 3)
				스탯창보기();
			else if (choice == 2) {
				System.out.println("던전입장을 포기하셨습니다.\n");
				return;
			} else
				break;
		}

		int r = 시스템.getRandInt(8) + 2;
		몬스터[] m = new 몬스터[r];

		for (int i = 0; i < r - 1; i++) {
			if (i % idx != 5)
				m[i] = new 몬스터(시스템.get샘플몬스터(t * idx + i % idx));
			else
				m[i] = new 몬스터(시스템.get샘플몬스터(t * idx + t));
			m[i].몬스터생성();

		}
		m[r - 1] = new 몬스터(시스템.get샘플몬스터(t * 시스템.getMonIdx() + 시스템.getMonIdx() - 1));
		m[r - 1].던전보스몬스터생성();

		for (int i = 0; i < r; i++) {
			몬스터를발견해서놀람(m[i]);
			m[i].스탯창보기();
			sleep(1500);
			생사결배틀시작(m[i]);
			if (용사죽음여부())
				break;
		}
	}

	private void 마왕성토벌() {
		// TODO Auto-generated method stub

		System.out.println("마왕성을 발견했다.\n");
		sleep(1500);
		System.out.println("*경고* 입장시 도망 갈 수 없습니다.\n");
		sleep(1000);
		System.out.println("도전하시겠습니까? ( 1. 도전한다  2. 포기한다 ) :");
		int c = 시스템.getInputInt();

		if (c == 1) {
			마왕성 BC = 시스템.get마왕성();
			System.out.println("마왕성의 문을 열고 들어갔다.\n");
			sleep(1500);

			boolean flag = 마왕성전투(BC.getNormal몬스터());

			if ( flag ) while(마왕성중간휴식());
			else return;

			System.out.println("마왕성을 오르기 시작했다.\n");
			sleep(1500);

			flag = 마왕성전투(BC.getHell몬스터());

			if ( flag ) while(마왕성중간휴식());
			else return;
			
			System.out.println("마왕성을 오르기 시작했다.\n");
			sleep(1500);
			System.out.println("마왕의 방 입구의 문을 열었다.\n");
			sleep(1500);
			System.out.println("마왕이 등장했다.\n");
			sleep(1500);

			몬스터 m = BC.get보스몬스터();
			m.스탯창보기();
			sleep(1500);
			생사결배틀시작(m);

			if (!용사죽음여부()) {
				System.out.println("마왕을 물리쳤습니다.\n");
				sleep(1500);
			} 
		} 
		else
		{
			System.out.println("마왕성 도전을 포기했다.\n");
		}
	}

	/////////////////////////////////////////////
	/////////////////////////////////////////////
	/////////////////////////////////////////////



	/////////////////////////////////////////////
	/////////////////// 전투 /////////////////////
	/////////////////////////////////////////////
	public void 피격(int dmg) {
		// TODO Auto-generated method stub
		int n = dmg - status.get합산물리방어력();
		int hp = status.mHP(dmg);
		
		if( hp < 0) status.setHP(0);
				
		System.out.printf("\n%s 가 %d 의 데미지를 입었습니다.  ", getName(), n);
		System.out.printf("%s ( %d / %d )\n",getName(), status.getHP(), status.getMaxHP());
	}

	public int 공격()
	{
		return status.get합산물리공격력();
	}
		
	private void 몬스터처치(몬스터 mon) {
		// TODO Auto-generated method stub
		System.out.println(mon.getName() + " 이(가) 쓰러졌습니다.\n");
		status.changeEXP(mon.getEXP());
		System.out.println("경험치가 " + mon.getEXP() + " 만큼 올랐습니다.");
		if(status.레벨업여부())
		{
			status.레벨업();
			status.스탯창보기();
		}
		System.out.println("\n<배틀종료>\n");
	}

	public int 용사턴() {
		System.out.println("선택해주세요 ( 1. 공격 , 2. 도망 ) : ");
		int choice = 시스템.getInputInt();
	
		return choice;
	}

	/////////////////////////////////////////////
	/////////////////////////////////////////////
	/////////////////////////////////////////////

	/////////////////////////////////////////////
	//////////////// 아이템 및 장비//////////////////
	/////////////////////////////////////////////

	void 아이템사용하기() {
		인벤토리보기();
		System.out.println("사용하고자 하는 아이템 이름을 입력해주세요 : ");
		String strName = 시스템.getInputString();

		아이템 item = 시스템.get샘플아이템(strName);

		if (item.사용가능여부()) {
			int iNum = item.getItemNumber();
			int n = get해당아이템개수(iNum);

			if (item.포션아이템인지여부()) {
				item.포션아이템사용하기(status);
			} else {

			}
			아이템개수변경(iNum, -1);
		}
	}

	void 장비착용하기() {
		장비인벤토리보기();
		System.out.println("착용하고자 하는 아이템 이름을 입력해주세요 : ");
		String strName = 시스템.getInputString();

		아이템 item = 시스템.get샘플아이템(strName);

		if (item.장비아이템인지여부()) {
			int iNumNow = item.getItemNumber();
			int nNow = get해당아이템개수(iNumNow);
			int iNumPast = 0;
			int nPast = 0;

			if (착용중인장비여부(item.getETypeID())) {
				iNumPast = equip[item.getETypeID().ordinal()];
				아이템 item2 = 시스템.get샘플아이템(iNumPast);
				아이템개수변경(iNumPast, 1);
				status.change장비스탯(item.getETypeID(), -item2.get물리());
			}
			equip[item.getETypeID().ordinal()] = item.getItemNumber();
			아이템개수변경(iNumNow, -1);
			status.change장비스탯(item.getETypeID(), item.get물리());
		}
	}

	/////////////////////////////////////////////
	/////////////////////////////////////////////
	/////////////////////////////////////////////
	
	private boolean 마왕성중간휴식() {
		System.out.println("입력해주세요 ( 1. 마왕성 토벌을 계속한다.  2. 정비시간을 갖는다. ) : ");
		int c = 시스템.getInputInt();
		System.out.println();

		if (c == 1) {
			System.out.println("마왕성 토벌을 계속한다.\n");
			sleep(1500);
			return false;
		}
		else if( c == 2){
			정비시간();
			return true;
		}
		return true;
	}
	
	void 정비시간() {
		System.out.println(getName() + "가 자리에 앉아 정비합니다.");
		System.out.println("정비활동 ( 1. 스탯확인  2. 소지품탭  3. 장비탭 ) : ");
		int c = 시스템.getInputInt();
		switch (c) {
		case 1: // 스탯 확인
			스탯창보기();
			break;
		case 2: // 소지품 확인
			아이템탭();
			break;
		case 3: // 장비 착용
			장비탭();
			break;
		}
		System.out.println(getName() + " 이(가) 정비를 마쳤습니다\n");
	}

	void 스탯창보기() {
		status.스탯창보기();
		착용중인장비보기();
	}
	
	private void 아이템탭() {
		System.out.println("사용하고자 하는 기능을 입력해주세요 ( 1. 인벤토리보기  2. 아이템사용하기 ) : ");
		int c = 시스템.getInputInt();

		if (c == 1) {
			if (아이템소지여부())
				인벤토리보기();
			else
				System.out.println("소지품이 없습니다.");
		} else if (c == 2) {

			if (아이템소지여부())
				아이템사용하기();
			else
				System.out.println("소지품이 없습니다.");
		} else
			System.out.println("잘못입력하셨습니다.");
	}

	private void 장비탭() {
		System.out.println("사용하고자 하는 기능을 입력해주세요 ( 1. 착용중인 장비 보기  2. 장비착용하기 ) : ");
		int c = 시스템.getInputInt();

		if (c == 1)
			착용중인장비보기();
		else if (c == 2)
			장비착용하기();
		else
			System.out.println("잘못입력하셨습니다.");
	}

	private void 착용중인장비보기() {
		// TODO Auto-generated method stub

		System.out.println("-------------< 착용 장비 >------------");

		for (int i = 0; i < 6; i++) {

			if (착용중인장비확인(i))
				System.out.print(시스템.장비종류.values()[i] + " : " + 시스템.get샘플아이템(equip[i]).getName() + "\t");
			else
				System.out.print(시스템.장비종류.values()[i] + " : " + "없음\t");

			if (i % 2 == 1)
				System.out.println();
		}
		System.out.println("------------------------------------\n");
	}


	
	/////////////////////////////////////////////
	///////////// getter & setter ///////////////
	/////////////////////////////////////////////

	public 스탯 get스탯() {
		return status;
	}

	
	/////////////////////////////////////////////
	////////////////// check ////////////////////
	/////////////////////////////////////////////
	
	private boolean 착용중인장비확인(int i) {
		if (equip[i] != -1)
			return true;
		else
			return false;
	}

	boolean 용사죽음여부() {
		if (status.getHP() <= 0)
			return true;
		else
			return false;
	}
	
	private boolean 마왕죽음여부() {
		// TODO Auto-generated method stub
		return 시스템.get마왕성().마왕죽음여부();
	}
	
	boolean 착용중인장비여부(시스템.장비종류 etype) {
		if (equip[etype.ordinal()] != -1)
			return true;
		else
			return false;
	}
	
	/////////////////////////////////////////////
	////////////////// 기타 //////////////////////
	/////////////////////////////////////////////
	
	void sleep(int m) {
		try {
			Thread.sleep(m);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
	
	
	
	/////////////////////////////////////////////
	///////////////// 상태이상 ////////////////////
	/////////////////////////////////////////////
	
	
	@Override
	public void 독상태가됨() {
		// TODO Auto-generated method stub
		System.out.println("독에 당했다!!!");
	}

	@Override
	public void 기쁨() {
		// TODO Auto-generated method stub
		System.out.println("기쁘다");
	}

	public void 아이템을발견해서기쁨() {
		// TODO Auto-generated method stub
		System.out.println("아이템을 발견해서 기쁘다!!\n");
		sleep(1500);
	}

	public void 레벨업기쁨() {
		// TODO Auto-generated method stub
		System.out.println("레벨이 올랐다!!! 기쁘다");
		sleep(1500);
	}

	@Override
	public void 놀람() {
		// TODO Auto-generated method stub
		System.out.println("!!! 놀랐다 !!!");
	}

	public void 몬스터를발견해서놀람(몬스터 mon) {
		// TODO Auto-generated method stub
		System.out.println("갑자기 " + mon.getName() + " 이(가) 튀어나왔다!!!");
//		sleep(1500);
	}

	@Override
	public void 황당함() {
		// TODO Auto-generated method stub
		System.out.println("??? 황당하다 ???");
	}


	
	
	
/*	
	public void cheet(int n)
	{
		status.레벨업(n);
	}
*/
	
}


