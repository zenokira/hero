package main;

public class 직업 {

}
