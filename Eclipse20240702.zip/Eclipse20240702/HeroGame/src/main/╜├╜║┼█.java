package main;

import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

public class 시스템 {

	시스템() {
		init();
	}

	////////////////////////////////////////////////////////////////
	///////////////////////// 아이템 관련 /////////////////////////////
	////////////////////////////////////////////////////////////////
	static enum 포션종류 {
		힐링, 마나, 활력
	}

	static enum 직업종류 {
		일반, 검사, 마법사, 마검사
	}

	static enum 장비종류 {
		무기, 갑옷, 투구, 장갑, 방패, 망토
	}

	static enum 아이템종류 {
		기타, 장비, 소비, 포션
	}

	private static final int itemtypeIdx = 4;
	private static final int itemIdx = 6;
	private static final int itemlistIdx = itemtypeIdx * itemIdx;
	private static String[][] strItemList = { 
			{ "토끼가죽", "여우의송곳니", "슬라임의방울", "고블린의누더기천조각", "오크의피", "마왕의뿔" },
			{ "롱소드", "나무스태프", "가죽갑옷", "가죽방패", "가죽투구", "가죽장갑" },
			{ "숫돌", "물", "감자", "해독제", "육포", "폭죽" },
			{ "하급힐링포션", "하급마나포션", "중급힐링포션", "중급마나포션", "하급활력포션", "중급활력포션" } };

	private static 아이템[] itemArr = new 아이템[itemlistIdx];
	//////////////////////////////////////////////////////////////////

	//////////////////////////////////////////////////////////////////
	///////////////////////// 몬스터 관련 ///////////////////////////////
	//////////////////////////////////////////////////////////////////
	private static final int monIdx = 6;
	private static final int montypeIdx = 6;
	private static final int monlistIdx = monIdx * montypeIdx;
	private String[][] strMonlist = { 
			{ "토끼", 	"산토끼"	, 	"숲토끼",		"사막토끼", 	"눈토끼", 	"토깽이" },
			{ "여우", 	"갈색여우", 	"사막여우",	"눈여우" ,	 "불여우",	"구미호" }, 
			{ "슬라임", "블루슬라임"	,	"브라운슬라임",	"레드슬라임", "늪슬라임", 	"버블링" },
			{ "고블린",	"어린고블린", "늙은고블린", 	"고블린궁수","고블린전사"	, 	"킹고블린" }, 
			{ "오크",  "어린오크",	 	"늙은오크",	"오크전사", 	"오크광전사", 	"오크왕"},
			{ "마족토끼", "마족여우", 	"마족슬라임", 	"마족고블린",	"마족오크", 	"마왕" } };

	private static 몬스터[] monArr = new 몬스터[monlistIdx];

	//////////////////////////////////////////////////////////////////

	
	//////////////////////////////////////////////////////////////////
	////////////////////////// 스킬 관련 ///////////////////////////////
	//////////////////////////////////////////////////////////////////
	
	private static String[][] strSkillList = { 
			{ "강타", "마구휘두르기"},
			{ "섬광찌르기", "오러베기"},
			{ "매직에로우", "파이어볼"}
	};
	private static final int skillIdx = 2;
	private static final int skilltypeIdx = 3;
	private static final int skilllistIdx = skillIdx * skilltypeIdx;
	private static 스킬[] skillArr = new 스킬[skilllistIdx];
	
	//////////////////////////////////////////////////////////////////
	//////////////////////////////////////////////////////////////////
	//////////////////////////////////////////////////////////////////
	
	
	
	
	
	
	
	
	
	private static Scanner sc = new Scanner(System.in);
	private static Random rand = new Random();

	
	private static 마왕성 devil;
	
	void init() {
		int i = 0;
		init기타아이템설정(i++);
		init장비아이템설정(i++);
		init소비아이템설정(i++);
		init포션아이템설정(i++);

		init몬스터설정();
		init스킬설정();
		devil = new 마왕성();
	}

	////////////////////////////////////////////////////////
	/////////////////////// 시스템 //////////////////////////
	////////////////////////////////////////////////////////
	
	public static String getInputString() {
		String str = "";
		try {
			str = sc.nextLine();
		} catch (InputMismatchException e) {
			System.out.println("문자를 입력해주세요");
		}
		return str;
	}

	public static int getInputInt() {
		int n = -1;
		try {
			n = sc.nextInt();
		} catch (InputMismatchException e) {
			System.out.println("숫자를 입력해주세요");
		}
		sc.nextLine();
		return n;
	}

	public static int getRandInt(int n) {
		return rand.nextInt(n);
	}

	public static boolean isNumber(String strValue) {
	    return strValue != null && strValue.matches("[-+]?\\d*\\.?\\d+");
	}

	////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////

	////////////////////////////////////////////////////////
	/////////////////////// 아이템 //////////////////////////
	////////////////////////////////////////////////////////

	void init기타아이템설정(int n) {
		for (int x = 0; x < itemIdx; x++) {
			itemArr[n * itemIdx + x] = new 아이템(strItemList[n][x], 아이템종류.values()[n], n * itemIdx + x);
			//itemArr[n * itemIdx + x].기타아이템설정();
		}
	}

	void init장비아이템설정(int n) {
		int pDmg, mDmg;
		int ac, mr;

		pDmg = mDmg = ac = mr = 0;

		for (int x = 0; x < itemIdx; x++) {
			itemArr[n * itemIdx + x] = new 아이템(strItemList[n][x], 아이템종류.values()[n], n * itemIdx + x);
		}

		itemArr[n * itemIdx + 0].장비아이템설정(시스템.장비종류.무기, 7, 0);
		itemArr[n * itemIdx + 1].장비아이템설정(시스템.장비종류.무기, 2, 7);
		itemArr[n * itemIdx + 2].장비아이템설정(시스템.장비종류.갑옷, 9, 0);
		itemArr[n * itemIdx + 3].장비아이템설정(시스템.장비종류.방패, 2, 2);
		itemArr[n * itemIdx + 4].장비아이템설정(시스템.장비종류.투구, 2, 2);
		itemArr[n * itemIdx + 5].장비아이템설정(시스템.장비종류.장갑, 2, 2);
		
		itemArr[n * itemIdx + 0].set직업제한(직업종류.일반);
		itemArr[n * itemIdx + 1].set직업제한(직업종류.마법사);
		itemArr[n * itemIdx + 2].set직업제한(직업종류.일반);
		itemArr[n * itemIdx + 3].set직업제한(직업종류.일반);
		itemArr[n * itemIdx + 4].set직업제한(직업종류.일반);
		itemArr[n * itemIdx + 5].set직업제한(직업종류.일반);
	}

	void init소비아이템설정(int n) {
		for (int x = 0; x < itemIdx; x++) {
			itemArr[n * itemIdx + x] = new 아이템(strItemList[n][x], 아이템종류.values()[n], n * itemIdx + x);
			itemArr[x].소비아이템설정();
		}
	}

	void init포션아이템설정(int n) {
		for (int x = 0; x < itemIdx; x++) {
			시스템.포션종류 ptype = 시스템.포션종류.values()[x % 2];
			int rec = 30 * ((x % 2) + 1);
			itemArr[n * itemIdx + x] = new 아이템(strItemList[n][x], 아이템종류.values()[n], n * itemIdx + x);
			if (x >= 4)
				ptype = 시스템.포션종류.활력;
			itemArr[n * itemIdx + x].포션아이템설정(ptype, rec);
		}
	}

	public static int 랜덤아이템생성() {
		int n = getRandInt(itemlistIdx);
		return n;
	}

	public static int 아이템수량생성(int iN) {
		int i = iN / itemIdx;
		int r = 5;
		if (i == 아이템종류.장비.ordinal())
			r = 1;
		else if (i == 아이템종류.포션.ordinal())
			r = 3;

		int n = getRandInt(r) + 1;

		return n;
	}

	public static int getilistIdx() {
		return itemlistIdx;
	}

	public static 아이템 get샘플아이템(int n) {
		return itemArr[n];
	}

	public static 아이템 get샘플아이템(String str) {
		int n = 0;
		for (; n < itemlistIdx; n++)
			if (str.equals(strItemList[n / itemIdx][n % itemIdx]))
				break;

		return itemArr[n];
	}

	public static int getItemIdx() {
		return itemIdx;
	}

	////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////

	////////////////////////////////////////////////////////
	/////////////////////// 몬스터 //////////////////////////
	///////////////////////////////////////////////////////

	public static int getmlistIdx() {
		return monlistIdx;
	}

	public static int getMonIdx() {
		return monIdx;
	}
	
	public static int getmtypeIdx() {
		return montypeIdx;
	}

	public static 몬스터 get샘플몬스터(int n) {
		return new 몬스터(monArr[n]);
	}

	public static int get랜덤몬스터종류() {
		return 시스템.getRandInt(montypeIdx - 1);
	}

	public static int get랜덤몬스터() {
		return 시스템.getRandInt(monIdx-1);
	}

	private void init몬스터설정() {
		// TODO Auto-generated method stub
		for (int i = 0; i < monlistIdx; i++) {
			int lv = i+1;
			double exp = 50;
			if ( i % monIdx == 5) {lv = i + 3; exp = 350;}
			monArr[i] = new 몬스터(strMonlist[i / monIdx][i % monIdx], i, lv, exp );
			monArr[i].setItem(itemArr[i % montypeIdx]);
		}
	}

	////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////


	////////////////////////////////////////////////////////
	///////////////////////// 스킬 //////////////////////////
	////////////////////////////////////////////////////////

	void init스킬설정() {
		for (int x = 0; x < getSkilllistIdx(); x++) {
			skillArr[x] = new 스킬(strSkillList[x/getSkillIdx()][x%getSkillIdx()],
					x,
					((x % getSkillIdx())+1) * 10,
					((x % getSkillIdx())+1) * 5, 
					시스템.직업종류.values()[x/getSkillIdx()]);
		}
	}
	
	public static 스킬 스킬이름으로_스킬구하기(String name)
	{
		for (스킬 s : skillArr)
		{
			if (s.get스킬이름().equals(name)) return s;
		}
		return null;
	}
	
	
	////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////
	
	////////////////////////////////////////////////////////
	//////////////////////// 마왕성 /////////////////////////
	////////////////////////////////////////////////////////
	
	public static 마왕성 get마왕성() { return devil; }

	public static int getSkillIdx() {
		return skillIdx;
	}

	public static int getSkilltypeIdx() {
		return skilltypeIdx;
	}

	public static int getSkilllistIdx() {
		return skilllistIdx;
	}
	
	public static 스킬 get샘플스킬(int n) {
		return skillArr[n];
	}
		
	////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////
}








class 마왕성 extends 몬스터 {
	몬스터[] normal;
	몬스터[] hell;
	몬스터 boss;
	
	마왕성(마왕성 devil)
	{
		normal = devil.getNormal몬스터();
		hell = devil.getHell몬스터();
		boss = devil.getBoss몬스터();
	}

	마왕성() {
		init();
	}

	void init() {
		int nR = 시스템.getRandInt(10) + 1;
		int hR = 시스템.getRandInt(10) + 1;
		normal = new 몬스터[nR];
		hell = new 몬스터[hR];
		for (int i = 0; i < nR; i++) {
			int nRsam = 시스템.getRandInt(시스템.getmlistIdx() - 시스템.getMonIdx());
			normal[i] = new 몬스터(시스템.get샘플몬스터(nRsam));
			normal[i].몬스터생성();

		}
		for (int i = 0; i < hR; i++) {
			int hRsam = 시스템.getRandInt(시스템.getMonIdx() - 1);
			hell[i] = new 몬스터(시스템.get샘플몬스터(시스템.getmlistIdx() - 시스템.getMonIdx() + hRsam));
			hell[i].마족몬스터생성();
		}

		boss = new 몬스터(시스템.get샘플몬스터(시스템.getmlistIdx() - 1));
		boss.마족몬스터생성();
	}

	public 마왕성 get마왕성() {
		return this;
	}

	public 몬스터[] getNormal몬스터() {
		return normal;
	}

	public 몬스터[] getHell몬스터() {
		return hell;
	}

	public 몬스터 getBoss몬스터() {
		return boss;
	}

	public int getNmonSize() {
		return normal.length;
	}

	public int getHmonSize() {
		return hell.length;
	}

	public boolean 마왕죽음여부() {
		return boss.몬스터죽음여부();
	}
}