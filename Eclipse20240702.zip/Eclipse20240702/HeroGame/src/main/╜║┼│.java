package main;

public class 스킬 {
	
	private String 스킬이름;
	private int skillId;
	private int 스킬물리데미지;
	private int 스킬마법데미지;
	
	private int ConsumHP;
	private int ConsumMP;
	
	private int 요구레벨;
	private 시스템.직업종류 요구직업;
	
	스킬()
	{
		
	}
	스킬(스킬 skill)
	{
		스킬이름 = skill.get스킬이름();
		skillId = skill.getSkillId();
		스킬물리데미지 = skill.get스킬물리데미지();
		스킬마법데미지 = skill.get스킬마법데미지();
		ConsumHP = skill.getConsumHP();
		ConsumMP = skill.getConsumMP();
		요구레벨 = skill.getReqLV();
		요구직업 = skill.get요구직업();
	}
	
	스킬(String name, int id, int dmg, int LV, 시스템.직업종류 직업)
	{
		스킬이름 = name;
		setSkillId(id);
		스킬물리데미지 = dmg;
		스킬마법데미지 = dmg;
		요구레벨 = LV;
		요구직업 = 직업;
		요구치계산();	
	}
	
	//////////////////////////////////////////////////////////////////
	//////////////////////////// method //////////////////////////////
	//////////////////////////////////////////////////////////////////
	
	public int getDamage()
	{
		return get스킬물리데미지();
	}
	
	public void 요구치계산()
	{
		ConsumHP = 요구레벨;
		ConsumMP = 요구레벨 * 6;
	}
	
	
	
	//////////////////////////////////////////////////////////////////
	//////////////////////////// check ///////////////////////////////
	//////////////////////////////////////////////////////////////////
	
	public boolean 스킬사용가능여부(int hp, int mp, int lv, 시스템.직업종류 job)
	{
		if ( 스킬사용가능레벨여부(lv) && 스킬사용가능HP소모값여부(hp) 
				&& 스킬사용가능MP소모값여부(mp) && 스킬사용가능직업여부(job))
			return true;
		else 
			return false;
	}
	
	public boolean 스킬사용가능레벨여부(int lv)
	{
		if ( 요구레벨 <= lv) 
			return true;
		else 
			return false;
	}
	
	public boolean 스킬사용가능HP소모값여부(int hp)
	{
		if ( hp > getConsumHP())
			return true;
		else
			return false;
	}
	
	public boolean 스킬사용가능MP소모값여부(int mp)
	{
		if ( mp >= getConsumHP())
			return true;
		else
			return false;
	}
	
	public boolean 스킬사용가능소모값여부(int hp, int mp)
	{
		if(스킬사용가능HP소모값여부(hp) && 스킬사용가능MP소모값여부(mp))
			return true;
		else
			return false;
	}
	
	public boolean 스킬사용가능직업여부(시스템.직업종류 job)
	{
		if ( get요구직업() == 시스템.직업종류.일반 || job == 시스템.직업종류.마검사)
			return true;
		else if (get요구직업() == job)
			return true;
		else 
			return false;
	}
	
	public void 스킬정보보기()
	{
		System.out.print(get스킬이름());
		if ( 요구직업 == 시스템.직업종류.검사 )
			System.out.println(" ( 소모값 : (HP : " + getConsumHP() + "  MP : " + getConsumMP() + " ) )");
		else
			System.out.println(" ( 소모값 : (" + "MP : " + getConsumMP() + " ) )");
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	//////////////////////////////////////////////////////////////////
	//////////////////////// getter && setter ////////////////////////
	//////////////////////////////////////////////////////////////////	
	

	public int getConsumHP() {
		return ConsumHP;
	}
	public void setConsumHP(int consumHP) {
		ConsumHP = consumHP;
	}
	public int getConsumMP() {
		return ConsumMP;
	}
	public void setConsumMP(int consumMP) {
		ConsumMP = consumMP;
	}
	public int getReqLV() {
		return 요구레벨;
	}
	public void setReqLV(int reqLV) {
		this.요구레벨 = reqLV;
	}
	public int get스킬마법데미지() {
		return 스킬마법데미지;
	}
	public void set스킬마법데미지(int 스킬마법데미지) {
		this.스킬마법데미지 = 스킬마법데미지;
	}
	public int get스킬물리데미지() {
		return 스킬물리데미지;
	}
	public void set스킬물리데미지(int 스킬물리데미지) {
		this.스킬물리데미지 = 스킬물리데미지;
	}
	public 시스템.직업종류 get요구직업() {
		return 요구직업;
	}
	public void set요구직업(시스템.직업종류 reqJob) {
		this.요구직업 = reqJob;
	}
	public String get스킬이름() {
		return 스킬이름;
	}
	public void set스킬이름(String 스킬이름) {
		this.스킬이름 = 스킬이름;
	}
	public int getSkillId() {
		return skillId;
	}
	public void setSkillId(int skillId) {
		this.skillId = skillId;
	}
	


}
