package main;

public class 아이템 {
	private String name;
	private 시스템.아이템종류 iType;
	private int itemNumber;

	// ===== 포션 변수 ===== //
	private int recovery;
	private 시스템.포션종류 pType;
	// =================== //

	// ===== 소비 변수 ===== //
	// =================== //

	// ===== 장비 변수 ===== //
	private 시스템.직업종류 직업제한;
	private 시스템.장비종류 eType; // 장비 종류 ( 무기 or 아머 )
	private int 물리; // physical attack
	private int 마법; // magical attack

	// =================== //

	// ===== 기타 변수 ===== //
	// =================== //

	public 아이템() {

	}

	public 아이템(아이템 i) {
		this.eType = i.getETypeID();
		this.name = i.getName();
		this.iType = i.getITypeID();
		this.itemNumber = i.getItemNumber();
		this.물리 = i.get물리();
		this.마법 = i.get마법();
	}

	// 아이템생성자 //
	public 아이템(String n, 시스템.아이템종류 type, int number) {
		this.name = n;
		this.iType = type;
		this.itemNumber = number;
	}

	/////////////////////////////////////////////
	///////////// getter & setter ///////////////
	/////////////////////////////////////////////

	public int get물리() {
		return 물리;
	}

	public int get마법() {
		return 마법;
	}

	public 아이템 getItem() {
		return this;
	}

	public 시스템.장비종류 getETypeID() {
		return eType;
	}

	public 시스템.아이템종류 getITypeID() {
		return iType;
	}

	public void setTypeID(시스템.아이템종류 id) {
		iType = id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String str) {
		this.name = str;
	}

	/////////////////////////////////////////////
	////////////////// check ////////////////////
	/////////////////////////////////////////////

	public boolean 소비아이템여부() {
		if (iType == 시스템.아이템종류.소비)
			return true;
		else
			return false;
	}

	public boolean 사용가능여부(아이템 item) {
		시스템.아이템종류 id = item.getITypeID();
		if (id == 시스템.아이템종류.소비 || id == 시스템.아이템종류.포션)
			return true;
		else
			return false;
	}

	public boolean 사용가능여부() {
		if (iType == 시스템.아이템종류.소비 || iType == 시스템.아이템종류.포션)
			return true;
		else
			return false;
	}

	public boolean 포션아이템인지여부(아이템 item) {
		if (item.getITypeID() == 시스템.아이템종류.포션)
			return true;
		else
			return false;
	}

	public boolean 포션아이템인지여부() {
		if (iType == 시스템.아이템종류.포션)
			return true;
		else
			return false;
	}

	public boolean 장비아이템인지여부() {
		// TODO Auto-generated method stub
		if (iType == 시스템.아이템종류.장비)
			return true;
		else
			return false;
	}

	/////////////////////////////////////////////
	///////////////// method ///////////////////
	/////////////////////////////////////////////

	public void 보유아이템정보보이기(int n) {
		System.out.println("\n아이템 이름 : " + name + "\t보유수량 : " + n);
	}

	public void 발견아이템정보보이기(int n) {
		System.out.printf("아이템 이름 : %s \t수량 : %d\n", name, n);
		if (iType == 시스템.아이템종류.장비) {
			if (eType == 시스템.장비종류.무기)
				System.out.printf("공격력 : %d \t마법공격력 : %d\n", 물리, 마법);
			else
				System.out.printf("방어력 : %d \t마법저항력 : %d\n", 물리, 마법);
		}
	}

	public void 아이템정보보이기(int n) {
		System.out.println("\n아이템 이름 : " + name + "\t수량 : " + n);
	}

	public void 아이템정보보이기() {
		System.out.println("아이템 이름 : " + name);
	}

	// ======= 포션 ======= //
	public void 포션아이템설정(시스템.포션종류 type_po, int recovery) {
		this.recovery = recovery;
		this.pType = type_po;
	}

	public void 포션아이템사용하기(스탯 status) {
		status.아이템사용으로회복하기(recovery, pType);
	}
	// =================== //

	// ======= 소비 ======= //
	public void 소비아이템설정() // magical resistance )
	{

	}
	// =================== //

	// ======= 장비 ======= //
	public void 장비아이템설정(시스템.장비종류 type, int phy, int magic) {
		this.eType = type;
		this.물리 = phy;
		this.마법 = magic;
	}

	// =================== //

	// ======= 기타 ======= //
	// =================== //

	@Override
	public String toString() {
		return this.name;
	}

	public int getItemNumber() {
		return itemNumber;
	}

	public void setItemNumber(int itemNumber) {
		this.itemNumber = itemNumber;
	}

	public 시스템.직업종류 get직업제한() {
		return 직업제한;
	}

	public void set직업제한(시스템.직업종류 직업제한) {
		this.직업제한 = 직업제한;
	}

}