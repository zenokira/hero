package main;

public class 용사키우기MAIN {
	private 용사 player;
	private 마왕성 devil;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		용사키우기MAIN st = new 용사키우기MAIN();

		st.Start();
	}

	void Start() {
//		String name = Intro();
		String name = "용사";
		시스템 s = new 시스템();

		Initialize(name);

		System.out.println(player.getName() + "의 모험을 시작합니다.");

		while (true) {
			int choice = player.용사의선택();

			if (choice == 1)
				이벤트발생();
			else if (choice == 2)
				player.정비시간();
			else if (choice == 3)
				마왕성토벌();
			else if ( choice == 4)
				player.수련();
			else 
				System.out.println("잘못입력하셨습니다.\n");

			if (player.용사죽음여부())
				Ending용사의죽음();
			if (devil.마왕죽음여부())
				Ending마왕의죽음();
		}
	}

	void 이벤트발생() {
		int event = 시스템.getRandInt(100) + 1;

		if (event > 40 && event <= 100) // 몬스터 발견
		{
			int type = 시스템.get랜덤몬스터종류();
			int src = 시스템.get랜덤몬스터();
			몬스터 mon = new 몬스터(시스템.get샘플몬스터(type*시스템.getMonIdx()+src));
			mon.몬스터생성();

			int c = player.몬스터발견(mon);
			
			if (c == 1)
				도망가능전투(player, mon);
			else if (c == 2)
				생사결(player, mon);
			else
				System.out.println("성공적으로 도망쳤다.");
		} else if (event > 20 && event <= 40) // 아이템 발견
		{
			int id = 시스템.랜덤아이템생성() % (시스템.getilistIdx()-시스템.getItemIdx()) + 시스템.getItemIdx();
			int n = 시스템.아이템수량생성(id);
			아이템 item = new 아이템(시스템.get샘플아이템(id));

			int c = player.아이템발견(item, n);
			if (c == 1)
				player.아이템획득(id, n);
			else
				System.out.println("아이템 획득을 포기했다.\n");
		} else if (event > 10 && event <= 20) // 마을 발견
		{

			int c = player.마을발견();
			if (c == 1) {
				시스템.직업종류 마을 = 랜덤마을생성();
				if (마을 == 시스템.직업종류.일반) {
					int r = 시스템.getRandInt(100);
					if (r % 10 == 5)
						player.온천에서회복한다();
					else
						player.마을에서회복한다();
				} else {
					int choice = player.직업마을발견(마을);

					if (choice == 1) {
						player.전직(마을);
					} else {
						System.out.println("전직을 포기하였습니다.");
					}
				}
			} else
				System.out.println("\n마을을 그냥 지나쳐다.\n");
		} else if (event > 0 && event <= 10) // 던전 발견
		{
			int t = 시스템.getRandInt(시스템.getMonIdx() - 1);
			int idx = 시스템.getmtypeIdx();

			while (true) {
				int choice = player.용사의던전선택(t, idx);
				if( choice == 1)
					break;
				else if (choice == 2)
					player.스탯창보기();
				else if (choice == 3) {
					System.out.println("던전입장을 포기하셨습니다.\n");
					return;
				}
				else
					System.out.println("잘못입력하셨습니다.\n");	
			}

			int r = 시스템.getRandInt(8) + 2;
			몬스터[] m = new 몬스터[r];

			for (int i = 0; i < r - 1; i++) {
				if (i % idx != 5)
					m[i] = new 몬스터(시스템.get샘플몬스터(t * idx + i % idx));
				else
					m[i] = new 몬스터(시스템.get샘플몬스터(t * idx + t));
				m[i].몬스터생성();
			}
			m[r - 1] = new 몬스터(시스템.get샘플몬스터(t * 시스템.getMonIdx() + 시스템.getMonIdx() - 1));
			m[r - 1].던전보스몬스터생성();

			for (int i = 0; i < r; i++) {
				m[i].스탯창보기();
				sleep(1500);
				도망불가능전투(player, m[i]);
				if (player.용사죽음여부()) {
					System.out.println("용사가 던전에서 죽었다...");
					return;
				}
			}
		}
	}

	private void 생사결(용사 p, 몬스터 m) {
		// TODO Auto-generated method stub
		int turn = 1;
		int c;
		boolean zero = false;
		boolean flag = true;
		while (flag) {
			if (turn % 2 == 1) {
				DMG dmg = p.공격();
				m.피격(dmg);
			} 
			else {
				DMG dmg = m.공격();
				p.피격(dmg);
				System.out.println();
			}
			if (p.용사죽음여부())
				break;
			if (m.check몬스터죽음()) {
				player.몬스터처치(m);
				break;
			}
			turn++;
		}
	}

	private void 도망가능전투(용사 p, 몬스터 m) {
		// TODO Auto-generated method stub
		int turn = 1;
		int c;
		int player_effect_cnt = 0;
		int monster_effect_cnt = 0;
		boolean flag = true;
		while (flag) {
			if (turn % 2 == 1) {
				if ( !p.check정상상태())
				{
					player_effect_cnt = ++player_effect_cnt % 3;
					if(player_effect_cnt == 0 ) 
						m.setEffectType(시스템.상태이상종류.정상);
					else
						p.상태이상상태();
				}
				if ( !check공격가능상태(p.getStatus().getEffectType())) {turn++; continue;}
				
				c = p.용사턴_도망가능();
				if (c == 1) {
					DMG dmg = p.공격();
					m.피격(dmg);
				} else if (c == 2) {
					스킬 s = p.용사의스킬선택();
					if (s == null)
						continue;
					DMG dmg = p.스킬공격(s);
					m.스킬피격(dmg);
				} 
				else if( c == 3 )
				{
					p.아이템사용하기();
					continue;
				}
					
				else if(c == 4){
					System.out.println("성공적으로 도망쳤다\n");
					return;
				}
			} else {
				if ( !m.check정상상태())
				{
					monster_effect_cnt = ++monster_effect_cnt % 3;
					if(monster_effect_cnt == 0 ) 
						m.setEffectType(시스템.상태이상종류.정상);
					else
						m.상태이상상태();
				}
				if ( !check공격가능상태(m.getEffectType())) {turn++; System.out.println(); continue;}
				DMG dmg = m.공격();
				p.피격(dmg);
				System.out.println();
			}
			if (p.용사죽음여부())
				break;
			if (m.check몬스터죽음()) {
				player.몬스터처치(m);
				break;
			}
			turn++;
		}
	}

	private void 마왕성토벌() {
		// TODO Auto-generated method stub
		while (true) {
			int choice = player.용사의던전선택();

			if (choice == 1) {

				System.out.println("마왕성의 문을 열고 들어갔다.\n");
				sleep(1500);

				마왕성전투(player, devil.normal);
				if (!player.용사죽음여부())
					while (player.마왕성중간휴식());
				else
					return;

				System.out.println("마왕성을 오르기 시작했다.\n");
				sleep(1500);

				마왕성전투(player, devil.getHell몬스터());
				if (!player.용사죽음여부())
					while (player.마왕성중간휴식());
				else
					return;

				System.out.println("마왕성을 오르기 시작했다.\n");
				sleep(1500);
				System.out.println("마왕의 방 입구의 문을 열었다.\n");
				sleep(1500);
				System.out.println("마왕이 등장했다.\n");
				sleep(1500);

				도망불가능전투(player, devil.getBoss몬스터());
				if (!player.용사죽음여부()) {
					System.out.println("마왕을 물리쳤습니다.\n");
					sleep(1500);
				}
				break;
			} else if (choice == 2)
				player.스탯창보기();
			else if(choice == 3)
				System.out.println("마왕성 도전을 포기했다.\n");
			else
			{
				System.out.println("잘못 입력하셨습니다.\n");
			}
			break;
		}
	}

	private void 마왕성전투(용사 p, 몬스터[] m) {
		// TODO Auto-generated method stub
		
		for (몬스터 mon : m)
		{
			mon.스탯창보기();
			도망불가능전투(p,mon);
			if( p.용사죽음여부()) break;
		}
	}

	private void 도망불가능전투(용사 p, 몬스터 m) {
		// TODO Auto-generated method stub
		int turn = 1;
		int c;
		boolean flag = true;
		while (flag) {
			if (turn % 2 == 1) {
				c = p.용사턴_도망불가능();
				
				if (c == 1) {
					DMG dmg = p.공격();
					m.피격(dmg);
				} else if (c == 2) {
					스킬 s = p.용사의스킬선택();
					if (s == null)
						continue;
					DMG dmg = p.스킬공격(s);
					m.스킬피격(dmg);
				}
				else if(c == 3)
				{
					생사결(player, m);
					break;
				}
				else if(c == 4)
				{
					p.아이템사용하기();
					continue;
				}
			} 
			else {
				DMG dmg = m.공격();
				p.피격(dmg);
				System.out.println();
			}
			if (p.용사죽음여부())
				break;
			if (m.check몬스터죽음()) {
				player.몬스터처치(m);
				break;
			}
			turn++;
		}
	}

	void Initialize(String name) {
		player = new 용사(name);
		devil = new 마왕성(시스템.get마왕성());
	}

	public 시스템.직업종류 랜덤마을생성() {

		int rand = 시스템.getRandInt(100) + 1;

		if (rand > 30)
			return 시스템.직업종류.일반;
		else if (rand > 15)
			return 시스템.직업종류.검사;
		else
			return 시스템.직업종류.마법사;
	}
	
	boolean check공격가능상태(시스템.상태이상종류 상태이상)
	{
		if ( 상태이상.ordinal() <= 2)
			return true;
		else if( 상태이상 == 시스템.상태이상종류.기절)	
			return false;
		else if( 상태이상 == 시스템.상태이상종류.마비)
		{
			int rand = 시스템.getRandInt(100)+1;
			
			if (rand % 2 == 0) return true;
			else				return false;
		}
		return false;
	}
	
	
	
	String Intro() {
		스토리String("마왕군과 대치중이던 용사가 단말마의 비명을 질렀다");
		스토리String("그와 함께 마왕 한마디 말을 내뱉으며 쓰러졌다");
		스토리String("마왕 : I will be back");
		스토리String("마왕이 쓰러지자 마왕군은 후퇴했고");
		스토리String("다시금 평화를 되찾았다");
		스토리String("평화롭게 지내는 500년의 시간이 흐르자 용사는 잊혀져갔다");
		스토리String("평화가 찾아오고 생산력이 복구되자 지배층의 욕심은 다시 생겨났다");
		스토리String("그로인해 다시금 전쟁이 시작되었다");
		스토리String("전쟁은 150년간 지속되었고");
		스토리String("인구는 마왕군과 전쟁했던 시대만큼 줄어버렸다");
		스토리String("심지어 마왕의 부활 필요한 대량의 피가 대지를 적셨고");
		스토리String("마왕의 부활이 임박해졌다");
		System.out.println("\n--------------------------\n");

		스토리String("용사가 마왕을 물리친지 666년이 지났다");
		스토리String("그동안의 거듭된 인간들의 전쟁으로 피가 필요했던 마왕은 결국 부활했고");
		스토리String("인간들은 전쟁을 멈추고 마왕군과 대적했다");
		스토리String("하지만 너무 많은 사람들이 전쟁으로 죽어버렸고");
		스토리String("마왕군과의 전투에서 항상 선두에서 싸우던 용사조차 이제는 없었다");
		스토리String("불리한 싸움을 거듭하던 그때 수도에 있던 성녀가 신탁을 받았다");
		스토리String("'지난번 마왕과 대적했던 용사 역시도 다시 태어났고");
		스토리String("다시금 그의 각성이 이루어져 인간들을 구원하리라' 라고");
		System.out.println("\n--------------------------\n");

		스토리String("신탁이 있은 후로부터 2년이 지났다.");
		스토리String("사람들은 신탁의 용사가 나타나기를 손꼽아 기다렸다");
		스토리String("이미 포기한 자들도 생겨났다");
		스토리String("성녀를 욕하는 자들 역시 날이 갈수록 늘어만 갔다");
		스토리String("절망의 나날이 흐르던 그때 다시금 성녀에게 신탁이 내려왔다");
		스토리String("'용사는 이미 각성하였고, 스스로 성장해나가고 있다' 라고");
		System.out.println("\n--------------------------\n");

		스토리String("어느 산골짜기 마을에 오크무리가 지나갔다");
		스토리String("마을의 모든 것이 부서져버렸으나 어린 생존자가 한명 있었다");
		스토리String("마을의 유일한 생존자인 당신에게");
		스토리String("하늘에서 강렬한 빛을 뿜는 존재가 내려와 말을 걸었다");

		System.out.println("당신의 이름은 무엇인가요? ");

		return 시스템.getInputString();
	}

	void sleep(int m) {
		try {
			Thread.sleep(m);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	void Ending용사의죽음() {
		System.out.println("\n");
		스토리String("용사가 죽어 마왕군이 득세합니다");
		System.out.println("----------< The End >----------");
		System.exit(0);
	}

	void Ending마왕의죽음() {
		스토리String(player.getName() + " 이(가) 마왕을 쓰러뜨렸다");
		스토리String(player.getName() + " 은(는) 지친 몸을 이끌고 왕국으로 돌아왔고");
		스토리String("대륙은 축제의 분위기에 휩싸였다");
		스토리String("하지만 왕은 자신보다 인기가 많아진 " + player.getName() + " 이(가) 마음에 들지않았다");
		스토리String("그래서 " + player.getName() + " 을(를) 위한 연회에서 용사의 술잔에 독을 탔다");
		스토리String("아직 마왕과의 전투에서 입은 부상들이 회복되지않은 상태에서");
		스토리String("극독을 마신 " + player.getName() + " 은(는) 피를 토하며 쓰러졌고");
		스토리String("왕이 소리쳤다");
		스토리String("마왕도 이긴 " + player.getName() + " 도 독 앞에선 별 수 없구나!!");
		스토리String("산골짜기에서 나타난 용사 ( " + player.getName() + " ) 는 그렇게 허무하게 죽음을 맞이했다");
		스토리String("----------< The End >----------");

		System.exit(0);
	}

	void 스토리String(String str) {
		System.out.println("-" + str + "-");
		sleep(2000);
	}

}