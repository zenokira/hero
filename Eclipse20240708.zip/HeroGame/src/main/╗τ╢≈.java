package main;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map.Entry;

public abstract class 사람 {
	protected String name;
	protected 스탯 status;
	protected int[] equip = new int[6];
	protected HashSet<Integer> skill = new HashSet<Integer>();
	protected HashMap<Integer, Integer> inv = new HashMap<Integer, Integer>();

	사람() {
		for (int i = 0; i < 6; i++) {
			equip[i] = -1;
		}

		for (int i = 0; i < 시스템.getSkillIdx(); i++)
			skill.add(i);
	}

	/////////////////////////////////////////////
	////////////////// check ////////////////////
	/////////////////////////////////////////////

	public boolean 아이템소지여부() {
		if (!inv.isEmpty())
			return true;

		return false;
	}

	public boolean 해당아이템소지여부(int iNum) {
		return inv.containsKey(iNum);
	}

	/////////////////////////////////////////////
	//////////////// abstract ///////////////////
	/////////////////////////////////////////////

	abstract void 아이템개수변경(int iNum, int n);
	abstract void 아이템획득(int iNum, int n) ;
	abstract void 인벤토리보기();
	abstract void 장비인벤토리보기();
	abstract void 장착장비보기();
	abstract void 보유스킬보기();

	/////////////////////////////////////////////
	///////////// getter & setter ///////////////
	/////////////////////////////////////////////

	public String getName() {
		return name;
	}

	public int get해당아이템개수(int iNum) {
		return inv.get(iNum);
	}

	public 스탯 getStatus() {
		return status;
	}

	public void setStatus(스탯 status) {
		this.status = status;
	}

}
