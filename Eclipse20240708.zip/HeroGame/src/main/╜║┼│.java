package main;

public class 스킬 {
	
	private String 스킬이름;
	private int skillId;
	private 시스템.데미지타입 dmgType;
	private 시스템.상태이상종류 effectType;
	
	private int dmg;
	
	private int ConsumHP;
	private int ConsumMP;
	
	private int 요구레벨;
	private 시스템.직업종류 요구직업;
	
	스킬()
	{
		
	}
	스킬(스킬 skill)
	{
		스킬이름 = skill.get스킬이름();
		skillId = skill.getSkillId();
		dmg = skill.getDmg();
		ConsumHP = skill.getConsumHP();
		ConsumMP = skill.getConsumMP();
		요구레벨 = skill.getReqLV();
		요구직업 = skill.get요구직업();
	}
	
	스킬(String name, int id, int LV, 시스템.직업종류 직업, 시스템.상태이상종류 상태이상)
	{
		스킬이름 = name;
		setSkillId(id);
		요구레벨 = LV;
		요구직업 = 직업;
		setEffectType(상태이상);
		요구치계산();	
	}
	
	//////////////////////////////////////////////////////////////////
	//////////////////////////// method //////////////////////////////
	//////////////////////////////////////////////////////////////////
	
	public int getDamage()
	{
		return getDmg();
	}
	
	public void 요구치계산()
	{
		if(요구직업 == 시스템.직업종류.마검사)
		{
			ConsumHP = 요구레벨;
			ConsumMP = 요구레벨 * 6;
		}
		else
		{
			ConsumHP = 0;
			ConsumMP = 요구레벨 * 5;
		}
	}
		
	//////////////////////////////////////////////////////////////////
	//////////////////////////// check ///////////////////////////////
	//////////////////////////////////////////////////////////////////
	
	public boolean 스킬사용가능여부(int hp, int mp, int lv, 시스템.직업종류 job)
	{
		if ( 스킬사용가능레벨여부(lv) && 스킬사용가능HP소모값여부(hp) 
				&& 스킬사용가능MP소모값여부(mp) && 스킬사용가능직업여부(job))
			return true;
		else 
			return false;
	}
	
	public boolean 스킬사용가능레벨여부(int lv)
	{
		if ( 요구레벨 <= lv) 
			return true;
		else 
			return false;
	}
	
	public boolean 스킬사용가능HP소모값여부(int hp)
	{
		if ( hp > getConsumHP())
			return true;
		else
			return false;
	}
	
	public boolean 스킬사용가능MP소모값여부(int mp)
	{
		if ( mp >= getConsumMP())
			return true;
		else
			return false;
	}
	
	public boolean 스킬사용가능소모값여부(int hp, int mp)
	{
		if(스킬사용가능HP소모값여부(hp) && 스킬사용가능MP소모값여부(mp))
			return true;
		else
			return false;
	}
	
	public boolean 스킬사용가능직업여부(시스템.직업종류 job)
	{
		if ( get요구직업() == 시스템.직업종류.일반 || job == 시스템.직업종류.마검사)
			return true;
		else if (get요구직업() == job)
			return true;
		else 
			return false;
	}
	
	public void 스킬정보보기()
	{
		System.out.print(get스킬이름());
		if ( 요구직업 == 시스템.직업종류.검사 )
			System.out.println(" ( 소모값 : (HP : " + getConsumHP() + "  MP : " + getConsumMP() + " ) )");
		else
			System.out.println(" ( 소모값 : (" + "MP : " + getConsumMP() + " ) )");
	}
	
	public int 스킬데미지계산(int pDmg, int lv)
	{
		int result = (dmg+pDmg+lv);
		return result;
	}
	
	public boolean 상태이상확률()
	{
		int rand = 시스템.getRandInt(100)+1;
				
		if (rand % 10 == 0) return true;
		else				return false;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	//////////////////////////////////////////////////////////////////
	//////////////////////// getter && setter ////////////////////////
	//////////////////////////////////////////////////////////////////	
	

	public int getConsumHP() {
		return ConsumHP;
	}
	public void setConsumHP(int consumHP) {
		ConsumHP = consumHP;
	}
	public int getConsumMP() {
		return ConsumMP;
	}
	public void setConsumMP(int consumMP) {
		ConsumMP = consumMP;
	}
	public int getReqLV() {
		return 요구레벨;
	}
	public void setReqLV(int reqLV) {
		this.요구레벨 = reqLV;
	}
	public 시스템.직업종류 get요구직업() {
		return 요구직업;
	}
	public void set요구직업(시스템.직업종류 reqJob) {
		this.요구직업 = reqJob;
	}
	public String get스킬이름() {
		return 스킬이름;
	}
	public void set스킬이름(String 스킬이름) {
		this.스킬이름 = 스킬이름;
	}
	public int getSkillId() {
		return skillId;
	}
	public void setSkillId(int skillId) {
		this.skillId = skillId;
	}
	public 시스템.데미지타입 getDmgType() {
		return dmgType;
	}
	public void setDmgType(시스템.데미지타입 dmgType) {
		this.dmgType = dmgType;
	}
	public int getDmg() {
		return dmg;
	}
	public void setDmg(int dmg) {
		this.dmg = dmg;
	}
	public 시스템.상태이상종류 getEffectType() {
		return effectType;
	}
	public void setEffectType(시스템.상태이상종류 effectType) {
		this.effectType = effectType;
	}
	


}
