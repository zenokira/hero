package main;

public class 스탯 {
	// [ 직업 , maxHP, HP , maxMP, MP , EXP , 레벨 ]
	// [ 일반 , 검사 , 마법사 , 마검사 ]

	final private int beginMAX = 100;

	// 기본 스탯 //
	protected 시스템.직업종류 job;
	protected 시스템.데미지타입 dmgType;
	protected 시스템.상태이상종류 effectType;
	protected int maxHP;
	protected int maxMP;
	protected int HP;
	protected int MP;
	protected int EXP;
	protected int maxEXP;
	protected int LV;

	// 공격력 스탯 //
	protected int 물리공격력;
	protected int 마법공격력;

	// 방어력 스탯 //
	protected int 물리방어력;
	protected int 마법방어력;

	protected int 장비물리공격력;
	protected int 장비물리방어력;

	protected int 장비마법공격력;
	protected int 장비마법방어력;

	스탯() {
		Initialize();
	}

	스탯(int LV, int maxHp, int maxMp) {
		initHP(maxHP);
		initMP(maxMP);
		this.LV = LV;
	}

	void Initialize() {
		job = 시스템.직업종류.일반;
		setDmgType(시스템.데미지타입.물리);
		setEffectType(시스템.상태이상종류.정상);
		
		initHP(beginMAX);
		initMP(beginMAX);
		EXP = 0;
		setMaxEXP(100);
		LV = 1;
		물리공격력 = 마법공격력 = 10;
		물리방어력 = 마법방어력 = 5;
		장비물리공격력 = 장비물리방어력 = 0;
		장비마법공격력 = 장비마법방어력 = 0;
	}

	private void 검사스탯업데이트() {
		setMaxHP(getMaxHP() + 30);
		setMaxMP(getMaxMP() - 20);

		set물리공격력(get물리공격력() + 4);
		set마법공격력(get마법공격력() - 2);
		set물리방어력(get물리방어력() + 4);
		set마법방어력(get마법방어력() - 2);
	}

	private void 마법사스탯업데이트() {
		setMaxHP(getMaxHP() - 20);
		setMaxMP(getMaxMP() + 30);

		set물리공격력(get물리공격력() - 2);
		set마법공격력(get마법공격력() + 4);
		set물리방어력(get물리방어력() - 2);
		set마법방어력(get마법방어력() + 4);
	}

	public void 전직스탯업데이트(시스템.직업종류 직업) {

		if (직업 == 시스템.직업종류.마검사) {
			if (job == 시스템.직업종류.마법사)
				검사스탯업데이트();
			else if (job == 시스템.직업종류.검사)
				마법사스탯업데이트();
		} else if (직업 == 시스템.직업종류.검사)
			검사스탯업데이트();
		else if (직업 == 시스템.직업종류.마법사)
			마법사스탯업데이트();

		setHP(getMaxHP());
		setMP(getMaxMP());
		setJob(직업);
	}
	
	public void 스탯업데이트()
	{
		
	}
	
	
	
	
	
	

	public void initHP(int hp) {
		setHP(hp);
		setMaxHP(hp);
	}

	public void initMP(int mp) {
		setMP(mp);
		setMaxMP(mp);
	}

	public int recHP(int Hp) {
		HP += Hp;
		return HP;
	}

	public int recMP(int Mp) {
		MP += Mp;
		return MP;
	}

	public int mHP(int Hp) {
		HP -= Hp;
		return HP;
	}

	public int mMP(int Mp) {
		MP -= Mp;
		return MP;
	}

	/////////////////////////////////////////////
	///////////// getter & setter ///////////////
	/////////////////////////////////////////////
	
	public 시스템.상태이상종류 getEffectType() {
		return effectType;
	}

	public void setEffectType(시스템.상태이상종류 effectType) {
		this.effectType = effectType;
	}
	
	public 시스템.직업종류 getJob() {
		return job;
	}

	public void setJob(시스템.직업종류 job) {
		this.job = job;
	}

	public int getMaxHP() {
		return maxHP;
	}

	public void setMaxHP(int maxHP) {
		this.maxHP = maxHP;
	}

	public int getMaxMP() {
		return maxMP;
	}

	public void setMaxMP(int maxMP) {
		this.maxMP = maxMP;
	}

	public int getHP() {
		return HP;
	}

	public int getMP() {
		return MP;
	}

	public void setHP(int hp) {
		this.HP = hp;
	}

	public void setMP(int mp) {
		this.MP = mp;
	}

	public int getEXP() {
		return EXP;
	}

	public void setEXP(int exp) {
		EXP = exp;
	}

	public int getLV() {
		return LV;
	}

	public void setLV(int lV) {
		LV = lV;
	}

	public int getBeginMAX() {
		return beginMAX;
	}

	public int get물리공격력() {
		return 물리공격력;
	}

	public void set물리공격력(int 물리공격력) {
		this.물리공격력 = 물리공격력;
	}

	public int get마법공격력() {
		return 마법공격력;
	}

	public void set마법공격력(int 마법공격력) {
		this.마법공격력 = 마법공격력;
	}

	public int get물리방어력() {
		return 물리방어력;
	}

	public void set물리방어력(int 물리방어력) {
		this.물리방어력 = 물리방어력;
	}

	public int get마법방어력() {
		return 마법방어력;
	}

	public void set마법방어력(int 마법방어력) {
		this.마법방어력 = 마법방어력;
	}

	////////////////////////////////////////////////////

	public void LVUP() {
		LV += 1;
	}

	public void changeEXP(double exp) {
		EXP += exp;
	}

	public int get합산물리공격력() {
		return 물리공격력 + 장비물리공격력;
	}

	public int get합산물리방어력() {
		return 물리방어력 + 장비물리방어력;
	}

	public int get합산마법공격력() {
		return 마법공격력 + 장비마법공격력;
	}

	public int get합산마법방어력() {
		return 마법방어력 + 장비마법방어력;
	}

	public int 물리데미지계산(int ac) {
		int dmg = (get합산물리공격력() - ac);
		if (dmg <= 0)
			dmg = 0;

		return dmg;
	}

	public int 마법데미지계산(int mr) {
		int dmg = (get합산마법공격력() - mr);
		if (dmg <= 0)
			dmg = 0;

		return dmg;
	}

	public void change장비스탯(시스템.장비종류 etype, int n) {
		if (etype == 시스템.장비종류.무기)
			장비물리공격력 += n;
		else
			장비물리방어력 += n;
	}

	public void 스탯창보기() {
		System.out.println();
		System.out.println("---------------<상태창>---------------");
		System.out.print("LV : " + getLV() + "\t");
		System.out.println("EXP : " + getEXP() + " / " + getMaxEXP());
		System.out.println("직업 : " + getJob());
		System.out.println("HP : " + getHP() + " / " + getMaxHP());
		System.out.println("MP : " + getMP() + " / " + getMaxMP());
		System.out.println("------------------------------------");
		System.out.print("물리공격력 : " + (물리공격력 + 장비물리공격력) + "(+" + 장비물리공격력 + ")");
		System.out.println("\t마법공격력 : " + (마법공격력 + 장비마법공격력) + "(+" + 장비마법공격력 + ")");
		System.out.print("방어력    : " + (물리방어력 + 장비물리방어력) + "(+" + 장비물리방어력 + ")");
		System.out.println("\t\t마법저항력 : " + (마법방어력 + 장비마법방어력) + "(+" + 장비마법방어력 + ")");
		System.out.println("------------------------------------");
	}

	void 현재체력마나상태보기() {
		System.out.print("HP : " + getHP() + " / " + getMaxHP());
		System.out.println("  \tMP : " + getMP() + " / " + getMaxMP());
		System.out.println();
	}

	public void 레벨업() {
		while (EXP >= getMaxEXP()) {
			EXP -= getMaxEXP();
			setLV(LV + 1);
			레벨업필요경험치변화();

			System.out.println("레벨이 올랐습니다. \n");

			initHP(getMaxHP() + 8);
			initMP(getMaxMP() + 8);

			set물리공격력(get물리공격력() + 2);
			set마법공격력(get마법공격력() + 2);
			set물리방어력(get물리방어력() + 2);
			set마법방어력(get마법방어력() + 2);
		}
	}
	
	public void 레벨업필요경험치변화()
	{
		setMaxEXP(getMaxEXP() + ((getMaxEXP() + LV) / 20 + LV ));
	}

	void 아이템사용으로회복하기(int recovery, 시스템.포션종류 type) {
		int hp = HP + recovery;
		int mp = MP + recovery;

		if (hp > maxHP)
			hp = maxHP;
		if (mp > maxMP)
			mp = maxMP;

		if (type == 시스템.포션종류.힐링)
			setHP(hp);
		if (type == 시스템.포션종류.마나)
			setMP(mp);
		if (type == 시스템.포션종류.활력) {
			setHP(hp);
			setMP(mp);
		}
	}

	void 휴식으로회복(int recovery) {
		int hp = maxHP - HP;
		int mp = maxMP - MP;
		int hrec = recovery;
		int mrec = recovery;

		if (hp < recovery)
			hrec = hp;
		if (mp < recovery)
			mrec = mp;

		recHP(hrec);
		recMP(mrec);

		System.out.println("컨디션이 회복되었다.\n");
		System.out.println(hrec + "의 체력이, " + mrec + "의 마나가 회복되었다.\n");

		if (check풀컨디션()) {
			System.out.println("완전히 회복했다\n");
			현재체력마나상태보기();
		}
	}

	/////////////////////////////////////////////
	////////////////// check ////////////////////
	/////////////////////////////////////////////

	public boolean 레벨업여부() {
		if (EXP >= maxEXP)
			return true;
		else
			return false;
	}

	boolean check풀컨디션() {
		if (HP == maxHP && MP == maxMP)
			return true;
		else
			return false;
	}

	public int get장비물리공격력() {
		return 장비물리공격력;
	}

	public void set장비물리공격력(int 장비물리공격력) {
		this.장비물리공격력 = 장비물리공격력;
	}

	public 시스템.데미지타입 getDmgType() {
		return dmgType;
	}

	public void setDmgType(시스템.데미지타입 dmgType) {
		this.dmgType = dmgType;
	}

	public int getMaxEXP() {
		return maxEXP;
	}

	public void setMaxEXP(int maxEXP) {
		this.maxEXP = maxEXP;
	}



	/*
	 * public void 레벨업(int lv) {
	 * 
	 * for(int i = 1; i <= lv; i++) { LVUP(); }
	 * 
	 * initHP(getMaxHP() + LV * 8); initMP(getMaxMP() + LV * 8);
	 * 
	 * set물리공격력(get물리공격력() + LV * 2); set마법공격력(get마법공격력() + LV * 2);
	 * set물리방어력(get물리방어력() + LV * 2); set마법방어력(get마법방어력() + LV * 2);
	 * 
	 * 스탯창보기(); }
	 */
}