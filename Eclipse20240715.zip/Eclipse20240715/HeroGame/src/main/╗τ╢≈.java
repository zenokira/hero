package main;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map.Entry;

public abstract class 사람 implements 상태이상, 감정표현{
	protected String name;
	protected 스탯 status;
	protected int[] equip = new int[6];
	protected HashSet<Integer> skill = new HashSet<Integer>();
	protected HashMap<Integer, Integer> inv = new HashMap<Integer, Integer>();

	사람() {
		for (int i = 0; i < 6; i++) {
			equip[i] = -1;
		}

		for (int i = 0; i < 시스템.getSkillIdx(); i++)
			skill.add(i);
	}

	/////////////////////////////////////////////
	////////////////// check ////////////////////
	/////////////////////////////////////////////

	public boolean 아이템소지여부() {
		if (!inv.isEmpty())
			return true;

		return false;
	}

	public boolean 해당아이템소지여부(int iNum) {
		return inv.containsKey(iNum);
	}

	/////////////////////////////////////////////
	//////////////// abstract ///////////////////
	/////////////////////////////////////////////

	abstract void 아이템개수변경(int iNum, int n);

	abstract void 아이템획득(int iNum, int n);

	abstract void 인벤토리보기();

	abstract void 장비인벤토리보기();

	abstract void 장착장비보기();

	abstract void 보유스킬보기();

	/////////////////////////////////////////////
	///////////// getter & setter ///////////////
	/////////////////////////////////////////////

	public String getName() {
		return name;
	}

	public int get해당아이템개수(int iNum) {
		return inv.get(iNum);
	}

	public 스탯 getStatus() {
		return status;
	}

	public void setStatus(스탯 status) {
		this.status = status;
	}

/////////////////////////////////////////////
///////////////// 상태이상 ////////////////////
/////////////////////////////////////////////

	@Override
	public void 중독() {
// TODO Auto-generated method stub
		System.out.println("중독 상태가 됐다!!!");
		status.setEffectType(시스템.상태이상종류.중독);
	}

	@Override
	public void 기절() {
		System.out.println("기절 상태가 됐다!!!");
		status.setEffectType(시스템.상태이상종류.기절);
	}

	@Override
	public void 화상() {
		System.out.println("화상 상태가 됐다!!!");
		status.setEffectType(시스템.상태이상종류.화상);
	}

	@Override
	public void 마비() {
		System.out.println("마비 상태가 됐다!!!");
		status.setEffectType(시스템.상태이상종류.마비);
	}

	@Override
	public void 정상() {
		System.out.println("정상 상태가 됐다!!!");
		status.setEffectType(시스템.상태이상종류.정상);
	}

	@Override
	public void 중독상태() {
		status.상태이상지속시간[status.getEffectType().ordinal()] = ++status.상태이상지속시간[status.getEffectType().ordinal()] % 4;
		if (status.상태이상지속시간[status.getEffectType().ordinal()] == 0) {
			status.setEffectType(시스템.상태이상종류.정상);
			return;
		}
		int dmg = 20;
		if (status.getHP() < dmg)
			dmg = status.getHP();
		status.mHP(dmg);
		System.out.println(dmg + " 의 독 데미지를 입었다.\n");
	}

	@Override
	public void 기절상태() {
		status.상태이상지속시간[status.getEffectType().ordinal()] = ++status.상태이상지속시간[status.getEffectType().ordinal()] % 4;
		if (status.상태이상지속시간[status.getEffectType().ordinal()] == 0) {
			status.setEffectType(시스템.상태이상종류.정상);
			return;
		}

	}

	@Override
	public void 화상상태() {
		status.상태이상지속시간[status.getEffectType().ordinal()] = ++status.상태이상지속시간[status.getEffectType().ordinal()] % 4;
		if (status.상태이상지속시간[status.getEffectType().ordinal()] == 0) {
			status.setEffectType(시스템.상태이상종류.정상);
			return;
		}
		int dmg = 20;
		if (status.getHP() < dmg)
			dmg = status.getHP();
		status.mHP(dmg);
		System.out.println(dmg + " 의 화상 데미지를 입었다.\n");
	}

	@Override
	public void 마비상태() {
		status.상태이상지속시간[status.getEffectType().ordinal()] = ++status.상태이상지속시간[status.getEffectType().ordinal()] % 4;
		if (status.상태이상지속시간[status.getEffectType().ordinal()] == 0) {
			status.setEffectType(시스템.상태이상종류.정상);
			return;
		}
	}

	@Override
	public void 정상상태() {
		System.out.println();
		System.out.println(getName() + " 의 상태이상이 풀렸다.\n");
	}

	@Override
	public boolean check정상상태() {
		if (status.getEffectType() == 시스템.상태이상종류.정상)
			return true;
		else
			return false;
	}
	

	@Override
	public void 기쁨() {
		// TODO Auto-generated method stub
		System.out.println("기쁘다");
	}

	public void 아이템을발견해서기쁨() {
		// TODO Auto-generated method stub
		System.out.println("아이템을 발견해서 기쁘다!!\n");
	}

	public void 레벨업기쁨() {
		// TODO Auto-generated method stub
		System.out.println("레벨이 올랐다!!! 기쁘다");
	}

	@Override
	public void 놀람() {
		// TODO Auto-generated method stub
		System.out.println("!!! 놀랐다 !!!");
	}

	public void 몬스터를발견해서놀람(몬스터 mon) {
		// TODO Auto-generated method stub
		System.out.println("갑자기 " + mon.getName() + " 이(가) 튀어나왔다!!!");
//		sleep(1500);
	}

	@Override
	public void 황당함() {
		// TODO Auto-generated method stub
		System.out.println("??? 황당하다 ???");
	}
}
