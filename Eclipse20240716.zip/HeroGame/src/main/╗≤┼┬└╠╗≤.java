package main;

public interface 상태이상 {
	
	public void 중독();
	public void 기절();
	public void 화상();
	public void 마비();
	public void 정상();
	
	public void 중독상태();
	public void 기절상태();
	public void 화상상태();
	public void 마비상태();
	public void 정상상태();
	public void 상태이상상태();
	
	public boolean check정상상태();
	public boolean check상태이상회복();
}
