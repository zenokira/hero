package main;

import java.io.Serializable;
import java.io.ObjectInputFilter.Status;

public class 저장 implements Serializable{
	public 시스템.직업종류 job;
	public 시스템.데미지타입 dmgType;
	public 시스템.상태이상종류 effectType;
	public int[] 상태이상지속시간 = new int[5];
	public int maxHP;
	public int maxMP;
	public int HP;
	public int MP;
	public int EXP;
	public int maxEXP;
	public int LV;

	// 공격력 스탯 //
	public int 물리공격력;
	public int 마법공격력;

	// 방어력 스탯 //
	public int 물리방어력;
	public int 마법방어력;

	public int 장비물리공격력;
	public int 장비물리방어력;

	public int 장비마법공격력;
	public int 장비마법방어력;
	
	public 저장(스탯 status)
	{
		job = status.getJob();
		dmgType = status.getDmgType();
		effectType = status.getEffectType();
		상태이상지속시간 = status.get상태이상지속시간();
		setMaxHP(status.getMaxHP());
		setMaxMP(status.getMaxMP());
		HP= status.getHP();
		MP= status.getMP();
		EXP= status.getEXP();
		maxEXP= status.getMaxEXP();
		LV= status.getLV();

		// 공격력 스탯 //
		물리공격력 = status.get물리공격력();
		마법공격력 = status.get마법공격력();

		// 방어력 스탯 //
		물리방어력 = status.get물리방어력();
		마법방어력 = status.get마법방어력();

		장비물리공격력 = status.get장비물리공격력();
		장비물리방어력 = status.get장비물리방어력();

		장비마법공격력 = status.get장비마법공격력();
		장비마법방어력 = status.get장비마법방어력();
	}

	public int getMaxHP() {
		return maxHP;
	}

	public void setMaxHP(int maxHP) {
		this.maxHP = maxHP;
	}

	public int getMaxMP() {
		return maxMP;
	}

	public void setMaxMP(int maxMP) {
		this.maxMP = maxMP;
	}
	
	//public 용사 get용사() { return player; }
}	
