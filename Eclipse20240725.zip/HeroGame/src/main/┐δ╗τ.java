package main;

import java.io.Serializable;
import java.util.Map.Entry;

public class 용사 extends 사람{

	용사() {

	}
	
	용사(String name) {
		setName(name);
		Initialize();
	}
	
	public void Initialize() {
		setStatus(new 스탯());
	}

	public int 용사의선택() {
		if(status.getLV() < 5)
		{
			System.out.println("---------------- #tip# -----------------");
			System.out.println("5레벨 이전의 경우 혼자서 수련 하는 것을 추천드립니다.");
			System.out.println("----------------------------------------");
			System.out.println();
		}
		System.out.print("입력해주세요 ( 1. 모험을 계속한다.  2. 정비시간을 갖는다.  3. 저장하기  4. 불러오기  5. 수련을 한다 ");
	
		if (status.getLV() >= 5)
			System.out.print("6. 마왕성으로 간다. ");
		System.out.println(" ) : ");
		
		int c = 시스템.getInputInt();
		System.out.println();

		if (c == 1) {
			System.out.println("모험을 계속한다.\n");
			sleep(1500);
		}
		if(status.getLV() < 5 && c == 6) 	return -1;
		return c;
	}
	
	public int[] 용사의던전선택(boolean is마왕성) {
		int [] imsi = new int[2];
		int lv = getStatus().getLV() / 10;
		int t = 0;
		
		if (is마왕성) {
			System.out.println("마왕성을 발견했다.\n");
			System.out.println("*주의* 입장시 포기 할 수 없습니다. (권장레벨 : 60 이상 )\n");
			t = 5;
		} else {
			if (lv > 4) {
				lv = 4;
				t = lv;
			} else		t = 시스템.getRandInt(lv + 1);
			int idx = 시스템.getmtypeIdx();
			System.out.println(시스템.get샘플몬스터(t * idx).getName() + "던전(난이도 : " + (t + 1) + " )을 발견했다.\n");
			System.out.println("*주의* 입장시 포기 할 수 없습니다. (권장레벨 : " + ((t + 1) * 10) + " )");
		}
		System.out.println("입장하시겠습니까? ( 1. 도전한다  2. 스탯확인  3. 포기한다 ) :");
		int choice = 시스템.getInputInt();

		imsi[0] = choice; imsi[1] = t;
		return imsi;
	}

	public 스킬 용사의스킬선택() {
		boolean flag = true;

		System.out.printf("현재 상태 ( HP : %d(%d) / MP : %d(%d) )\n", status.getHP(), status.getMaxHP(), status.getMP(),
				status.getMaxMP());
		while (flag) {
			보유스킬보기();
			System.out.println("\n사용할 스킬을 입력해주세요 : ( 스킬 사용 취소하려면 x 입력) ");
			String str = 시스템.getInputString();
			if (str.equals("x"))		break;
			스킬 s = 시스템.스킬이름으로_스킬구하기(str);
			if (s == null) {
				System.out.println("잘못입력하셨습니다.\n\n");
				continue;
			}
			if (s.is스킬사용가능레벨(status.getLV()))
			{
				if (s.is스킬사용가능소모값(status.getHP(), status.getMP()))	return s;
				else	System.out.println("체력과 마력을 다시 확인하고 사용해주세요.\n");
			}
			else	System.out.println("레벨 제한으로 해당 스킬을 사용 할 수 없습니다.\n");
		}
		return null;
	}

	/////////////////////////////////////////////
	////////////// 메인 이벤트 처리 ////////////////
	/////////////////////////////////////////////

	public void 전직(시스템.직업종류 직업) {
		if (status.getJob() == 시스템.직업종류.마검사) {
			System.out.println("이미 해당 직업 또는 상위직업을 가지고 있습니다.\n");
			return;
		}

		if (status.getJob() == 시스템.직업종류.일반) {
			status.전직스탯업데이트(직업);
			전직으로인한장착아이템해제();
		} else if (status.getJob() != 직업) {
			System.out.println(status.getJob() + "을 이미 가지고 있어 " + 직업 + "가 아닌 ");
			status.전직스탯업데이트(시스템.직업종류.마검사);
		} else {
			System.out.println("이미 해당 직업 또는 상위직업을 가지고 있습니다.\n");
			return;
		}

		System.out.println(status.getJob() + " 으로 전직하셨습니다.");
		for (int i = 0; i < 시스템.getSkillIdx(); i++)
			getSkill().add(status.getJob().ordinal() * 시스템.getSkillIdx() + i);
	}

	public void 전직으로인한장착아이템해제() {
		for (int i = 0; i < 6; i++) {
			if (getEquip()[i] != -1) {
				아이템 item = 시스템.get샘플아이템(getEquip()[i]);
				if (!해당장비착용가능여부(item)) {
					System.out.println(item.getName() + "은(는) 전직으로 인해 착용이 불가능하게 되어 해제됩니다.");
					아이템개수변경(item.getItemNumber(), 1);
					getStatus().change장비스탯(item.getETypeID(), -item.get물리(), -item.get마법());
				}
			}
		}
	}

	public int 아이템발견(아이템 item, int n) {
		아이템을발견해서기쁨();
		item.발견아이템정보보이기(n);
		System.out.println("\n선택해주세요 ( 1. 획득 , 2. 포기 ) : ");
		int choice = 시스템.getInputInt();
		return choice;
	}

	public void 몬스터처치아이템발견(아이템 item, int n) {
		아이템을발견해서기쁨();
		item.발견아이템정보보이기(n);
	}

	public int 몬스터발견(몬스터 mon) {
		// TODO Auto-generated method stub
		몬스터를발견해서놀람(mon);
		sleep(1500);
		mon.스탯창보기();
		System.out.println("\n선택해주세요 ( 1. 싸운다  0. 도망간다  ) : ");
		int choice = 시스템.getInputInt();
		System.out.println();
		return choice;
	}

	public int 마을발견(시스템.직업종류 직업) {
		if (직업 == 시스템.직업종류.일반) {
			System.out.println("마을을 발견했다!!!");
			System.out.println("\n선택해주세요 ( 1. 마을에 들어간다  2. 그냥 지나간다 ) : ");
		} else {
			System.out.println(직업 + " 마을을 발견했다!!!");
			System.out.println("\n선택해주세요 ( 1. 전직을 한다  2. 전직을 포기한다 ) : ");
		}
		int choice = 시스템.getInputInt();

		return choice;
	}

	public void 온천에서회복한다() {
		// TODO Auto-generated method stub
		System.out.println("마을에서 온천을 발견했다!!\n");
		sleep(1500);
		System.out.println("휴식을 취한다.... 몸이 회복되고 있다.\n");
		sleep(1500);
		System.out.println("피로가 많이 가시는 것 같다.\n");
		sleep(1500);

		int r = 시스템.getRandInt(100) + 50;
		getStatus().휴식으로회복(r);
	}

	public void 마을에서회복한다() {
		// TODO Auto-generated method stub
		System.out.println("휴식을 취한다.... 몸이 회복되고 있다.\n");
		sleep(1500);
		System.out.println("피로가 조금 가시는 것 같다.\n");
		sleep(1500);

		int r = 시스템.getRandInt(50) + 30;
		getStatus().휴식으로회복(r);
	}

	/////////////////////////////////////////////
	/////////////////////////////////////////////
	/////////////////////////////////////////////

	/////////////////////////////////////////////
	/////////////////// 전투 /////////////////////
	/////////////////////////////////////////////

	public void 피격(DMG dmg) {
		// TODO Auto-generated method stub
		int result = 0;
		if (dmg.getDmgType() == 시스템.데미지타입.물리)
			result = dmg.getDmg() - status.get합산물리방어력();
		else
			result = dmg.getDmg() - status.get합산마법방어력();

		if (result <= 0)	
			result = 1;
		
		int hp = status.mHP(result);
		
		if (hp < 0)	
			status.setHP(0);
		
		용사피격음(result);
		
		System.out.printf("%s 가 %d 의 데미지를 입었습니다.  ", getName(), result);
		System.out.printf("%s ( %d / %d )", getName(), status.getHP(), status.getMaxHP());
	}

	public DMG 공격() {
		DMG dmg = new DMG();
		if (status.getJob() == 시스템.직업종류.마법사) {
			dmg.setDmgType(시스템.데미지타입.마법);
			dmg.setDmg(일반공격력_랜덤변동(status.get합산마법공격력()));
		} else {
			dmg.setDmgType(시스템.데미지타입.물리);
			dmg.setDmg(일반공격력_랜덤변동(status.get합산물리공격력()));
		}
		return dmg;
	}

	public DMG 스킬공격(스킬 s) {

		DMG dmg = new DMG();

		dmg.setDmgType(s.getDmgType());
		dmg.setEffectType(시스템.상태이상종류.정상);

		if (s.상태이상확률())
			dmg.setEffectType(s.getEffectType());

		int result = 0;

		if (s.get요구직업() == 시스템.직업종류.마검사)
			result = s.스킬데미지계산((status.get합산마법공격력() + status.get합산마법공격력()) * 2 / 3, status.getLV());
		else if (dmg.getDmgType() == 시스템.데미지타입.물리)
			result = s.스킬데미지계산(status.get합산물리공격력(), status.getLV());
		else
			result = s.스킬데미지계산(status.get합산마법공격력(), status.getLV());

		dmg.setDmg(result);
		status.mHP(s.getConsumHP());
		status.mMP(s.getConsumMP());

		return dmg;
	}
	
	int 일반공격력_랜덤변동(int dmg)
	{
		int range = dmg / 7;
		int rand = 시스템.getRandInt(range);
		int sign = 시스템.getRandInt(2);
		
		if(sign == 0) 	dmg -= rand;
		else 			dmg += rand;
		
		return dmg;
	}
	
	int 스킬공격력_랜덤변동(int dmg)
	{
		int range = dmg / 7;
		int rand = 시스템.getRandInt(range);
		int sign = 시스템.getRandInt(2);
		
		if(sign == 0) 	dmg -= rand;
		else 			dmg += rand;
		
		return dmg;
	}

	public void 몬스터처치(몬스터 mon) {
		// TODO Auto-generated method stub
		System.out.println("\n" + mon.getName() + " 이(가) 쓰러졌습니다.\n");
		double exp = 몬스터처치경험치구하기(mon);
		
		if (exp <= 0)	exp = 0;
		
		getStatus().changeEXP(exp);
		System.out.println("경험치가 " + exp + " 만큼 올랐습니다.\n");
		if (getStatus().is레벨업()) {
			getStatus().레벨업();
			용사스탯창보기();
		}

		if (mon.is몬스터아이템소지()) {
			int n = 시스템.getRandInt(3) + 1;
			몬스터처치아이템발견(mon.getItem(), n);
			몬스터처치아이템획득(mon.getItem().getItemNumber(), n);
		}
		System.out.println("\n<배틀종료>\n");
	}

	public double 몬스터처치경험치구하기(몬스터 mon) {
		double exp = 0;
		if (status.getLV() > mon.getLV())
			exp = mon.getEXP() - (10 * (status.getLV() - mon.getLV()));
		else if (status.getLV() == mon.getLV())
			exp = mon.getEXP() - (5 * status.getLV());
		else
			exp = mon.getEXP() + (5 * (mon.getLV() - status.getLV()));
		return exp;
	}

	public int 용사턴_도망가능() {
		System.out.println();
		System.out.println("선택해주세요 ( 1. 공격  2. 스킬  3. 아이템사용하기  4. 도망  ) : ");
		int choice = 시스템.getInputInt();
		System.out.println();
		return choice;
	}

	public int 용사턴_도망불가능() {
		System.out.println();
		System.out.println("선택해주세요 ( 1. 공격  2. 스킬  3. 생사결  4. 아이템사용하기  ) : ");
		int choice = 시스템.getInputInt();
		System.out.println();
		return choice;
	}

	
	void 용사피격음(int dmg)
	{
		System.out.println("공격을 받은 용사가 외칩니다");
		if( dmg < 10 ) 시스템.효과음("윽");
		else if( dmg < 100 ) 시스템.효과음("으윽");
		else if( dmg < 200 ) 시스템.효과음("@&#*@($");
		else if( dmg < 400 ) 시스템.효과음("@#(@($!)%@*)@#");
	}
	
	/////////////////////////////////////////////
	/////////////////////////////////////////////
	/////////////////////////////////////////////

	/////////////////////////////////////////////
	//////////////// 아이템 및 장비//////////////////
	/////////////////////////////////////////////

	public void 아이템획득(int iNum, int n) {
		if (해당아이템소지여부(iNum)) {
			아이템개수변경(iNum, n);
		} else {
			getInv().put(iNum, n);
		}
		System.out.println();
		System.out.println(시스템.get샘플아이템(iNum).getName() + " 을(를) 획득했다.\n");
	}

	public void 몬스터처치아이템획득(int itemNumber, int n) {
		// TODO Auto-generated method stub
		if (해당아이템소지여부(itemNumber)) {
			아이템개수변경(itemNumber, n);
		} else {
			getInv().put(itemNumber, n);
		}
		System.out.println();
		System.out.println(시스템.get샘플아이템(itemNumber).getName() + " 을(를) 획득했다.\n");
	}

	void 아이템사용하기() {
		인벤토리보기();
		System.out.println("사용하고자 하는 아이템 이름을 입력해주세요 : ");
		String strName = 시스템.getInputString();

		int flag = 0;
		for (아이템 i : 시스템.getItemArr()) {
			if (i.is해당이름아이템(strName)) {
				flag = 1;
				break;
			}
		}
		if (flag == 0) {
			System.out.println("잘못 입력하셨습니다.\n");
			return;
		}

		아이템 item = 시스템.get샘플아이템(strName);

		if (item.is사용가능()) {
			int iNum = item.getItemNumber();
				if (item.is포션아이템()) {
				item.포션아이템사용하기(getStatus());
			} else {

			}
			아이템개수변경(iNum, -1);
		}
	}

	void 장비착용하기() {
		장비인벤토리보기();
		System.out.println("착용하고자 하는 아이템 이름을 입력해주세요 : ");
		String strName;

		strName = 시스템.getInputString();
		if (시스템.isNumber(strName)) {
			System.out.println("잘못입력하셨습니다.");
			return;
		}
		아이템 item = 시스템.get샘플아이템(strName);

		if (item.is장비아이템()) {
			int iNumNow = item.getItemNumber();
			
			if (해당장비착용가능여부(item)) {
				if (is착용중인장비(item.getETypeID())) {
					int iNumPast = getEquip()[item.getETypeID().ordinal()];
					아이템 item2 = 시스템.get샘플아이템(iNumPast);
					아이템개수변경(iNumPast, 1);
					getStatus().change장비스탯(item.getETypeID(), -item2.get물리(), -item2.get마법());
				}
				getEquip()[item.getETypeID().ordinal()] = item.getItemNumber();
				아이템개수변경(iNumNow, -1);
				getStatus().change장비스탯(item.getETypeID(), item.get물리(), item.get마법());
			} else {
				System.out.println("현재 직업으로 착용이 불가능합니다.");
			}
		}
	}

	private boolean 해당장비착용가능여부(아이템 item) {
		// TODO Auto-generated method stub
		if (item.get직업제한() == 시스템.직업종류.일반 || status.getJob() == 시스템.직업종류.마검사)
			return true;
		else if (item.get직업제한() == status.getJob())
			return true;
		else
			return false;
	}

	/////////////////////////////////////////////
	/////////////////////////////////////////////
	/////////////////////////////////////////////

	public void 아이템개수변경(int iNum, int n) {
		if (해당아이템소지여부(iNum)) {
			int imsi = get해당아이템개수(iNum) + n;
			if (imsi == 0)	getInv().remove(iNum);
			else			getInv().put(iNum, imsi);
		} 
		else 			
			getInv().put(iNum, 1);
	
	}

	public void 마왕성중간휴식() {
		while (true) {
			System.out.println("입력해주세요 ( 1. 마왕성 토벌을 계속한다.  2. 정비시간을 갖는다. ) : ");
			int c = 시스템.getInputInt();
			System.out.println();

			if (c == 1) {
				System.out.println("마왕성 토벌을 계속한다.\n");
				sleep(1500);
				return;
			} 
			else if (c == 2) 
				정비시간();
			else 
				System.out.println("잘못 입력하셨습니다.");
		}
	}

	public void 정비시간() {
		System.out.println(getName() + "가 자리에 앉아 정비합니다.");
		System.out.println("정비활동 ( 1. 스탯확인  2. 소지품탭  3. 장비탭 ) : ");
		int c = 시스템.getInputInt();
		switch (c) {
		case 1: // 스탯 확인
			용사스탯창보기();
			break;
		case 2: // 소지품 확인
			아이템탭();
			break;
		case 3: // 장비 착용
			장비탭();
			break;
		}
		System.out.println(getName() + " 이(가) 정비를 마쳤습니다\n");
	}

	public void 용사스탯창보기() {
		스탯창보기();
		착용중인장비보기();
	}

	private void 아이템탭() {
		System.out.println("사용하고자 하는 기능을 입력해주세요 ( 1. 인벤토리보기  2. 아이템사용하기 ) : ");
		int c = 시스템.getInputInt();

		if (c == 1) {
			if (아이템소지여부())	인벤토리보기();
			else				System.out.println("소지품이 없습니다.");
		} 
		else if (c == 2) {
			if (아이템소지여부())	아이템사용하기();
			else				System.out.println("소지품이 없습니다.");
		} 
		else
			System.out.println("잘못입력하셨습니다.");
	}

	private void 장비탭() {
		System.out.println("사용하고자 하는 기능을 입력해주세요 ( 1. 착용중인 장비 보기  2. 장비착용하기 ) : ");
		int c = 시스템.getInputInt();

		if (c == 1)
			착용중인장비보기();
		else if (c == 2)
			장비착용하기();
		else
			System.out.println("잘못입력하셨습니다.");
	}

	private void 착용중인장비보기() {
		// TODO Auto-generated method stub

		System.out.println("-------------< 착용 장비 >------------");

		for (int i = 0; i < 6; i++) {
			if (is착용중인장비(i))
				System.out.print(시스템.장비종류.values()[i] + " : " + 시스템.get샘플아이템(getEquip()[i]).getName() + "\t");
			else
				System.out.print(시스템.장비종류.values()[i] + " : " + "없음\t");
			if (i % 2 == 1)
				System.out.println();
		}
		System.out.println("------------------------------------\n");
	}

	/////////////////////////////////////////////
	///////////// getter & setter ///////////////
	/////////////////////////////////////////////

	public 스탯 get스탯() {
		return getStatus();
	}

	/////////////////////////////////////////////
	////////////////// check ////////////////////
	/////////////////////////////////////////////

	private boolean is착용중인장비(int i) {
		return getEquip()[i] != -1;
	}

	boolean is용사죽음() {
		return getStatus().getHP() <= 0;
	}

	boolean is착용중인장비(시스템.장비종류 etype) {
		return getEquip()[etype.ordinal()] != -1;
	}

	/////////////////////////////////////////////
	////////////////// 기타 //////////////////////
	/////////////////////////////////////////////

	void sleep(int m) {
		try {
			Thread.sleep(m);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/////////////////////////////////////////////
	////////////////// 보기 //////////////////////
	/////////////////////////////////////////////

	public void 보유스킬보기() {
		for (int s : getSkill()) {
			스킬 sSkill = 시스템.get샘플스킬(s);
			if (sSkill.is스킬사용가능직업(status.getJob()) && sSkill.is스킬사용가능레벨(status.getLV()))
				sSkill.스킬정보보기();
		}
	}

	public void 장착장비보기() {
		for (int i = 0; i < 6; i++) {
			if (getEquip()[i] != -1) {
				아이템 item = 시스템.get샘플아이템(getEquip()[i]);
				System.out.println(item.getETypeID() + " : " + item.getName());
			}
		}
	}

	public void 장비인벤토리보기() {
		System.out.println("----------< 장비 >----------");

		for (Entry<Integer, Integer> i : getInv().entrySet()) {
			아이템 item = 시스템.get샘플아이템(i.getKey());
			if (item.getITypeID() == 시스템.아이템종류.장비)
				System.out.println("아이템 : " + item.getName() + "\t\t개수 : " + i.getValue());
		}
		System.out.println("---------------------------");
	}

	public void 인벤토리보기() {
		System.out.println("----------< 소지품 >----------");

		for (Entry<Integer, Integer> i : getInv().entrySet()) {
			System.out.println("아이템 : " + 시스템.get샘플아이템(i.getKey()).getName() + "\t\t개수 : " + i.getValue());
		}

		System.out.println("----------------------------\n ");
	}	

	public boolean is공격가능상태() {
		if (!is정상상태()) {
			상태이상상태();
			if (is상태이상회복())
				정상상태();
		} else
			return true;

		if (status.getEffectType() == 시스템.상태이상종류.마비) {
			int random = 시스템.getRandInt(100) % 3;
			if (random == 2) {
				System.out.println(getName() + " 은(는) 마비상태지만 참아내고 공격합니다.");
				return true;
			} else
				return false;
		} else if (status.getEffectType() == 시스템.상태이상종류.기절) {
			System.out.println(getName() + " 은(는) 기절상태입니다.\n");
			return false;
		} else
			return true;
	}

	
	
	
	/*
	 * public void cheet(int n) { status.레벨업(n); }
	 */

}
