package main;

import java.io.Serializable;
import java.util.HashMap;
import java.util.HashSet;

public class 저장및불러오기 implements Serializable{
	용사 player ;
	private String name;
	private int[] equip = new int[6];
	private HashSet<Integer> skill = new HashSet<Integer>();
	private HashMap<Integer, Integer> inv = new HashMap<Integer, Integer>();
	
	private 시스템.직업종류 job;
	private 시스템.데미지타입 dmgType;
	private 시스템.상태이상종류 effectType;
	private int[] 상태이상지속시간 = new int[5];
	private int maxHP;
	private int maxMP;
	private int HP;
	private int MP;
	private int EXP;
	private int maxEXP;
	private int LV;

	// 공격력 스탯 //
	private int 물리공격력;
	private int 마법공격력;

	// 방어력 스탯 //
	private int 물리방어력;
	private int 마법방어력;

	private int 장비물리공격력;
	private int 장비물리방어력;

	private int 장비마법공격력;
	private int 장비마법방어력;
	
	public 저장및불러오기(용사 player )
	{
		setJob(player.getStatus().getJob());
		setDmgType(player.getStatus().getDmgType());
		setEffectType(player.getStatus().getEffectType());
		set상태이상지속시간(player.getStatus().get상태이상지속시간());
		setMaxHP(player.getStatus().getMaxHP());
		setMaxMP(player.getStatus().getMaxMP());
		setHP(player.getStatus().getHP());
		setMP(player.getStatus().getMP());
		setEXP(player.getStatus().getEXP());
		setMaxEXP(player.getStatus().getMaxEXP());
		setLV(player.getStatus().getLV());

		// 공격력 스탯 //
		set물리공격력(player.getStatus().get물리공격력());
		set마법공격력(player.getStatus().get마법공격력());

		// 방어력 스탯 //
		set물리방어력(player.getStatus().get물리방어력());
		set마법방어력(player.getStatus().get마법방어력());

		set장비물리공격력(player.getStatus().get장비물리공격력());
		set장비물리방어력(player.getStatus().get장비물리방어력());

		set장비마법공격력(player.getStatus().get장비마법공격력());
		set장비마법방어력(player.getStatus().get장비마법방어력());
		
		name = player.getName();
		equip = player.getEquip();
		skill = player.getSkill();
		inv = player.getInv();
	}

	public int getMaxHP() {
		return maxHP;
	}

	public void setMaxHP(int maxHP) {
		this.maxHP = maxHP;
	}

	public int getMaxMP() {
		return maxMP;
	}

	public void setMaxMP(int maxMP) {
		this.maxMP = maxMP;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int[] getEquip() {
		return equip;
	}

	public void setEquip(int[] equip) {
		this.equip = equip;
	}

	public HashSet<Integer> getSkill() {
		return skill;
	}

	public void setSkill(HashSet<Integer> skill) {
		this.skill = skill;
	}

	public HashMap<Integer, Integer> getInv() {
		return inv;
	}

	public void setInv(HashMap<Integer, Integer> inv) {
		this.inv = inv;
	}

	public 시스템.직업종류 getJob() {
		return job;
	}

	public void setJob(시스템.직업종류 job) {
		this.job = job;
	}

	public 시스템.데미지타입 getDmgType() {
		return dmgType;
	}

	public void setDmgType(시스템.데미지타입 dmgType) {
		this.dmgType = dmgType;
	}

	public 시스템.상태이상종류 getEffectType() {
		return effectType;
	}

	public void setEffectType(시스템.상태이상종류 effectType) {
		this.effectType = effectType;
	}

	public int[] get상태이상지속시간() {
		return 상태이상지속시간;
	}

	public void set상태이상지속시간(int[] 상태이상지속시간) {
		this.상태이상지속시간 = 상태이상지속시간;
	}

	public int getHP() {
		return HP;
	}

	public void setHP(int hP) {
		HP = hP;
	}

	public int getMP() {
		return MP;
	}

	public void setMP(int mP) {
		MP = mP;
	}

	public int getEXP() {
		return EXP;
	}

	public void setEXP(int eXP) {
		EXP = eXP;
	}

	public int getMaxEXP() {
		return maxEXP;
	}

	public void setMaxEXP(int maxEXP) {
		this.maxEXP = maxEXP;
	}

	public int getLV() {
		return LV;
	}

	public void setLV(int lV) {
		LV = lV;
	}

	public int get물리공격력() {
		return 물리공격력;
	}

	public void set물리공격력(int 물리공격력) {
		this.물리공격력 = 물리공격력;
	}

	public int get마법공격력() {
		return 마법공격력;
	}

	public void set마법공격력(int 마법공격력) {
		this.마법공격력 = 마법공격력;
	}

	public int get물리방어력() {
		return 물리방어력;
	}

	public void set물리방어력(int 물리방어력) {
		this.물리방어력 = 물리방어력;
	}

	public int get마법방어력() {
		return 마법방어력;
	}

	public void set마법방어력(int 마법방어력) {
		this.마법방어력 = 마법방어력;
	}

	public int get장비물리공격력() {
		return 장비물리공격력;
	}

	public void set장비물리공격력(int 장비물리공격력) {
		this.장비물리공격력 = 장비물리공격력;
	}

	public int get장비물리방어력() {
		return 장비물리방어력;
	}

	public void set장비물리방어력(int 장비물리방어력) {
		this.장비물리방어력 = 장비물리방어력;
	}

	public int get장비마법공격력() {
		return 장비마법공격력;
	}

	public void set장비마법공격력(int 장비마법공격력) {
		this.장비마법공격력 = 장비마법공격력;
	}

	public int get장비마법방어력() {
		return 장비마법방어력;
	}

	public void set장비마법방어력(int 장비마법방어력) {
		this.장비마법방어력 = 장비마법방어력;
	}
	
	//public 용사 get용사() { return player; }
}	
