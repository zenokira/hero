package main;

import java.io.Serializable;

public class Student implements Serializable {
	
	private ss ss1;
	
	
	
	
	
	private String name;
	private int id;
	private String address;
	
	public Student(int id, String name, String add)
	{
		this.setId(id);
		this.setName(name);
		this.setAddress(add);
	}
	public Student(ss a)
	{
		setSs1(a);
		
		this.setId(a.getId());
		this.setName(a.getName());
		this.setAddress(a.getAddress());
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	public ss getSs1() {
		return ss1;
	}
	public void setSs1(ss ss1) {
		this.ss1 = ss1;
	}
}
