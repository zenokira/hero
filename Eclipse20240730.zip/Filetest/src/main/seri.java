package main;

import java.io.*;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Vector;

public class seri {
	static String path = "C:\\Users\\D413\\Desktop\\EclipseClass\\Eclipse20240724\\HeroGame\\test.txt";
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		while(true)
		{
		int i = sc.nextInt();
		
		if( i == 1) Save();
		else if (i == 2 )load();
		else if( i == 3 ) break;
		}
	}

	public static void load() {
		try {
			FileInputStream fis = new FileInputStream(
					new File(path));
			ObjectInputStream ois = new ObjectInputStream(fis);
			Vector v = (Vector) ois.readObject();

			Iterator iter = v.iterator();

			while (iter.hasNext()) {
				Student s = (Student) iter.next();
				System.out.println(s.getSs1().getId() + s.getSs1().getName() + s.getSs1().getAddress());
			}

			System.out.println("성공적으로 마쳤습니다");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void Save() {
		ss ss1 = new ss(2011, "홍길동", "경북 구미시");
		ss ss2 = new ss(2011, "장길산", "서울 도봉구");
		Student s1 = new Student(ss1);
		Student s2 = new Student(ss2);

		Vector v = new Vector();

		v.add(s1);
		v.add(s2);

		try {
			FileOutputStream fos = new FileOutputStream(
					new File(path));
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(v);
			System.out.println("성공적으로 마쳤습니다");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
