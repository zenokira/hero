package main;

public class 몬스터 extends 스탯 implements 상태이상 {
	private String name;
	private int id;
	private 아이템 item;

	몬스터() {

	}

	몬스터(String name, int id, int lv) {
		this.name = name;
		this.id = id;
		this.LV = lv;
	}

	몬스터(몬스터 m) {
		this.name = m.getName();
		this.id = m.getID();
		this.LV = m.getLV();
		item = m.getItem();
	}

	public void 몬스터설정(String name, 아이템 i, int lv) {
		this.name = name;
		this.item = i;
		this.LV = lv;
	}

	boolean is몬스터아이템소지() {
		int rand = 시스템.getRandInt(100);

		if (rand % 10 % 2 == 0)
			return true;
		else
			return false;
	}

	int 몬스터종류생성(int n) {
		return 시스템.getRandInt(n);
	}

	int 몬스터LV생성(int n) {
		return (시스템.getRandInt(5) + n);
	}

	int 몬스터HP생성(int n) {
		return (시스템.getRandInt(n) * 10 + n * 30);
	}

	int 몬스터MP생성(int n) {
		return (시스템.getRandInt(n) * 10 + n * 30 - 15);
	}

	public void 몬스터생성() {

		int rLV = 몬스터LV생성(LV);
		int rHP = 몬스터HP생성(rLV);
		int rMP = 몬스터MP생성(rLV);

		setLV(rLV);
		initHP(rHP);
		initMP(rMP);

		set몬스터공격력(rLV);
		set몬스터방어력(rLV);

		EXP = 몬스터경험치구하기();
	}

	public void 던전보스몬스터생성() {

		int rT = id % 시스템.getmtypeIdx() + id / 시스템.getMonIdx();
		int rLV = 몬스터LV생성(LV + 1) + 3;
		int rHP = 몬스터HP생성(rLV);
		int rMP = 몬스터MP생성(rLV);

		setLV(rLV);
		initHP(rHP);
		initMP(rMP);

		set몬스터공격력(rLV);
		set몬스터방어력(rLV);

		EXP = 몬스터경험치구하기() + 350;
	}

	public void 마족몬스터생성() {
		int rT = id + 시스템.getRandInt(id);
		if (id == 시스템.getmlistIdx() - 1)
			rT += id;

		int rLV = 몬스터LV생성(rT + 1) + 3;
		int rHP = 몬스터HP생성(rLV);
		int rMP = 몬스터MP생성(rLV);

		setLV(rLV);
		initHP(rHP);
		initMP(rMP);

		set몬스터공격력(rLV);
		set몬스터방어력(rLV);

		EXP = 350;
	}

	public int 몬스터경험치구하기() {
		return LV * 20;
	}

	/////////////////////////////////////////////
	///////////// getter & setter ///////////////
	/////////////////////////////////////////////

	public int getID() {
		return id;
	}

	public void setID(int id) {
		this.id = id;
	}

	public void setItem(아이템 item) {
		this.item = new 아이템(item);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void set몬스터공격력(int n) {
		int ad = 시스템.getRandInt(n) + n;
		set물리공격력(ad);
		int ap = 시스템.getRandInt(n) + n;
		set마법공격력(ap);
	}

	public void set몬스터방어력(int n) {
		int ac = 시스템.getRandInt(n) + n;
		set물리방어력(ac);
		int mr = 시스템.getRandInt(n) + n;
		set마법공격력(mr);
	}

	/////////////////////////////////////////////
	/////////////////// 전투 /////////////////////
	/////////////////////////////////////////////
	public void 피격(DMG dmg) {
		// TODO Auto-generated method stub
		int result = 0;
		if (dmg.getDmgType() == 시스템.데미지타입.물리)
			result = dmg.getDmg() - get합산물리방어력();
		else
			result = dmg.getDmg() - get합산마법방어력();

		if (result <= 0)
			result = 1;

		int hp = mHP(result);

		if (hp < 0)
			setHP(0);
		
		몬스터피격음(result);
		System.out.printf("%s 가 %d 의 데미지를 입었습니다.  ", getName(), result);
		System.out.printf("%s ( %d / %d )\n", getName(), getHP(), getMaxHP());
	}

	void 몬스터피격음(int dmg)
	{
		System.out.print(getName() + " : ");
		if( dmg < 10 ) 시스템.효과음("&*");
		else if( dmg < 100 ) 시스템.효과음("&!%$#");
		else if( dmg < 200 ) 시스템.효과음("@&#*@($");
		else if( dmg < 400 ) 시스템.효과음("@#(@($!)%@*)@#");
		
		System.out.println("용사의 공격에 " + getName() + " 가 괴로워합니다.");
	}
	public void 스킬피격(DMG dmg) {
		// TODO Auto-generated method stub
		int result = 0;
		if (dmg.getDmgType() == 시스템.데미지타입.물리)
			result = dmg.getDmg() - get합산물리방어력();
		else
			result = dmg.getDmg() - get합산마법방어력();

		if (result < 0)
			result = 0;

		int hp = mHP(result);

		if (hp < 0)
			setHP(0);

		if (result != 0 && dmg.getEffectType() != 시스템.상태이상종류.정상 && effectType == 시스템.상태이상종류.정상) {
			setEffectType(dmg.getEffectType());
			
			if ( effectType == 시스템.상태이상종류.중독 )		중독();
			else if ( effectType == 시스템.상태이상종류.마비)	마비();
			else if ( effectType == 시스템.상태이상종류.화상)	화상();
			else if ( effectType == 시스템.상태이상종류.기절)	기절();
		}

		System.out.printf("%s 가 %d 의 데미지를 입었습니다.  ", getName(), result);
		System.out.printf("%s ( %d / %d )\n", getName(), getHP(), getMaxHP());
	}

	public DMG 공격() {
		DMG dmg = new DMG();
		dmg.setEffectType(시스템.상태이상종류.정상);
		if (dmgType == 시스템.데미지타입.마법) {
			dmg.setDmgType(시스템.데미지타입.마법);
			dmg.setDmg(일반공격력_랜덤변동(get합산마법공격력()));
		} else {
			dmg.setDmgType(시스템.데미지타입.물리);
			dmg.setDmg(일반공격력_랜덤변동(get합산물리공격력()));
		}
		return dmg;
	}
	
	int 일반공격력_랜덤변동(int dmg)
	{
		int range = dmg / 7;
		if(range == 0 ) range = 1;
		int rand = 시스템.getRandInt(range);
		int sign = 시스템.getRandInt(2);
		
		if(sign == 0) 	dmg -= rand;
		else 			dmg += rand;
		
		return dmg;
	}

	/////////////////////////////////////////////
	////////////////// check ////////////////////
	/////////////////////////////////////////////

	boolean is몬스터죽음() {
		return HP == 0;
	}
	
	public boolean is보스몬스터()
	{
		return getName().equals("마왕");
	}
	
	public boolean is보스몬스터죽음()
	{
		return is보스몬스터() && is몬스터죽음();
	}
	
	public void DOTDmg(시스템.상태이상종류 상태이상)
	{
		int dmg = 20;
		if (getHP() < dmg)
			dmg = getHP();
		mHP(dmg);
		System.out.println();
		if(상태이상 == 시스템.상태이상종류.중독)
			System.out.print(getName() + "은(는) " + dmg + " 의 중독 데미지를 입었다. ");
		else if(상태이상 == 시스템.상태이상종류.화상)
			System.out.print(getName() + "은(는) " + dmg + " 의 화상 데미지를 입었다. ");
		
		System.out.printf("%s ( %d / %d )\n\n", getName(), getHP(), getMaxHP());

	}
	
	
	

	@Override
	public void 중독() {
		// TODO Auto-generated method stub
		System.out.println(getName() + " 이(가) 중독 상태가 됐다!!!");
		setEffectType(시스템.상태이상종류.중독);
	}

	@Override
	public void 기절() {
		System.out.println(getName() + " 이(가) 기절 상태가 됐다!!!");
		setEffectType(시스템.상태이상종류.기절);
	}

	@Override
	public void 화상() {
		System.out.println(getName() + " 이(가) 화상 상태가 됐다!!!");
		setEffectType(시스템.상태이상종류.화상);
	}

	@Override
	public void 마비() {
		System.out.println("마비 상태가 됐다!!!");
		setEffectType(시스템.상태이상종류.마비);
	}

	@Override
	public void 정상() {
		System.out.println(getName() + " 이(가) 정상 상태가 됐다!!!");
		setEffectType(시스템.상태이상종류.정상);
	}

	@Override
	public void 중독상태() {
		DOTDmg(시스템.상태이상종류.중독);
	}

	@Override
	public void 기절상태() {

	}

	@Override
	public void 화상상태() {
		DOTDmg(시스템.상태이상종류.화상);
	}

	@Override
	public void 마비상태() {
		System.out.println();
		System.out.println(getName() + "은(는) 마비상태입니다.");
	}

	@Override
	public void 정상상태() {
		setEffectType(시스템.상태이상종류.정상);
		System.out.println();
		System.out.println(getName() + " 의 상태이상이 풀렸다.");
	}

	@Override
	public boolean is정상상태() {
		return getEffectType() == 시스템.상태이상종류.정상;
	
	}

	public boolean is상태이상회복() {
		return get상태이상지속시간()[getEffectType().ordinal()] == 0;
	}
	@Override
	public void 스탯창보기() {
		System.out.println();
		System.out.printf("%s(%d)\t", getName(), getLV());
		System.out.println("HP : " + getHP() + " / " + getMaxHP());
	}

	public 아이템 getItem() {
		// TODO Auto-generated method stub
		return item;
	}

	
	@Override
	public void 상태이상상태()
	{
		int idx = getEffectType().ordinal();
		get상태이상지속시간()[idx] = ++get상태이상지속시간()[idx] % 4;
		
		if( idx == 1) 		중독상태(); 
		else if(idx == 2) 	화상상태();
		else if(idx == 3) 	기절상태();
		else if(idx == 4) 	마비상태(); 
	}
	
	public boolean is공격가능상태() {
		if (!is정상상태()) {
			상태이상상태();
			if (is상태이상회복())
				정상상태();
		}
		else return true;
	
		if (getEffectType() == 시스템.상태이상종류.마비) {
			int random = 시스템.getRandInt(100) % 3;
			if (random == 2) {
				System.out.println(getName() + " 은(는) 마비상태지만 참아내고 공격합니다.");
				return true;
			} else
				return false;
		} else if (getEffectType() == 시스템.상태이상종류.기절) {
			System.out.println();
			System.out.println(getName() + " 은(는) 기절상태입니다.\n");
			return false;
		} else
			return true;
	}

}