package main;

public class 게임엔딩 extends Exception {
	게임엔딩() {
	}

	public void Ending용사의죽음(용사 Player) {
		System.out.println("\n");
		스토리String(Player.getName() + "(용사) 이(가) 죽어 마왕군이 득세합니다");
		System.out.println("----------< The End >----------");
		System.exit(0);
	}

	private void 스토리String(String str) {
		System.out.println("-" + str + "-");
		sleep(2000);
	}

	private void sleep(int m) {
		try {
			Thread.sleep(m);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
