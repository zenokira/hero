package main;

public class 포션아이템 extends 아이템 {
	private int recovery;
	private int potion_type;
	
	public 포션아이템()
	{
		
	}
		
	public 포션아이템(String n, 시스템.아이템종류 type_id, int count, int type_po, int recovery)
	{
		super(n,type_id,count);
		this.recovery = recovery;
		this.potion_type = type_po;
	}
	
	public void 포션아이템사용하기(스탯 status)
	{
		if ( potion_type == 0 ) 
			status.아이템사용으로회복하기(recovery, 0);
		if ( potion_type == 1 )
			status.아이템사용으로회복하기(0, recovery);
		if ( potion_type == 2 )
			status.아이템사용으로회복하기(recovery, recovery);
		
		count--;
	}
}
