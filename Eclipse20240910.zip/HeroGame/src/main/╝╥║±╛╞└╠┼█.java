package main;

public class 소비아이템 extends 아이템{
	public 소비아이템()
	{
		
	}
		
	public 소비아이템(String n, 시스템.아이템종류 type_id, int count)
	{
		super(n,type_id,count);
	}
}
