package main;

public class 게임엔딩 extends Exception {
	게임엔딩() {
	}

	public int Ending용사의죽음(용사 Player) {
		System.out.println("\n");
		

		시스템.showBoxString("    용사가 죽어 마왕군이 득세합니다","    < The End >");
		
		while (true) {
			System.out.println("다시 시작하시겠습니까? ( 1. 새로시작한다  0. 종료한다 )");
			int choice = 시스템.getInputInt();
			
			if( choice == 1 ||choice == 0) return choice;
			else {
				시스템.missChoice();
			}
		}
	}

	private void 스토리String(String str) {
		System.out.println("-" + str + "-");
		sleep(2000);
	}
	
	private void ColorPrint(String color, String text)
	{
		if(시스템.getColorString(color) != null)
			System.out.println( 시스템.getColorString(color) + text + 시스템.getColorString("exit")      );
	}

	private void sleep(int m) {
		try {
			Thread.sleep(m);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
