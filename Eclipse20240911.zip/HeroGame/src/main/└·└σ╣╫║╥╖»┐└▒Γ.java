
package main;

import java.io.Serializable;
import java.util.HashMap;
import java.util.TreeSet;
import java.util.Vector;

public class 저장및불러오기 extends Exception implements Serializable {
	
	private String name;
	private int[] equip = new int[6];;
	private TreeSet<Integer> skill = new TreeSet<Integer>();
	private HashMap<Integer, Integer> inv = new HashMap<Integer, Integer>();
	private int 허기;
	private int 목마름;
	private boolean 전투여부;
	private int 전투중; // 0 전투x  1 한마리  2 던전  3 마왕성
	private 몬스터[][] mon = new 몬스터[3][10];

	
	private 스탯 status;
		
	저장및불러오기()
	{
		
	}
	
	저장및불러오기(용사 player)
	{
		스탯 _status = player.getStatus();
		set전투여부(false);
		setName(player.getName());
		setEquip(player.getEquip());
		setSkill(player.getSkill());
		setInv(player.getInv());
		set허기(player.get허기());
		set목마름(player.get목마름());
		
		setStatus(player.getStatus());	
	}
	저장및불러오기(용사 player, int _전투중)
	{
		스탯 _status = player.getStatus();
		set전투여부(true);
		set전투중(_전투중);
		setName(player.getName());
		setEquip(player.getEquip());
		setSkill(player.getSkill());
		setInv(player.getInv());
		set허기(player.get허기());
		set목마름(player.get목마름());
		
		setStatus(player.getStatus());	
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int[] getEquip() {
		return equip;
	}

	public void setEquip(int[] equip) {
		this.equip = equip;
	}

	public TreeSet<Integer> getSkill() {
		return skill;
	}

	public void setSkill(TreeSet<Integer> skill) {
		this.skill = skill;
	}

	public HashMap<Integer, Integer> getInv() {
		return inv;
	}

	public void setInv(HashMap<Integer, Integer> inv) {
		this.inv = inv;
	}

	public int get허기() {
		return 허기;
	}

	public void set허기(int 허기) {
		this.허기 = 허기;
	}

	public int get목마름() {
		return 목마름;
	}

	public void set목마름(int 목마름) {
		this.목마름 = 목마름;
	}


	public 스탯 getStatus() {
		return status;
	}


	public void setStatus(스탯 status) {
		this.status = status;
	}

	public boolean is전투여부() {
		return 전투여부;
	}
	public void set전투여부(boolean 전투여부) {
		this.전투여부 = 전투여부;
	}
	public int get전투중() {
		return 전투중;
	}
	public void set전투중(int 전투중) {
		this.전투중 = 전투중;
	}
	public 몬스터[][] getMon() {
		return mon;
	}
	public void setMon(몬스터[][] mon) {
		this.mon = mon;
	}

}
