package main;

import java.util.Collections;
import java.util.HashMap;
import java.util.TreeSet;
import java.util.Vector;
import java.util.Map.Entry;

public class 용사 extends 사람 {

	용사() {
		Initialize();
	}

	용사(String name) {
		setName(name);
		Initialize();
	}

	public void Initialize() {
		setStatus(new 스탯());
	}

	public int 용사의선택() {
		if (status.getLV() < 5) {
			System.out.println("---------------------- #tip# -----------------------");
			System.out.println("5레벨 이전의 경우 혼자서 수련 하는 것을 추천드립니다.");
			System.out.println("15레벨 이전에 마을을 방문할 경우 초보자세트가 지급됩니다.");
			System.out.println("----------------------------------------------------");
			System.out.println();
		}
		System.out.print("입력해주세요 ( 1. 모험을 계속한다  2. 정비시간을 갖는다  3. 저장하기  4. 불러오기  5. 수련을 한다  ");

		if (status.getLV() >= 5)
			System.out.print("6. 마왕성으로 간다  ");
		System.out.println("0. 게임종료 ) : ");

		
		int c = 시스템.getInputInt();
		System.out.println();

		if (c == 1) {
			System.out.println("모험을 계속한다.\n");
			sleep(1500);
		}
		if (status.getLV() < 5 && c == 6)
			return -1;
		return c;
	}

	public int 용사의던전선택() {

		System.out.println("입장하시겠습니까? ( 1. 도전한다  0. 포기한다 ) :");
		int choice = 시스템.getInputInt();

		return choice;
	}

	public int 용사의스킬선택() {
		boolean flag = true;

		
		Vector<String> str = new Vector<String>();
		
		
		시스템.showBoxString("\t\t\t\t# t i p #\t\t\t     ", "\t\t\t불 > 물 > 전기 > 땅 > 바람 > 불\t\t     ");
		시스템.showBoxString(String.format("\t\t현재 상태 ( HP : %3d(%3d) / MP : %3d(%3d) )\t     ", status.getHP(), status.getMaxHP(), status.getMP(),
				status.getMaxMP()));
				
		while (flag) {
			보유스킬보기();
			System.out.println("사용할 스킬의 번호를 입력해주세요  (스킬 사용 취소하려면 0 입력) : ");


			int skill_No = 시스템.getInputInt();
			if (skill_No == 0)
				break;
			if (skill_No == -1 || !(1 <= skill_No && skill_No <= 12) ) {
				시스템.missChoice();
				continue;
			}

			스킬 s = 시스템.get용사샘플스킬(skill_No - 1);
			if (s == null || !is스킬보유(s.getSkillId())) {
				System.out.println("보유중인 스킬이 아니거나 번호를 잘못입력하셨습니다.\n");
				continue;
			}

			if (s.is스킬사용가능레벨(status.getLV())) {
				if (s.is스킬사용가능소모값(status.getHP(), status.getMP()))
					return s.getSkillId();
				else
					System.out.println("체력과 마력을 다시 확인하고 사용해주세요.\n");
			} else
				System.out.println("레벨 제한으로 해당 스킬을 사용 할 수 없습니다.\n");
		}
		return -1;
	}

	/////////////////////////////////////////////
	////////////// 메인 이벤트 처리 ////////////////
	/////////////////////////////////////////////

	public void 전직(시스템.직업종류 직업) {
		if (status.getJob() == 시스템.직업종류.마검사) {
			System.out.println("이미 해당 직업 또는 상위직업을 가지고 있습니다.\n");
			return;
		}

		if (status.getJob() == 시스템.직업종류.일반) {
			status.전직스탯업데이트(직업);
			전직으로인한장착아이템해제();
		} else if (status.getJob() != 직업) {
			System.out.println(status.getJob() + "을 이미 가지고 있어 " + 직업 + "가 아닌 ");
			status.전직스탯업데이트(시스템.직업종류.마검사);
		} else {
			System.out.println("이미 해당 직업 또는 상위직업을 가지고 있습니다.\n");
			return;
		}
		System.out.println(status.getJob() + " 으로 전직하셨습니다.");
		스킬획득();
	}

	void 스킬획득() {
		int lv = status.getLV() / 5;
		if (lv > 3)
			lv = 3;

		if (lv == 0)
			return;

		if (status.getJob() == 시스템.직업종류.마검사) {
			for (int i = 0; i < 시스템.getSkilllistIdx(); i++) {
				if ((i % 3 < lv) && !skill.contains(i)) {
					skill.add(i);
					System.out.println("스킬 " + 시스템.get용사샘플스킬(i).get스킬이름() + " 을(를) 습득하였습니다.");
				}
			}
		} else {
			for (int i = 0; i < lv; i++) {
				if (!skill.contains(i)) {
					skill.add(i);
					System.out.println("스킬 " + 시스템.get용사샘플스킬(i).get스킬이름() + " 을(를) 습득하였습니다.");
				}
			}
			for (int i = 0; i < lv; i++) {
				int n = status.getJob().ordinal() * 시스템.getSkillIdx();
				if (!skill.contains(n + i)) {
					skill.add(n + i);
					System.out.println("스킬 " + 시스템.get용사샘플스킬(n + i).get스킬이름() + " 을(를) 습득하였습니다.");
				}
			}
		}
	}

	public void 전직으로인한장착아이템해제() {
		for (int i = 0; i < 6; i++) {
			if (getEquip(i) != -1) {
				아이템 item = 시스템.get샘플아이템(getEquip(i));
				if (!해당장비착용가능여부(item)) {
					System.out.println(item.getName() + "은(는) 전직으로 인해 착용이 불가능하게 되어 해제됩니다.");
					아이템개수변경(item.getItemNumber(), 1);
					getStatus().change장비스탯(item.getEType(), -item.get물리(), -item.get마법());
				}
			}
		}
	}

	public int 아이템발견(아이템 item, int n) {
		아이템을발견해서기쁨();
		item.발견아이템정보보이기(n);
		System.out.println("\n선택해주세요 ( 1. 획득 , 0. 포기 ) : ");
		int choice = 시스템.getInputInt();
		return choice;
	}

	public void 몬스터처치아이템발견(아이템 item, int n) {
		아이템을발견해서기쁨();
		item.발견아이템정보보이기(n);
	}

	public int 몬스터발견(몬스터 mon) {
		// TODO Auto-generated method stub
		몬스터를발견해서놀람(mon);
		sleep(1500);
		mon.스탯창보기();
		System.out.println("\n선택해주세요 ( 1. 싸운다  0. 도망간다  ) : ");
		int choice = 시스템.getInputInt();
		System.out.println();
		return choice;
	}

	public int 마을발견(시스템.직업종류 직업) {
		if (직업 == 시스템.직업종류.일반) {
			System.out.println("마을을 발견했다!!!");
			System.out.println("\n선택해주세요 ( 1. 마을에 들어간다  0. 그냥 지나간다 ) : ");
		} else {
			System.out.println(직업 + " 마을을 발견했다!!!");
			System.out.println("\n선택해주세요 ( 1. 전직을 한다  0. 전직을 포기한다 ) : ");
		}
		int choice = 시스템.getInputInt();

		return choice;
	}

	public void 온천에서회복한다() {
		// TODO Auto-generated method stub
		System.out.println("마을에서 온천을 발견했다!!\n");
		sleep(1500);
		System.out.println("휴식을 취한다.... 몸이 회복되고 있다.\n");
		sleep(1500);
		System.out.println("피로가 많이 가시는 것 같다.\n");
		sleep(1500);

		int _허기 = get허기();
		int _목마름 = get목마름();

		if (_허기 < 50)
			set허기(0);
		else
			set허기(_허기 - 50);
		if (_목마름 < 50)
			set목마름(0);
		else
			set목마름(_목마름 - 50);

		System.out.println((_허기 - get허기()) + "만큼 허기가, " + (_목마름 - get목마름()) + "의 목마름이 회복되었다.\n");

		int r = 시스템.getRandInt(100) + 50;
		휴식으로회복(r);
	}

	public void 마을에서회복한다() {
		// TODO Auto-generated method stub
		System.out.println("휴식을 취한다.... 몸이 회복되고 있다.\n");
		sleep(1500);
		System.out.println("피로가 조금 가시는 것 같다.\n");
		sleep(1500);

		int _허기 = get허기();
		int _목마름 = get목마름();

		if (_허기 < 30)
			set허기(0);
		else
			set허기(_허기 - 30);
		if (_목마름 < 30)
			set목마름(0);
		else
			set목마름(_목마름 - 30);

		System.out.println((_허기 - get허기()) + "만큼 허기가, " + (_목마름 - get목마름()) + "의 목마름이 회복되었다.\n");

		int r = 시스템.getRandInt(50) + 30;
		휴식으로회복(r);
	}

	/////////////////////////////////////////////
	///////////////////////////////////////////// 4

	/////////////////////////////////////////////

	/////////////////////////////////////////////
	/////////////////// 전투 /////////////////////
	/////////////////////////////////////////////

	public void 피격(DMG dmg) {
		// TODO Auto-generated method stub
		int result = 0;
		if (dmg.getDmgType() == 시스템.데미지타입.물리)
			result = dmg.getDmg() - status.get합산물리방어력();
		else
			result = dmg.getDmg() - status.get합산마법방어력();

		int n = 시스템.상성속성판별(dmg.get속성(), null);

		if (n == 1) {
			System.out.println("유리한 속성으로 공격하였다");
			result = result * 3 / 2;
		} else if (n == -1) {
			System.out.println("불리한 속성으로 공격하였다");
			result = result * 2 / 3;
		}

		if (result <= 0)
			result = 1;

		int hp = status.mHP(result);

		if (hp < 0)
			status.setHP(0);

		용사피격음(result);

		System.out.printf("%s 가 %d 의 데미지를 입었습니다.  ", getName(), result);
		System.out.printf("%s ( %d / %d )\n", getName(), status.getHP(), status.getMaxHP());
	}

	public DMG 공격() {
		DMG dmg = new DMG();
		if (status.getJob() == 시스템.직업종류.마법사) {
			dmg.setDmgType(시스템.데미지타입.마법);
			dmg.setDmg(일반공격력_랜덤변동(status.get합산마법공격력()));
		} else {
			dmg.setDmgType(시스템.데미지타입.물리);
			dmg.setDmg(일반공격력_랜덤변동(status.get합산물리공격력()));
		}
		return dmg;
	}

	public DMG 스킬공격(스킬 s) {

		DMG dmg = new DMG();

		dmg.setDmgType(s.getDmgType());
		dmg.setEffectType(시스템.상태이상종류.정상);
		dmg.set속성(s.get속성());

		if (s.상태이상확률())
			dmg.setEffectType(s.getEffectType());

		int result = 0;

		if (s.get요구직업() == 시스템.직업종류.마검사)
			result = s.스킬데미지계산(status);
		else if (dmg.getDmgType() == 시스템.데미지타입.물리)
			result = s.스킬데미지계산(status);
		else
			result = s.스킬데미지계산(status);

		dmg.setDmg(result);
		status.mHP(s.getConsumHP());
		status.mMP(s.getConsumMP());

		return dmg;
	}

	int 일반공격력_랜덤변동(int dmg) {
		int range = dmg / 7;
		int rand = 시스템.getRandInt(range);
		int sign = 시스템.getRandInt(2);

		if (sign == 0)
			dmg -= rand;
		else
			dmg += rand;

		return dmg;
	}

	int 스킬공격력_랜덤변동(int dmg) {
		int range = dmg / 7;
		int rand = 시스템.getRandInt(range);
		int sign = 시스템.getRandInt(2);

		if (sign == 0)
			dmg -= rand;
		else
			dmg += rand;

		return dmg;
	}

	public void 몬스터처치(몬스터 mon) {
		// TODO Auto-generated method stub
		System.out.println("\n" + mon.getName() + " 이(가) 쓰러졌습니다.\n");
		double exp = 몬스터처치경험치구하기(mon);

		if (exp <= 0)
			exp = 0;

		getStatus().changeEXP(exp);
		System.out.println("경험치가 " + exp + " 만큼 올랐습니다.\n");
		if (getStatus().is레벨업()) {
			boolean flag = getStatus().레벨업();
			if (flag)
				스킬획득();
			용사스탯창보기();
		}

		if (mon.hasItem()) {
			아이템획득(mon.getItem().getItemNumber(), 1);
		}

		System.out.println("\n<배틀종료>\n");
	}

	public double 몬스터처치경험치구하기(몬스터 mon) {
		double exp = 0;
		if (status.getLV() > mon.getLV())
			exp = mon.getEXP() - (10 * (status.getLV() - mon.getLV()));
		else if (status.getLV() == mon.getLV())
			exp = mon.getEXP() - (5 * status.getLV());
		else
			exp = mon.getEXP() + (5 * (mon.getLV() - status.getLV()));
		return exp;
	}

	public int 용사턴_도망가능() {
		System.out.println();
		System.out.println("선택해주세요 ( 1. 공격  2. 스킬  3. 아이템사용하기  4. 도망  ) : ");
		int choice = 시스템.getInputInt();
		System.out.println();
		return choice;
	}

	public int 용사턴_도망불가능() {
		System.out.println();
		System.out.println("선택해주세요 ( 1. 공격  2. 스킬  3. 생사결  4. 아이템사용하기  ) : ");
		int choice = 시스템.getInputInt();
		System.out.println();
		return choice;
	}

	void 용사피격음(int dmg) {
		System.out.print(getName() + "(용사) : ");
		if (dmg < 10)
			시스템.효과음("윽");
		else if (dmg < 100)
			시스템.효과음("으윽");
		else if (dmg < 200)
			시스템.효과음("@&#*@($");
		else if (dmg < 400)
			시스템.효과음("@#(@($!)%@*)@#");

		시스템.sleep(800);
	}

	/////////////////////////////////////////////
	/////////////////////////////////////////////
	/////////////////////////////////////////////

	/////////////////////////////////////////////
	//////////////// 아이템 및 장비//////////////////
	/////////////////////////////////////////////

	public void 아이템획득(int iNum, int n) {
		if (해당아이템소지여부(iNum)) {
			아이템개수변경(iNum, n);
		} else {
			getInv().put(iNum, n);
		}
		System.out.println();
		System.out.println(시스템.get샘플아이템(iNum).getName() + " 을(를) 획득했다.\n");
	}

	public void 아이템획득(int iNum) {
		if (해당아이템소지여부(iNum)) {
			아이템개수변경(iNum, 1);
		} else {
			getInv().put(iNum, 1);
		}
		System.out.println(시스템.get샘플아이템(iNum).getName() + " 을(를) 획득했다.");
	}

	public void 몬스터처치아이템획득(int itemNumber, int n) {
		// TODO Auto-generated method stub
		if (해당아이템소지여부(itemNumber)) {
			아이템개수변경(itemNumber, n);
		} else {
			getInv().put(itemNumber, n);
		}
		System.out.println();
		System.out.println(시스템.get샘플아이템(itemNumber).getName() + " 을(를) 획득했다.\n");
	}

	int 아이템사용하기(boolean _flag) {
		String strName = null;
		boolean flag = false;

		while (true) {
			인벤토리보기(_flag);
			System.out.println("사용하고자 하는 아이템 이름을 입력해주세요 ( 취소하시려면 0 를 입력해주세요 ) : ");
			strName = 시스템.getInputString();

			if (strName.equals("0")) {
				return 0;
			}
			for (아이템 i : 시스템.getItemArr()) {
				if (i.is해당이름아이템(strName)) {
					flag = true;
					break;
				}
			}
			if (flag)	break;
			else 		System.out.println("잘못 입력하셨습니다.\n");
		}

		아이템 item = 시스템.get샘플아이템(strName);

		if (item.is사용가능()) {
			if (item.is포션아이템()) 
			{
				if( !getStatus().is풀컨디션())
				{
					포션사용하기(item.getRecovery(), item.getpType());
				}
				else
				{
					System.out.println("체력과 마나가 모두 가득차 있어 포션을 사용해도 효과가 없습니다.\n");
				}
			} 
			else if (item.is소비아이템()) 
			{
				if (item.is음식())
				{
					음식먹기(item.get음식종류());
				} 
				else if (item.is치료제()) 
				{
					if (is상태이상치료제사용하기(item.get상태이상())) 
					{
						status.setEffectType(시스템.상태이상종류.정상);
						System.out.println(item.get상태이상() + " 이 회복되었습니다.");
					}
					else 
					{
						System.out.println("사용해도 효과가 없습니다.");
						return 1;
					}
				}
			}
			int iNum = item.getItemNumber();
			아이템개수변경(iNum, -1);
		}
		return 1;
	}

	private void 음식먹기(시스템.음식필요종류 음식종류) {
		// TODO Auto-generated method stub
		if (음식종류 == 시스템.음식필요종류.허기) {
			int n = get허기() - 30;
			if (n <= 0)
				n = 0;
			set허기(n);
		} else if (음식종류 == 시스템.음식필요종류.목마름) {
			int n = get목마름() - 30;
			if (n <= 0)
				n = 0;
			set목마름(n);
		}
	}
	
	private void 포션사용하기(int recovery, 시스템.포션종류 type) {

		스탯 s = getStatus();

		int hrecMax = s.getMaxHP() - s.getHP();
		int mrecMax = s.getMaxMP() - s.getMP();
		int hrec = recovery;
		int mrec = recovery;
		
		if ( hrecMax < recovery ) hrec = hrecMax;
		if ( mrecMax < recovery ) mrec = mrecMax;
		
		if (type == 시스템.포션종류.힐링)
		{
			s.setChangeHP(hrec);
			System.out.print("힐링");
		}
		else if (type == 시스템.포션종류.마나)
		{
			s.setChangeMP(hrec);
			System.out.print("마나");
		}
		else if (type == 시스템.포션종류.활력) 
		{
			s.setChangeHP(hrec);
			s.setChangeMP(mrec);
			System.out.print("활력");
		}
		System.out.printf("포션종류를 사용하여 체력이 %d 만큼, 마나가 %d 만큼 회복되었습니다\n\n", hrec, mrec);
	}

	boolean is상태이상치료제사용하기(시스템.상태이상종류 type) {
		return status.getEffectType() == type;
	}

	void 장비착용하기() {
		while (true) {
			착용중인장비보기();
			장비인벤토리보기();
			System.out.println("착용하고자 하는 아이템 번호를 입력해주세요 : ( 0 : 나가기 )");
			int n = 시스템.getInputInt();

			if (n == 0)
				return;

			if (!(시스템.getEquipSIdx() <= n && n < 시스템.getilistIdx())) {
				시스템.missChoice();
				continue;
			}
			아이템 item = 시스템.get샘플아이템(n);
			if (item == null || !is보유장비아이템(item)) {
				시스템.missChoice();
				continue;
			}
			if (item.is장비아이템()) {
				int iNumNow = item.getItemNumber();

				if (해당장비착용가능여부(item)) {
					if (is착용중인장비(item.getEType())) {
						int iNumPast = getEquip(item.getEType().ordinal());
						아이템 item2 = 시스템.get샘플아이템(iNumPast);
						아이템개수변경(iNumPast, 1);
						showUnEquip(item2);
						getStatus().change장비스탯(item.getEType(), -item2.get물리(), -item2.get마법());
					}
					setEquip(item.getEType().ordinal(), item.getItemNumber());
					아이템개수변경(iNumNow, -1);
					showEquip(item);
					getStatus().change장비스탯(item.getEType(), item.get물리(), item.get마법());
				} else {
					System.out.println("현재 직업으로 착용이 불가능합니다.");
				}
			}
		}
	}
	
	private void showUnEquip(아이템 item)
	{
		시스템.ColorPrint("yellow", "┌───────────────────────────────────────┐");
		System.out.print( 시스템.getColorString("yellow") + "│");
		System.out.print(시스템.getColorString("green") + "       장착중이던 아이템을 해제합니다\t\t" + 시스템.getColorString("exit"));
		System.out.println( 시스템.getColorString("yellow") + "│");
		
		System.out.print( 시스템.getColorString("yellow") + "│");
		if(item.getEType() == 시스템.장비종류.무기 )						
			System.out.printf(시스템.getColorString("green") + "물리공격력이 %2d , 마법공격력 %2d 만큼 줄어듭니다\t" + 시스템.getColorString("exit"),item.get물리(), item.get마법());
		else
			System.out.printf(시스템.getColorString("green") + "물리방어력이 %2d , 마법방어력 %2d 만큼 줄어듭니다\t" + 시스템.getColorString("exit"),item.get물리(), item.get마법());

		System.out.println( 시스템.getColorString("yellow") + "│");
		시스템.ColorPrint("yellow", "└───────────────────────────────────────┘");
	}
	
	private void showEquip(아이템 item)
	{
		시스템.ColorPrint("yellow", "┌───────────────────────────────────────┐");
		System.out.print( 시스템.getColorString("yellow") + "│");
		System.out.print(시스템.getColorString("green") + "           아이템을 장착합니다\t\t" + 시스템.getColorString("exit"));
		System.out.println( 시스템.getColorString("yellow") + "│");
		
		System.out.print( 시스템.getColorString("yellow") + "│");
	
		if(item.getEType() == 시스템.장비종류.무기 )						
			System.out.printf(시스템.getColorString("green") + "물리공격력이 %2d , 마법공격력 %2d 만큼 늘어납니다\t" + 시스템.getColorString("exit"),item.get물리(), item.get마법());
		else
			System.out.printf(시스템.getColorString("green") + "물리방어력이 %2d , 마법방어력 %2d 만큼 늘어납니다\t" + 시스템.getColorString("exit"),item.get물리(), item.get마법());

		System.out.println( 시스템.getColorString("yellow") + "│");
		시스템.ColorPrint("yellow", "└───────────────────────────────────────┘");
	}

	private boolean 해당장비착용가능여부(아이템 item) {
		// TODO Auto-generated method stub
		return 해당장비레벨제한여부(item) && 해당장비직업제한여부(item);
	}

	private boolean 해당장비레벨제한여부(아이템 item) {
		// TODO Auto-generated method stub
		return status.getLV() >= item.get제한레벨();
	}

	private boolean 해당장비직업제한여부(아이템 item) {
		// TODO Auto-generated method stub
		if (item.get직업제한() == 시스템.직업종류.일반 || status.getJob() == 시스템.직업종류.마검사)
			return true;
		else if (item.get직업제한() == status.getJob())
			return true;
		else
			return false;
	}

	/////////////////////////////////////////////
	/////////////////////////////////////////////
	/////////////////////////////////////////////

	public void 아이템개수변경(int iNum, int n) {
		if (해당아이템소지여부(iNum)) {
			int imsi = get해당아이템개수(iNum) + n;
			if (imsi == 0)
				getInv().remove(iNum);
			else
				getInv().put(iNum, imsi);
		} else
			getInv().put(iNum, 1);

	}

	public void 마왕성중간휴식() {
		while (true) {
			용사스탯창보기();
			System.out.println("입력해주세요 ( 1. 마왕성 토벌을 계속한다.  2. 정비시간을 갖는다. ) : ");
			int c = 시스템.getInputInt();
			System.out.println();

			if (c == 1) {
				System.out.println("마왕성 토벌을 계속한다.\n");
				sleep(1500);
				return;
			} else if (c == 2)
				정비시간(false);
			else
				System.out.println("잘못 입력하셨습니다.");
		}
	}

	public void 정비시간(boolean flag) {
		System.out.println(getName() + "가 자리에 앉아 정비합니다.\n");
		시스템.sleep(800);

		while (true) {
			용사스탯창보기();
			보유스킬보기();

			System.out.println("정비활동 ( 1. 소지품탭  2. 장비탭  0. 나가기 ) : ");
			int c = 시스템.getInputInt();
			if (c == 1) {
				아이템탭(flag);
			} else if (c == 2) // 장비 착용
			{
				장비탭();
			} else if (c == 0) {
				break;
			} else
				시스템.missChoice();
		}
		System.out.println(getName() + " 이(가) 정비를 마쳤습니다\n");
	}

	public void 용사스탯창보기() {
		스탯창보기();
		착용중인장비보기();
	}

	private void 아이템탭(boolean flag) {

		if (아이템소지여부())
			인벤토리보기(flag);
		else {
			System.out.println("현재 보유중인 소지품이 없습니다.\n");
			return;
		}
		System.out.println("사용하고자 하는 기능을 입력해주세요 ( 1. 아이템사용하기  0. 나가기 ) : ");
		int c = 시스템.getInputInt();

		if (c == 1) {
			아이템사용하기(flag);
		} else if (c == 0) {
			return;
		} else
			시스템.missChoice();
	}

	private void 장비탭() {

		착용중인장비보기();

		System.out.println("사용하고자 하는 기능을 입력해주세요 ( 1. 장비착용하기  2. 장비해제하기  0. 나가기 ) : ");
		int c = 시스템.getInputInt();

		if (c == 1)
			장비착용하기();
		else if (c == 2)
			장비해제하기();
		else if (c == 0)
			return;
		else
			시스템.missChoice();
	}

	private void 장비해제하기() {
		// TODO Auto-generated method stub
		while (true) {
			착용중인장비보기();
			System.out.println("해제하고자 하는 아이템 번호를 입력해주세요 : ( 1.무기 2.갑옷 3.투구 4.장갑 5.방패 6.망토 0.나가기 )");
			int n = 시스템.getInputInt();

			if (n == 0)
				return;

			if (!(1 <= n && n <= 6) || !is착용중인장비(n - 1)) {
				시스템.missChoice();
				continue;
			}
			int iNumPast = getEquip(n - 1);

			아이템 item = 시스템.get샘플아이템(iNumPast);

			아이템개수변경(iNumPast, 1);
			getStatus().change장비스탯(item.getEType(), -item.get물리(), -item.get마법());
			showUnEquip(item);
			setEquip(n - 1, -1);

			System.out.println(item.getName() + "이 해제됩니다.");
		}
	}

	private void 착용중인장비보기() {
		// TODO Auto-generated method stub

		System.out.println("---------------------< 착용 장비 >--------------------");

		for (int i = 0; i < 6; i++) {
			if (is착용중인장비(i))
				System.out.print(시스템.get장비종류(i) + " : " + 시스템.get아이템이름(getEquip(i)) + "\t");
			else
				System.out.print(시스템.get장비종류(i) + " : " + "없음\t");
			if (i % 2 == 1)
				System.out.println();
		}
		System.out.println("----------------------------------------------------");
	}

	/////////////////////////////////////////////
	///////////// getter & setter ///////////////
	/////////////////////////////////////////////

	public 스탯 get스탯() {
		return getStatus();
	}

	/////////////////////////////////////////////
	////////////////// check ////////////////////
	/////////////////////////////////////////////

	private boolean is착용중인장비(int i) {
		return getEquip(i) != -1;
	}

	boolean is용사죽음() {
		return getStatus().getHP() <= 0;
	}

	boolean is착용중인장비(시스템.장비종류 etype) {
		return getEquip(etype.ordinal()) != -1;
	}

	boolean is스킬사용가능컨디션() {
		int minHP = 100;
		int minMP = 100;
		for (int i : skill) {
			int hp = 시스템.get용사샘플스킬(i).getConsumHP();
			if (minHP > hp)
				minHP = hp;
			int mp = 시스템.get용사샘플스킬(i).getConsumMP();
			if (minMP > mp)
				minMP = mp;
		}

		if (status.getHP() > minHP && status.getMP() >= minMP)
			return true;

		return false;
	}
	
	void 휴식으로회복(int recovery) {
		int hp = getStatus().getMaxHP() - getStatus().getHP();
		int mp = getStatus().getMaxMP() - getStatus().getMP();
		int hrec = recovery;
		int mrec = recovery;

		if (hp < recovery)
			hrec = hp;
		if (mp < recovery)
			mrec = mp;

		getStatus().recHP(hrec);
		getStatus().recMP(mrec);

		System.out.println("컨디션이 회복되었다.\n");
		System.out.println(hrec + "의 체력이, " + mrec + "의 마나가 회복되었다.\n");
		System.out.println();
		if (getStatus().is풀컨디션()) {
			System.out.println("완전히 회복했다\n");
			getStatus().현재체력마나상태보기();
		}
	}
	
	/////////////////////////////////////////////
	////////////////// 기타 //////////////////////
	/////////////////////////////////////////////

	void sleep(int m) {
		try {
			Thread.sleep(m);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/////////////////////////////////////////////
	////////////////// 보기 //////////////////////
	/////////////////////////////////////////////

	public void 보유스킬보기() {
		System.out.println("----------------------< 스킬창 >---------------------");
		
		for (int s : getSkill()) {
			스킬 sSkill = 시스템.get용사샘플스킬(s);
			if (sSkill.is스킬사용가능직업(status.getJob()) && sSkill.is스킬사용가능레벨(status.getLV()))
				sSkill.스킬정보보기();
		}
		System.out.println("----------------------------------------------------");
		System.out.println();
	}

	public void 장착장비보기() {
		for (int i = 0; i < 6; i++) {
			if (getEquip(i) != -1) {
				아이템 item = 시스템.get샘플아이템(getEquip(i));
				System.out.println(item.getEType() + " : " + item.getName());
			}
		}
	}

	public void 장비인벤토리보기() {
		System.out.println("-------------------< 소지중인 장비 >-------------------");

		for (Entry<Integer, Integer> i : getInv().entrySet()) {
			아이템 item = 시스템.get샘플아이템(i.getKey());
			if (item.getIType() == 시스템.아이템종류.장비) {
				if (해당장비착용가능여부(item))
					System.out.printf("NO : %2d\t아이템 : %-10s\t레벨제한 : %-2d\t개수 : %d\t\t착용가능 : O\n", item.getItemNumber(),
							item.getName(), item.get제한레벨(), i.getValue());
				else
					System.out.printf("NO : %2d\t아이템 : %-10s\t레벨제한 : %-2d\t개수 : %d\t\t착용가능 : X\n", item.getItemNumber(),
							item.getName(), item.get제한레벨(), i.getValue());
			}

		}
		System.out.println("---------------------------------------------------------------");
	}

	public void 인벤토리보기(boolean flag) {
		if (flag)
			일반인벤토리보기();
		else
			전투용인벤토리보기();
	}

	public void 일반인벤토리보기() {
		System.out.println("----------------------< 소지품 >----------------------");

		for (Entry<Integer, Integer> i : getInv().entrySet()) {
			if (i.getKey() < 시스템.getEquipSIdx()) {
				아이템 item = 시스템.get샘플아이템(i.getKey());
				아이템설명(item, i.getValue());
			}
		}

		System.out.println("----------------------------------------------------\n ");
	}

	public void 아이템설명(아이템 item, int n) {
		System.out.printf("아이템 : %-10s\t개수 : %-3d\t", item.getName(), n);

		if (item.getIType() == 시스템.아이템종류.장비)
			System.out.printf("레벨제한 : %-3d\n", item.get제한레벨());
		else if (item.getIType() == 시스템.아이템종류.포션) {
			System.out.printf("효과 : %d 만큼의 ", item.getRecovery());
			if (item.getpType() == 시스템.포션종류.힐링)
				System.out.println("체력을 회복합니다.");
			else if (item.getpType() == 시스템.포션종류.마나)
				System.out.println("마나를 회복합니다.");
			else if (item.getpType() == 시스템.포션종류.활력)
				System.out.println("체력과 마나를 회복합니다.");
		} else if (item.getIType() == 시스템.아이템종류.소비) {
			System.out.print("효과 : ");
			if (item.getName().equals("물"))
				System.out.println("목마름을 30 회복시켜준다");
			else if (item.getName().equals("육포") || item.getName().equals("감자"))
				System.out.println("허기를 30 회복시켜준다");
			else
				System.out.println(item.getName().replace("치료제", "") + "상태를 치료한다");
		} else
			System.out.println();
	}

	public void 전투용인벤토리보기() {
		System.out.println("----------------------< 소지품 >----------------------");

		for (Entry<Integer, Integer> i : getInv().entrySet()) {
			아이템 item = 시스템.get샘플아이템(i.getKey());
			if (item.getIType() == 시스템.아이템종류.포션) {
				아이템설명(item, i.getValue());
			}
		}
		System.out.println("----------------------------------------------------\n ");
	}

	public boolean is공격가능상태() {
		if (!is정상상태()) {
			상태이상상태();
			if (is상태이상회복())
				정상상태();
		} else
			return true;

		if (status.getEffectType() == 시스템.상태이상종류.마비) {
			int random = 시스템.getRandInt(100) % 3;
			if (random == 2) {
				System.out.println(getName() + " 은(는) 마비상태지만 참아내고 공격합니다.");
				return true;
			} else
				return false;
		} else if (status.getEffectType() == 시스템.상태이상종류.기절) {
			System.out.println(getName() + " 은(는) 기절상태입니다.\n");
			return false;
		} else
			return true;
	}

	public void 스킬피격(DMG dmg) {
		// TODO Auto-generated method stub
		int result = 0;
		if (dmg.getDmgType() == 시스템.데미지타입.물리)
			result = dmg.getDmg() - status.get합산물리방어력();
		else
			result = dmg.getDmg() - status.get합산마법방어력();

		int n = 시스템.상성속성판별(dmg.get속성(), null);

		if (n == 1) {
			System.out.println("유리한 속성으로 공격하였다");
			result = result * 3 / 2;
		} else if (n == -1) {
			System.out.println("불리한 속성으로 공격하였다");
			result = result * 2 / 3;
		}

		if (result <= 0)
			result = 1;

		int hp = status.mHP(result);

		if (hp < 0)
			status.setHP(0);

		if (result != 0 && dmg.getEffectType() != 시스템.상태이상종류.정상 && status.getEffectType() == 시스템.상태이상종류.정상) {
			status.setEffectType(dmg.getEffectType());

			if (status.getEffectType() == 시스템.상태이상종류.중독)
				중독();
			else if (status.getEffectType() == 시스템.상태이상종류.마비)
				마비();
			else if (status.getEffectType() == 시스템.상태이상종류.화상)
				화상();
			else if (status.getEffectType() == 시스템.상태이상종류.기절)
				기절();
		}
		시스템.sleep(800);
		System.out.printf("%s 가 %d 의 데미지를 입었습니다.  ", getName(), result);
		System.out.printf("%s ( %d / %d )\n", getName(), status.getHP(), status.getMaxHP());
	}

	public void set불러오기용사(저장및불러오기 _load) {
		setName(_load.getName());
		setEquip(_load.getEquip());
		setSkill(_load.getSkill());
		setInv(_load.getInv());
		set허기(_load.get허기());
		set목마름(_load.get목마름());

		setStatus(_load.getStatus());
	}

	@Override
	void 인벤토리보기() {
		// TODO Auto-generated method stub

	}

	/*
	 * public void cheet(int n) { status.레벨업(n); }
	 */

}
