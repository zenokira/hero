package main;

import java.util.Arrays;

public class 전투저장 {
	private int 전투중; // 0 전투x  1 한마리  2 던전  3 마왕성
	private 몬스터[][] mon = new 몬스터[3][10];
	
	전투저장()
	{
		
	}
	전투저장(몬스터[][] _mon, int _전투중)
	{
		setEntireMonster(_mon);
		set전투중(_전투중);
	}
	
	public void Clear()
	{
		set전투중(0);
		
		for(int i = 0; i < 3; i++)	Arrays.fill(mon[i], null);
	}
	
	public int get전투중() {
		return 전투중;
	}
	public void set전투중(int 전투중) {
		this.전투중 = 전투중;
	}
	public 몬스터[][] getEntireMonster() {
		return mon;
	}
	public void setEntireMonster(몬스터[][] mon) {
		this.mon = mon;
	}
	
	public 몬스터[] getArrMonster(int i)
	{
		return mon[i];
	}
	public void setArrMonster(몬스터[] _mon, int i)
	{
		mon[i] = _mon;
	}
	
	public 몬스터 getMonster()
	{
		return mon[0][0];
	}
	public void setMonster(몬스터 _mon)
	{
		mon[0][0] = _mon;
	}
	
	public boolean is전투중()
	{
		return ( mon[0][0] != null );
	}
}
