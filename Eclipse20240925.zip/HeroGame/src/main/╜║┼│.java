package main;

public class 스킬 {
	
	private String 스킬이름;
	private int skillId;
	private 시스템.데미지타입 dmgType;
	private 시스템.상태이상종류 effectType;
	private 시스템.속성 속성;
	
	private int dmg;
	
	private int ConsumHP;
	private int ConsumMP;
	
	private int 요구레벨;
	private 시스템.직업종류 요구직업;
	
	스킬()
	{
		
	}
	스킬(스킬 skill)
	{
		스킬이름 = skill.get스킬이름();
		skillId = skill.getSkillId();
		dmg = skill.getDmg();
		ConsumHP = skill.getConsumHP();
		ConsumMP = skill.getConsumMP();
		요구레벨 = skill.getReqLV();
		요구직업 = skill.get요구직업();
		속성 = skill.get속성();
	}
	
	스킬(String name, int id, int LV, 시스템.직업종류 직업, 시스템.상태이상종류 상태이상, 시스템.속성 속성)
	{
		스킬이름 = name;
		setSkillId(id);
		요구레벨 = LV;
		요구직업 = 직업;
		setEffectType(상태이상);
		요구치계산();	
		set속성(속성);
	}
	
	스킬(String name, int id,시스템.상태이상종류 상태이상, 시스템.속성 속성)
	{
		스킬이름 = name;
		setSkillId(id);
		setEffectType(상태이상);
		set속성(속성);
	}
	
	//////////////////////////////////////////////////////////////////
	//////////////////////////// method //////////////////////////////
	//////////////////////////////////////////////////////////////////
	
	public int getDamage()
	{
		return getDmg();
	}
	
	public void 요구치계산()
	{
		if(요구직업 == 시스템.직업종류.마검사)
		{
			ConsumHP = 요구레벨;
			ConsumMP = 요구레벨 * 6;
		}
		else
		{
			ConsumHP = 0;
			ConsumMP = 요구레벨 * 5;
		}
	}
		
	//////////////////////////////////////////////////////////////////
	//////////////////////////// check ///////////////////////////////
	//////////////////////////////////////////////////////////////////
	
	public boolean is스킬사용가능(int hp, int mp, int lv, 시스템.직업종류 job)
	{
		return  ( is스킬사용가능레벨(lv) && is스킬사용가능HP(hp) 
				&& is스킬사용가능MP(mp) && is스킬사용가능직업(job));
	}
	
	public boolean is스킬사용가능레벨(int lv)
	{
		return 요구레벨 <= lv ;
	}
	
	public boolean is스킬사용가능HP(int hp)
	{
		return hp > getConsumHP();
	}
	
	public boolean is스킬사용가능MP(int mp)
	{
		return mp >= getConsumMP();
	}
	
	public boolean is스킬사용가능소모값(int hp, int mp)
	{
		return (is스킬사용가능HP(hp) && is스킬사용가능MP(mp));
	}
	
	public boolean is스킬사용가능직업(시스템.직업종류 job)
	{
		if ( get요구직업() == 시스템.직업종류.일반 || job == 시스템.직업종류.마검사)
			return true;
		else if (get요구직업() == job)
			return true;
		else 
			return false;
	}
	
	public void 스킬정보보기()
	{
		System.out.printf("%2d. %-8s\t", getSkillId() + 1 , get스킬이름());
		if ( 요구직업 == 시스템.직업종류.검사 || 요구직업 == 시스템.직업종류.마검사)
			System.out.printf("( 소모값 : (HP : %2d  MP : %2d ) )\t", getConsumHP() ,getConsumMP());
		else
			System.out.printf("( 소모값 : (MP : %2d ) )\t\t", getConsumMP());
		
		if (get속성() == null )	System.out.println("무속성");
		else					System.out.println(get속성());
	}
	
	public int 스킬데미지계산(스탯 _status)
	{
		int pDmg = _status.get물리공격력() + _status.get마법공격력();
		
		return (dmg+ pDmg / 5 * 2 + _status.getLV());
	}
	public int 스킬데미지계산(int pDmg, int LV)
	{
		return (dmg+ pDmg / 5 * 2 + LV);
	}
	
	public boolean 상태이상확률()
	{
		return ((시스템.getRandInt(100)+1) % 5 == 0);
	}

	
	//////////////////////////////////////////////////////////////////
	//////////////////////// getter && setter ////////////////////////
	//////////////////////////////////////////////////////////////////	
	

	public int getConsumHP() {
		return ConsumHP;
	}
	public void setConsumHP(int consumHP) {
		ConsumHP = consumHP;
	}
	public int getConsumMP() {
		return ConsumMP;
	}
	public void setConsumMP(int consumMP) {
		ConsumMP = consumMP;
	}
	public int getReqLV() {
		return 요구레벨;
	}
	public void setReqLV(int reqLV) {
		this.요구레벨 = reqLV;
	}
	public 시스템.직업종류 get요구직업() {
		return 요구직업;
	}
	public void set요구직업(시스템.직업종류 reqJob) {
		this.요구직업 = reqJob;
	}
	public String get스킬이름() {
		return 스킬이름;
	}
	public void set스킬이름(String 스킬이름) {
		this.스킬이름 = 스킬이름;
	}
	public int getSkillId() {
		return skillId;
	}
	public void setSkillId(int skillId) {
		this.skillId = skillId;
	}
	public 시스템.데미지타입 getDmgType() {
		return dmgType;
	}
	public void setDmgType(시스템.데미지타입 dmgType) {
		this.dmgType = dmgType;
	}
	public int getDmg() {
		return dmg;
	}
	public void setDmg(int dmg) {
		this.dmg = dmg;
	}
	public 시스템.상태이상종류 getEffectType() {
		return effectType;
	}
	public void setEffectType(시스템.상태이상종류 effectType) {
		this.effectType = effectType;
	}
	public 시스템.속성 get속성() {
		return 속성;
	}
	public void set속성(시스템.속성 속성) {
		this.속성 = 속성;
	}
}
