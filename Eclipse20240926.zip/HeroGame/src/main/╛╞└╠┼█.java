package main;

import java.io.Serializable;

import main.시스템.장비종류;

public class 아이템 implements Serializable{
	private String name;
	private 시스템.아이템종류 iType;
	private int itemNumber;

	// ===== 포션 변수 ===== //
	private int recovery;
	private 시스템.포션종류 pType;
	// =================== //

	// ===== 소비 변수 ===== //
	private 시스템.소비종류 cType;
	private 시스템.상태이상종류 상태이상;
	private 시스템.음식필요종류 음식종류;
	
	// =================== //

	// ===== 장비 변수 ===== //
	private 시스템.직업종류 직업제한;
	private 시스템.장비종류 eType; // 장비 종류 ( 무기 or 아머 )
	private int 제한레벨;
	private int 물리; // physical attack
	private int 마법; // magical attack

	// =================== //

	// ===== 기타 변수 ===== //
	// =================== //

	public 아이템() {

	}

	public 아이템(아이템 _i) {
		this.name = _i.getName();
		this.iType = _i.getIType();
		this.itemNumber = _i.getItemNumber();
		
		this.직업제한 = _i.get직업제한();
		this.eType = _i.getEType();
		this.제한레벨 = _i.get제한레벨();
		this.물리 = _i.get물리();
		this.마법 = _i.get마법();
		
		this.recovery = _i.getRecovery();
		this.pType = _i.getpType();
		
	}

	void setEType(장비종류 _eType) {
		// TODO Auto-generated method stub
		eType = _eType;
	}

	// 아이템생성자 //
	public 아이템(String _n, 시스템.아이템종류 _type, int _number) {
		this.name = _n;
		this.iType = _type;
		this.itemNumber = _number;
	}
	
	public boolean contains (String _str)
	{
		return this.name.contains(_str);
	}

	/////////////////////////////////////////////
	///////////// getter & setter ///////////////
	/////////////////////////////////////////////

	public void set물리마법(int _물리, int _마법)
	{
		set물리(_물리); set마법(_마법);
	}
	
	public void set물리(int _물리)
	{
		this.물리 = _물리;
	}
	public void set마법(int _마법)
	{
		this.마법 = _마법;
	}
	
	public int get물리() {
		return 물리;
	}

	public int get마법() {
		return 마법;
	}

	public 아이템 getItem() {
		return this;
	}

	public 시스템.장비종류 getEType() {
		return eType;
	}

	public 시스템.아이템종류 getIType() {
		return iType;
	}

	public void setIType(시스템.아이템종류 _id) {
		iType = _id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String _str) {
		this.name = _str;
	}

	/////////////////////////////////////////////
	////////////////// check ////////////////////
	/////////////////////////////////////////////
	
	public boolean is해당이름아이템(String _name)
	{
		return getName().equals(_name);
	}

	public boolean is사용가능(아이템 _item) {
		시스템.아이템종류 id = _item.getIType();
		return (id == 시스템.아이템종류.소비 || id == 시스템.아이템종류.포션);
	}

	public boolean is사용가능() {
		return (getIType() == 시스템.아이템종류.소비 || getIType() == 시스템.아이템종류.포션);
	}

	public boolean is포션아이템(아이템 _item) {
		return _item.getIType() == 시스템.아이템종류.포션;
	}

	public boolean is포션아이템() {
		return iType == 시스템.아이템종류.포션;
	}
	
	public boolean is소비아이템(아이템 _item) {
		return _item.getIType() == 시스템.아이템종류.소비;
	}

	public boolean is소비아이템() {
		return iType == 시스템.아이템종류.소비;
	}
	
	public boolean is치료제() {
		return cType == 시스템.소비종류.치료제;
	}
	
	public boolean is음식() {
		return cType == 시스템.소비종류.음식;
	}

	public boolean is장비아이템() {
		// TODO Auto-generated method stub
		return iType == 시스템.아이템종류.장비;
	}

	/////////////////////////////////////////////
	///////////////// method ///////////////////
	/////////////////////////////////////////////

	public void 보유아이템정보보이기(int _n) {
		System.out.println("\n아이템 이름 : " + name + "\t보유수량 : " + _n);
	}

	public void 발견아이템정보보이기(int _n) {
		System.out.printf("아이템 이름 : %s \t",name);
		if (getIType() == 시스템.아이템종류.장비) {
			System.out.printf("레벨제한 : %d\t", get제한레벨());
			if (getEType() == 시스템.장비종류.무기)
				System.out.printf("공격력 : %d \t마법공격력 : %d\n", 물리, 마법);
			else
				System.out.printf("방어력 : %d \t마법저항력 : %d\n", 물리, 마법);
		}
		System.out.printf("수량 : %d\n", _n);
	}

	public void 아이템정보보이기(int n) {
		System.out.println("\n아이템 이름 : " + name + "\t수량 : " + n);
	}

	public void 아이템정보보이기() {
		System.out.println("아이템 이름 : " + name);
	}

	// ======= 포션 ======= //
	public void 포션아이템설정(시스템.포션종류 _type_po, int _recovery) {
		this.setRecovery(_recovery);
		this.setpType(_type_po);
	}

	// =================== //

	// ======= 소비 ======= //
	public void 소비아이템설정(시스템.소비종류 _type, 시스템.상태이상종류 _상태이상) 
	{
		this.cType = _type;
		this.set상태이상(_상태이상);
	}
	public void 소비아이템설정(시스템.소비종류 _type, 시스템.음식필요종류 _음식) 
	{
		this.cType = _type;
		this.set음식종류(_음식);
	}
	// =================== //

	// ======= 장비 ======= //
	public void 장비아이템설정(시스템.장비종류 _type, int _phy, int _magic) {
		this.setEType(_type);
		this.물리 = _phy;
		this.마법 = _magic;
	}

	// =================== //

	// ======= 기타 ======= //
	
	public void 기타아이템설정() 
	{

	}
	// =================== //

	@Override
	public String toString() {
		return this.name;
	}

	public int getItemNumber() {
		return itemNumber;
	}

	public void setItemNumber(int _itemNumber) {
		this.itemNumber = _itemNumber;
	}

	public 시스템.직업종류 get직업제한() {
		return 직업제한;
	}

	public void set직업제한(시스템.직업종류 _직업제한) {
		this.직업제한 = _직업제한;
	}

	public 시스템.포션종류 getpType() {
		return pType;
	}

	public void setpType(시스템.포션종류 _pType) {
		this.pType = _pType;
	}

	public int getRecovery() {
		return recovery;
	}

	public void setRecovery(int _recovery) {
		this.recovery = _recovery;
	}

	public int get제한레벨() {
		return 제한레벨;
	}

	public void set제한레벨(int _제한레벨) {
		this.제한레벨 = _제한레벨;
	}

	public 시스템.소비종류 getcType() {
		return cType;
	}

	public void setcType(시스템.소비종류 _cType) {
		this.cType = _cType;
	}

	public 시스템.상태이상종류 get상태이상() {
		return 상태이상;
	}

	public void set상태이상(시스템.상태이상종류 _상태이상) {
		this.상태이상 = _상태이상;
	}

	public 시스템.음식필요종류 get음식종류() {
		return 음식종류;
	}

	public void set음식종류(시스템.음식필요종류 _음식종류) {
		this.음식종류 = _음식종류;
	}
}