package main;

public interface 상태이상 {
	void 독상태가됨();
}
