package main;

import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

public class 시스템 {
	
	시스템() {
		init();
	}
	////////////////////////////////////////////////////////////////
	///////////////////////// 아이템 관련 /////////////////////////////
	////////////////////////////////////////////////////////////////
	static enum 포션종류 { 힐링,마나,활력 }
	static enum 장비종류 { 무기, 갑옷, 투구, 장갑, 방패, 망토 }
	static enum 아이템종류 { 기타, 장비,소비, 포션 }
	
	private static final int typeIdx = 4;
	private static final int itemIdx = 5;
	private static final int ilistIdx = typeIdx * itemIdx;
	private static String[][] strItemList = {
			{"토끼가죽","여우의송곳니","슬라임의방울","고블린의누더기천조각","오크의피"},
			{"단검","롱소드","레이피어","갑옷", "방패"},
			{"숫돌","물","감자","해독제","육포"},
			{"하급힐링포션","하급마나포션","중급힐링포션","중급마나포션","활력포션"}
			};
	
	private static 아이템[] itemArr = new 아이템[ilistIdx];
	//////////////////////////////////////////////////////////////////
	
	
	
	//////////////////////////////////////////////////////////////////
	///////////////////////// 몬스터 관련 ///////////////////////////////
	//////////////////////////////////////////////////////////////////
	private static final int mlistIdx = 6;
	private String [] strMonlist = { "토끼", "여우", "슬라임", "고블린", "오크", "마왕" };

	
	private static 몬스터[] monArr = new 몬스터[mlistIdx];
	
	
	//////////////////////////////////////////////////////////////////

	
	private static Scanner sc = new Scanner(System.in);
	private static Random rand = new Random();
	void init()
	{
		int i = 0;
		기타아이템설정(i++);
		장비아이템설정(i++);
		소비아이템설정(i++);
		포션아이템설정(i++);	
		
		몬스터설정();
	}
		
	private void 몬스터설정() {
		// TODO Auto-generated method stub
		for(int i = 0; i < mlistIdx; i++)
		{
			monArr[i] = new 몬스터(strMonlist[i]);
		}
	}

	void 기타아이템설정(int n)
	{
		for ( int x = 0; x < itemIdx; x++)
		{
			itemArr[n*itemIdx + x] = new 아이템(strItemList[n][x], 아이템종류.values()[n], n * itemIdx + x);
			itemArr[n*itemIdx + x].기타아이템설정();
		}
	}
	void 장비아이템설정(int n)
	{
		int pDmg, mDmg;
		int ac,mr;
				
		pDmg = mDmg = ac = mr = 0;
		
		for ( int x = 0; x < itemIdx; x++)
		{
			itemArr[n*itemIdx+ x] = new 아이템(strItemList[n][x], 아이템종류.values()[n], n * itemIdx + x);
		}
		
		itemArr[n*itemIdx + 0].장비아이템설정(시스템.장비종류.무기, 2, 0);
		itemArr[n*itemIdx + 1].장비아이템설정(시스템.장비종류.무기, 5, 0);
		itemArr[n*itemIdx + 2].장비아이템설정(시스템.장비종류.무기, 9, 0);
		itemArr[n*itemIdx + 3].장비아이템설정(시스템.장비종류.갑옷, 2, 2);
		itemArr[n*itemIdx + 4].장비아이템설정(시스템.장비종류.방패, 2, 2);
		
	}
	void 소비아이템설정(int n)
	{
		for ( int x = 0; x < itemIdx; x++)
		{
			itemArr[n*itemIdx + x] = new 아이템(strItemList[n][x], 아이템종류.values()[n], n * itemIdx + x);
			itemArr[x].소비아이템설정();
		}
	}
	void 포션아이템설정(int n)
	{
		for ( int x = 0; x < itemIdx; x++)
		{
			시스템.포션종류 ptype = 시스템.포션종류.values()[x % 2];
			int rec = 30 * (x % 2) + 1;
			itemArr[n*itemIdx + x] = new 아이템(strItemList[n][x], 아이템종류.values()[n], n * itemIdx + x);
			if ( x == 4) 
			{
				ptype = 시스템.포션종류.활력;
				rec = 30;
			}
			itemArr[n*itemIdx + x].포션아이템설정(ptype,rec);
		}
	}
		
	public static String getInputString() {
		String str = "";
		try {
			str = sc.nextLine();
		} catch (InputMismatchException e) {
			System.out.println("문자를 입력해주세요");
		}
		return str;
	}

	public static int getInputInt() {
		int n = -1;
		try {
			n = sc.nextInt();
		} catch (InputMismatchException e) {
			System.out.println("숫자를 입력해주세요");
		}
		sc.nextLine();
		return n;
	}

	public static int getRandInt(int n) {
		return rand.nextInt(n);
	}
	
	
	public static int 랜덤아이템생성() {
		int n = getRandInt(ilistIdx);
		return n;
	}
	
	public static int 아이템수량생성(int iN)
	{
		int i = iN / itemIdx;
		int r = 5;
		if ( i == 아이템종류.장비.ordinal() ) r = 1;
		else if( i == 아이템종류.포션.ordinal() ) r = 3;
		
		int n = getRandInt(r) + 1;
		
		return n;
	}
	
	public static int getItemidx() {
		return itemIdx;
	}

	public static 아이템 get샘플아이템(int n)
	{
		return itemArr[n];
	}
	public static 몬스터 get샘플몬스터(int n)
	{
		return monArr[n];
	}
	
	public static int get랜덤몬스터()
	{
		return 시스템.getRandInt(mlistIdx);
	}
	
	public static 아이템 get샘플아이템(String str)
	{
		int n = 0;
		for ( ; n < ilistIdx; n++)
			if ( str.equals(strItemList[n/itemIdx][n%itemIdx])) break;
		
		return itemArr[n];
	}
	
	public static int getItemIdx()
	{
		return itemIdx;
	}
	
	public static int getMonIdx()
	{
		return mlistIdx;
	}
}