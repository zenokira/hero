package main;

public class 용사 extends 사람 implements 상태이상, 감정표현 {

	용사() {

	}

	용사(String name) {
		this.name = name;
		Initialize();
	}

	public void Initialize() {
		status = new 스탯();
	}

	public 스탯 get스탯() {
		return status;
	}

	void 스탯창보기() {
		status.스탯창보기();
	}

	public void 용사의모험() {

	}

	void 정비시간() {
		System.out.println(getName() + "가 자리에 앉아 정비합니다.");
		System.out.println("정비활동 ( 1. 스탯확인  2. 소지품확인  3. 소지품사용  4. 장비착용 ) : ");
		int c = 시스템.getInputInt();
		switch (c) {
		case 1: // 스탯 확인
			스탯창보기();
			break;
		case 2: // 소지품 확인
			if (아이템소지여부())
				인벤토리보기();
			else
				System.out.println("소지품이 없습니다.");
			break;
		case 3: // 소지품 사용
			if (아이템소지여부())
				아이템사용하기();
			else
				System.out.println("소지품이 없습니다.");
			break;
		case 4: // 장비 착용
			장비착용하기();
			break;
		}
	}

	public boolean 용사의선택() {
		
		System.out.println("입력해주세요 ( 1. 모험을 계속한다.  2. 정비시간을 갖는다 ) : ");
		int c = 시스템.getInputInt();

		if(c == 1)
		{
			System.out.println("다음 목적지를 향해 걷는다.");
			return true;
		}
		else 
		{
			정비시간();
			return false;
		}
	}

	public void 이벤트발생(int event) {
		
		
		switch (event) {
		case 1: // 아이템 발견
			아이템발견();
			break;
		case 2: // 몬스터 발견
			몬스터발견();
			break;
		case 3: // 마을 발견
			마을발견();
			break;
		case 4: // 던전 발견
			
			
			
			break;
		case 5:
			System.out.println("목적지까지 아무런 이상없이 도착했다.");
			break;
		}
	}

	// 메인 이벤트 처리

	void 아이템발견() {
		int iN = 시스템.랜덤아이템생성();
		int n = 시스템.아이템수량생성(iN);
		아이템을발견해서기쁨();
		아이템 item = 시스템.get샘플아이템(iN);
		item.발견아이템정보보이기(n);
		
		
		System.out.println("\n선택해주세요 ( 1. 획득 , 2. 포기 ) : ");
		int choice = 시스템.getInputInt();

		if (choice == 1)
			아이템획득(iN, n);
		else {
			System.out.println("아이템을 포기했다.");
		}
		System.out.println("\n다시 목적지를 향해 걷는다.");
	}

	public void 몬스터발견() {
		// TODO Auto-generated method stub
		int iN = 시스템.get랜덤몬스터();
		몬스터 mon = 시스템.get샘플몬스터(iN);
		mon.랜덤몬스터생성();

		몬스터를발견해서놀람(mon);
		mon.스탯창보기();

		System.out.println("선택해주세요 ( 1. 싸운다 , 2. 도망간다 ) : ");
		int choice = 시스템.getInputInt();

		if (choice == 1) {
			배틀시작(mon);
		} else {
			System.out.println("싸움을 포기하고 도망쳤다.");
		}
		System.out.println("\n다시 목적지를 향해 걷는다.");
	}
	
	void 마을발견()
	{
		System.out.println("마을을 발견했다!!!");
		System.out.println("\n선택해주세요 ( 1. 휴식을 취한다  2. 그냥 지나간다 ) : ");
		int choice = 시스템.getInputInt();

		if (choice == 1)
		{
			int r = 시스템.getRandInt(100);
		
			if( r % 10 == 5 ) 온천에서회복한다();
			else 			  마을에서회복한다();
		}
		else {
			System.out.println("마을을 그냥 지나쳐다.");
		}
		System.out.println("\n다시 목적지를 향해 걷는다.");
	}

	private void 온천에서회복한다() {
		// TODO Auto-generated method stub
		System.out.println("마을에서 온천을 발견했다!!");
		System.out.println("휴식을 취한다.... 몸이 회복되고 있다.");
		sleep(1500);
		System.out.println("피로가 많이 가시는 것 같다.");
		
		int r = 시스템.getRandInt(100) + 50;
		status.휴식으로회복(r);
	}

	private void 마을에서회복한다() {
		// TODO Auto-generated method stub
		System.out.println("휴식을 취한다.... 몸이 회복되고 있다.");
		sleep(1500);
		System.out.println("피로가 조금 가시는 것 같다.");
		
		int r = 시스템.getRandInt(50) + 30;
		status.휴식으로회복(r);
	}

	/////////////////////////////////////////////////

	// 용사 자체 처리

	void 배틀시작(몬스터 mon) {

		int turn = 1;
		boolean flag = true;

		while (flag) {
			if (turn % 2 == 1)
				flag = 용사턴(mon);
			else
				flag = 몬스터턴(mon);
			turn++;
		}
	}

	boolean 용사턴(몬스터 mon) {
		System.out.println("선택해주세요 ( 1. 공격 , 2. 도망 ) : ");
		int choice = 시스템.getInputInt();
		boolean flag = true;
		switch (choice) {
		case 1:
			용사의공격(mon);
			flag = mon.몬스터죽음여부();
			if (flag) {
				System.out.println(mon.getName() + " 이(가) 쓰러졌습니다.");
				status.레벨업여부(mon);
				System.out.println("\n<배틀종료>\n");
			}
			break;
		case 2:
			System.out.println("성공적으로 도망쳤다");
		}
		return !flag;
	}

	void 용사의공격(몬스터 mon) {
		int dmg = status.물리데미지계산(mon.get합산물리방어력());
		mon.몬스터의피격(dmg);
	}

	boolean 몬스터턴(몬스터 mon) {
		int dmg = mon.몬스터턴(this);

		용사의피격(dmg);

		if (용사죽음여부()) {
			System.out.println(getName() + " 이 쓰러졌습니다. \n<배틀종료>");
			return false;
		}

		return true;
	}

	void 용사의피격(int dmg) {
		int hp = status.mHP(dmg);

		if (hp < 0)
			status.setHP(0);

		System.out.printf("%s 이(가) %d 의 데미지를 받았습니다.  ", getName(), dmg);
		System.out.printf("%s ( %d / %d )\n", getName(), status.getHP(), status.getMaxHP());
	}

	boolean 용사죽음여부() {
		if (status.getHP() <= 0)
			return true;
		else
			return false;
	}

	void 아이템사용하기() {
		인벤토리보기();
		System.out.println("사용하고자 하는 아이템 이름을 입력해주세요 : ");
		String strName = 시스템.getInputString();

		아이템 item = 시스템.get샘플아이템(strName);

		if (item.사용가능여부()) {
			int iNum = item.getItemNumber();
			int n = get해당아이템개수(iNum);

			if (item.포션아이템인지여부()) {
				item.포션아이템사용하기(status);
			} else {

			}
			아이템개수변경(iNum, n - 1);
			}
	}
	
	
	

	void 장비착용하기() {
		장비인벤토리보기();
		System.out.println("착용하고자 하는 아이템 이름을 입력해주세요 : ");
		String strName = 시스템.getInputString();

		아이템 item = 시스템.get샘플아이템(strName);

		if (item.장비아이템인지여부()) {
			int iNumNow = item.getItemNumber();
			int nNow = get해당아이템개수(iNumNow);
			int iNumPast = 0;
			int nPast = 0;

			if (착용중인장비여부(item.getETypeID())) {
				iNumPast = equip[item.getETypeID().ordinal()];
				nPast = get해당아이템개수(iNumPast);
				아이템개수변경(iNumPast, nPast + 1);
			}
			equip[item.getETypeID().ordinal()] = item.getItemNumber();
			아이템개수변경(iNumNow, -1);
			status.set장비스탯(item.getETypeID(), item.get물리());
		}
	}

	boolean 착용중인장비여부(시스템.장비종류 etype) {
		if (equip[etype.ordinal()] != -1)
			return true;
		else
			return false;
	}

	/////////////////////////////////////////////
	void sleep(int m)
	{
		try {
			Thread.sleep(m);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Override
	public void 독상태가됨() {
		// TODO Auto-generated method stub
		System.out.println("독에 당했다!!!");
	}

	@Override
	public void 기쁨() {
		// TODO Auto-generated method stub
		System.out.println("기쁘다");
	}
	public void 아이템을발견해서기쁨() {
		// TODO Auto-generated method stub
		System.out.println("\n아이템을 발견해서 기쁘다!!");
	}
	public void 레벨업기쁨() {
		// TODO Auto-generated method stub
		System.out.println("레벨이 올랐다!!! 기쁘다");
	}


	@Override
	public void 놀람() {
		// TODO Auto-generated method stub
		System.out.println("!!! 놀랐다 !!!");
	}
	public void 몬스터를발견해서놀람(몬스터 mon) {
		// TODO Auto-generated method stub
		System.out.println("갑자기 " + mon.getName() + "이(가) 튀어나왔다!!!");
		
	}
	
	@Override
	public void 황당함() {
		// TODO Auto-generated method stub
		System.out.println("??? 황당하다 ???");
	}
}