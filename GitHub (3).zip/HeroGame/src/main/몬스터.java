package main;

public class 몬스터 extends 스탯 implements 상태이상 {
	private String name;
	private int id;
	private 아이템 item;
	
	
	몬스터() {

	}
	
	몬스터(String name, int id, int lv) {
		this.name = name;
		this.id = id;
		this.LV = lv;
	}
	
	몬스터(몬스터 m) {
		this.name = m.getName();
		this.id = m.getID();
		this.LV = m.LV;
	}
	
	public int getID()
	{
		return id;
	}
	public void setID(int id)
	{
		this.id = id;
	}
	
	public void 몬스터설정(String name, 아이템 i, int lv)
	{
		this.name = name;
		this.item = i;
		this.LV = lv;
	}
	
	public void setItem(아이템 item)
	{
		this.item = new 아이템(item);
	}
	

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void 몬스터생성() {

		int rLV = 몬스터LV생성(LV);
		int rHP = 몬스터HP생성(rLV);
		int rMP = 몬스터MP생성(rLV);

		setLV(rLV);
		initHP(rHP);
		initMP(rMP);
		
		set몬스터공격력(rLV);
		set몬스터방어력(rLV);
	}
	
	public void 던전보스몬스터생성() {

		int rT = id % 시스템.getmtypeIdx() + id / 시스템.getMonIdx();
		int rLV = 몬스터LV생성(rT + 1) + 3;
		int rHP = 몬스터HP생성(rLV);
		int rMP = 몬스터MP생성(rLV);

		setLV(rLV);
		initHP(rHP);
		initMP(rMP);
		
		set몬스터공격력(rLV);
		set몬스터방어력(rLV);
	}


	
	public void set몬스터공격력(int n)
	{
		int ad = 시스템.getRandInt(n) + n;
		set물리공격력(ad);
		int ap = 시스템.getRandInt(n) + n;
		set마법공격력(ap);
	}
	
	public void set몬스터방어력(int n)
	{
		int ac = 시스템.getRandInt(n) + n;
		set물리방어력(ac);
		int mr = 시스템.getRandInt(n) + n;
		set마법공격력(mr);
	}

	int 몬스터종류생성(int n) {
		return 시스템.getRandInt(n);
	}

	int 몬스터LV생성(int n) {
		return (시스템.getRandInt(5) + n);
	}

	int 몬스터HP생성(int n) {
		return (시스템.getRandInt(n) * 10 + n * 30);
	}

	int 몬스터MP생성(int n) {
		return (시스템.getRandInt(n) * 10 + n * 30 - 15);
	}
	
	public int 몬스터턴(용사 hero)
	{
		int choice = 1;
		int dmg = 0;
		switch (choice) {
		case 1:		
			dmg = 몬스터의공격(hero);
			return dmg;
		}
		return 0;
	}
	
	int 몬스터의공격(용사 hero)
	{
		int dmg = 물리데미지계산(hero.get스탯().get합산물리방어력() );
		return dmg;
	}
	
	boolean 몬스터죽음여부()
	{
		if (getHP() == 0 )	return true;
		else				return false;
	}
	
	public void 몬스터의피격(int dmg)
	{
		int hp = mHP(dmg);
		
		if( hp < 0) setHP(0);
				
		System.out.printf("\n%s 에게 %d 의 데미지를 가하였습니다.  ", getName(), dmg);
		System.out.printf("%s ( %d / %d )\n",getName(), getHP(), getMaxHP());
	}
	

	@Override
	public void 독상태가됨() {
		System.out.println();
	}

	@Override
	public void 스탯창보기() {
		System.out.println();
		System.out.printf("%s(%d)\t", getName(), getLV());
		System.out.println("HP : " + getHP() + " / " + getMaxHP());
	}

}