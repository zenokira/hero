package main;

public interface 감정표현 {
	void 기쁨();
	void 아이템을발견해서기쁨();
	void 레벨업기쁨();

	void 놀람();
	void 몬스터를발견해서놀람(몬스터 mon);
	void 황당함();
}
