package main;

public interface 감정표현 {
	void 기쁨();
	void 놀람();
	void 황당함();
}
