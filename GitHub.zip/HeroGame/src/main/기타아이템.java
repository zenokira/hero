package main;

public class 기타아이템 extends 아이템 {
	public 기타아이템()
	{
		
	}
		
	public 기타아이템(String n, 시스템.아이템종류 type_id, int count)
	{
		super(n,type_id,count);
	}
}
