package main;

import java.util.HashMap;
import java.util.Map.Entry;

public abstract class 사람 {
	protected String name;
	protected 스탯 status;
	protected int[] equip = new int[6];

	protected HashMap<Integer, Integer> inv = new HashMap<Integer, Integer>();

	사람() {
		for (int i = 0; i < 6; i++) {
			equip[i] = -1;
		}
	}

	public String getName() {
		return name;
	}

	public boolean 아이템소지여부() {
		if (!inv.isEmpty())
			return true;

		return false;
	}

	public boolean 해당아이템소지여부(int iNum) {
		return inv.containsKey(iNum);
	}

	public int get해당아이템개수(int iNum) {
		return inv.get(iNum);
	}

	public void 아이템개수변경(int iNum, int n) {
		if (해당아이템소지여부(iNum)) {
			int imsi = get해당아이템개수(iNum) + n;

			if (imsi == 0)
				inv.remove(iNum);
			else
				inv.put(iNum, imsi);
		} else {
			inv.put(iNum, 1);
		}
	}

	public void 아이템획득(int iNum, int n) {
		if (해당아이템소지여부(iNum)) {
			아이템개수변경(iNum, n);
		} else {
			inv.put(iNum, n);
		}
		System.out.println();
		System.out.println(시스템.get샘플아이템(iNum).getName() + " 을(를) 획득했다.\n");
	}

	public void 인벤토리보기() {
		System.out.println("----------< 소지품 >----------");

		for (Entry<Integer, Integer> i : inv.entrySet()) {
			System.out.println("아이템 : " + 시스템.get샘플아이템(i.getKey()).getName() + "\t\t개수 : " + i.getValue());
		}

		System.out.println("----------------------------");
	}

	public void 장비인벤토리보기() {
		System.out.println("----------< 장비 >----------");

		for (Entry<Integer, Integer> i : inv.entrySet()) {
			아이템 item = 시스템.get샘플아이템(i.getKey());
			if (item.getITypeID() == 시스템.아이템종류.장비)
				System.out.println("아이템 : " + item.getName() + "\t\t개수 : " + i.getValue());
		}
		System.out.println("---------------------------");
	}
	
	public void 장착장비보기()
	{
		for ( int i = 0; i < 6; i++)
		{
			if ( equip[i] != -1 )
			{
				아이템 item = 시스템.get샘플아이템(equip[i]);
				System.out.println(item.getETypeID() + " : " + item.getName());
			}
		}
	}
}
