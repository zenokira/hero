package main;

import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;
import java.util.Vector;

public class 시스템 {

	시스템() {

	}

	////////////////////////////////////////////////////////////////
	///////////////////////// 아이템 관련 /////////////////////////////
	////////////////////////////////////////////////////////////////

	static enum 속성 {
		불 , 물, 전기, 대지, 바람, 엘리멘탈
	}

	static enum 상태이상종류 {
		정상, 중독, 화상, 기절, 마비
	}

	static enum 포션종류 {
		힐링, 마나, 활력
	}

	static enum 소비종류 {
		치료제, 음식
	}

	static enum 음식필요종류 {
		목마름, 허기
	}

	static enum 데미지타입 {
		물리, 마법
	}

	static enum 직업종류 {
		일반, 검사, 마법사, 마검사
	}

	static enum 장비종류 {
		무기, 갑옷, 투구, 장갑, 방패, 망토
	}

	static enum 아이템종류 {
		기타, 장비, 소비, 포션
	}

	private static final String PATH = System.getProperty("user.dir") + "\\";
	private static final int MiscellaneousSIdx = 0;
	private static final int MiscellaneousIdx = 6;
	private static final int ConsumableSIdx = MiscellaneousSIdx + MiscellaneousIdx; // 6
	private static final int ConsumableIdx = 6;
	private static final int PotionSIdx = ConsumableSIdx + ConsumableIdx; // 12
	private static final int PotionIdx = 10;
	private static final int EquipSIdx = PotionSIdx + PotionIdx; // 22
	private static final int EquipIdx = 32;
	private static final int itemlistIdx = MiscellaneousIdx + ConsumableIdx + PotionIdx + getEquipIdx();
	private static String[] strItemList = { "토끼가죽", "여우의송곳니", "슬라임의방울", "고블린의누더기천조각", "오크의피", "마왕의뿔", "화상치료제", "해독제",
			"마비치료제", "물", "육포", "감자", "하급힐링포션", "하급마나포션", "중급힐링포션", "중급마나포션", "상급힐링포션", "상급마나포션", "하급활력포션", "중급활력포션",
			"상급활력포션", "엘릭서",

			"롱소드", "레이피어", "브로드소드", "강철소드", "미스릴소드", "오리할콘소드", "엘리멘탈소드", "에고소드", 
			"우드완드", "우드스태프", "미스릴완드", "미스릴스태프", "엘리멘탈완드", "엘리멘탈스태프", "에고완드", "에고스태프",
			"가죽갑옷", "가죽투구", "가죽장갑", "가죽방패", "강철갑옷", "강철투구", "강철장갑", "강철방패",
			"미스릴갑옷", "미스릴투구", "미스릴장갑", "미스릴방패", "오리할콘갑옷", "오리할콘투구", "오리할콘장갑", "오리할콘방패" };

	private static 아이템[] itemArr = new 아이템[itemlistIdx];

	//////////////////////////////////////////////////////////////////

	//////////////////////////////////////////////////////////////////
	///////////////////////// 몬스터 관련 ///////////////////////////////
	//////////////////////////////////////////////////////////////////
	private static final int monIdx = 6;
	private static final int montypeIdx = 6;
	private static final int monlistIdx = monIdx * montypeIdx;
	private static String[][] strMonlist = { { "토끼", "산토끼", "숲토끼", "사막토끼", "눈토끼", "토깽이" },
			{ "여우", "갈색여우", "사막여우", "눈여우", "불여우", "구미호" }, { "슬라임", "블루슬라임", "브라운슬라임", "레드슬라임", "늪슬라임", "버블링" },
			{ "고블린", "어린고블린", "늙은고블린", "고블린궁수", "고블린전사", "킹고블린" }, { "오크", "어린오크", "늙은오크", "오크전사", "오크광전사", "오크왕" },
			{ "마족토끼", "마족여우", "마족슬라임", "마족고블린", "마족오크", "마왕" } };

	private static 몬스터[] monArr = new 몬스터[monlistIdx];

	//////////////////////////////////////////////////////////////////

	//////////////////////////////////////////////////////////////////
	////////////////////////// 스킬 관련 ///////////////////////////////
	//////////////////////////////////////////////////////////////////

	private static String[] strSkillList = { "강타", "마구휘두르기", "급소찌르기", "섬광찌르기", "오러베기", "오러블레이드", "윈드커터", "파이어볼",
			"블리자드", "멸화검", "뇌신검", "엘리멘탈소드" };
	private static final int skillIdx = 3;
	private static final int skilltypeIdx = 4;
	private static final int skilllistIdx = skillIdx * skilltypeIdx;
	private static 스킬[] skillArr = new 스킬[skilllistIdx];

	private static String[] strMonSkillList = { "물기", "할퀴기", "체액발사", "휘두르기", "강타", "메테오" };
	private static final int MonSkillIdx = 6;
	private static 스킬[] MonSkillArr = new 스킬[getMonSkillIdx()];

	
	
	//////////////////////////////////////////////////////////////////
	//////////////////////////////////////////////////////////////////
	//////////////////////////////////////////////////////////////////

	private static Scanner sc = new Scanner(System.in);
	private static Random rand = new Random();

	private static 마왕성 devil;

	static public void init() {
		int i = 0;
		init기타아이템설정(i++);
		init장비아이템설정();
		init소비아이템설정(i++);
		init포션아이템설정(i++);

		init몬스터설정();
		init용사스킬설정();
		init몬스터스킬설정();
		devil = new 마왕성();
	}

	////////////////////////////////////////////////////////
	/////////////////////// 시스템 //////////////////////////
	////////////////////////////////////////////////////////

	public static String getInputString() {
		String str = "";
		try {
			str = sc.nextLine();
		} catch (InputMismatchException e) {
			System.out.println("문자를 입력해주세요");
		}
		return str;
	}

	public static int getInputInt() {
		int n = -1;
		try {
			n = sc.nextInt();
		} catch (InputMismatchException e) {
			System.out.println("숫자를 입력해주세요");
		}
		sc.nextLine();
		return n;
	}

	public static int getRandInt(int n) {
		return rand.nextInt(n);
	}

	public static boolean isNumber(String strValue) {
		return strValue != null && strValue.matches("[-+]?\\d*\\.?\\d+");
	}

	////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////

	////////////////////////////////////////////////////////
	/////////////////////// 아이템 //////////////////////////
	////////////////////////////////////////////////////////

	static void init기타아이템설정(int n) {
		for (int i = MiscellaneousSIdx; i < MiscellaneousIdx; ++i) {
			itemArr[i] = new 아이템(strItemList[i], 아이템종류.기타, i);
			itemArr[i].기타아이템설정();
		}
	}

	static void init소비아이템설정(int n) {

		for (int i = ConsumableSIdx, j = 0; i < ConsumableSIdx + ConsumableIdx; ++i, ++j) {
			itemArr[i] = new 아이템(strItemList[i], 아이템종류.소비, i);
		}

		int idx = ConsumableSIdx;

		itemArr[idx].소비아이템설정(시스템.소비종류.치료제, 시스템.상태이상종류.중독);
		++idx;
		itemArr[idx].소비아이템설정(시스템.소비종류.치료제, 시스템.상태이상종류.화상);
		++idx;
		itemArr[idx].소비아이템설정(시스템.소비종류.치료제, 시스템.상태이상종류.마비);
		++idx;
		itemArr[idx].소비아이템설정(시스템.소비종류.음식, 시스템.음식필요종류.목마름);
		++idx;
		itemArr[idx].소비아이템설정(시스템.소비종류.음식, 시스템.음식필요종류.허기);
		++idx;
		itemArr[idx].소비아이템설정(시스템.소비종류.음식, 시스템.음식필요종류.허기);
		++idx;

	}

	static void init포션아이템설정(int n) {
		for (int i = PotionSIdx; i < PotionSIdx + PotionIdx; i++) {
			시스템.포션종류 ptype = get포션종류(i % 2);
			itemArr[i] = new 아이템(strItemList[i], 아이템종류.포션, i);
			if (itemArr[i].getName().contains("활력") || itemArr[i].getName().contains("엘릭서"))
				ptype = 시스템.포션종류.활력;
			itemArr[i].setpType(ptype);
			;
		}
		int i = 0;
		int rec = 50;

		for (int x = 0; x < 3; x++) {
			itemArr[PotionSIdx + i].setRecovery(30 + x * rec);
			itemArr[PotionSIdx + i + 1].setRecovery(30 + x * rec);
			i += 2;
		}

		for (int x = 0; x < 3; x++) {
			itemArr[PotionSIdx + 6 + x].setRecovery(40 * x * rec);
		}

		itemArr[PotionSIdx + PotionSIdx - 1].setRecovery(250);
	}

	static void init장비아이템설정() {
		for (int i = getEquipSIdx(); i < getEquipSIdx() + getEquipIdx(); i++) {
			itemArr[i] = new 아이템(strItemList[i], 아이템종류.장비, i);
			itemArr[i].set직업제한(직업종류.일반);
		}

		int quadIdx = getEquipIdx() / 4;
		int halfIdx = getEquipIdx() / 2;
		// 공격력 및 방어력 셋팅
		for (int i = 0; i < quadIdx; i++)
			itemArr[getEquipSIdx() + i].set물리마법(7 + i * 3, 0);
		for (int i = 0; i < quadIdx; i++)
			itemArr[getEquipSIdx() + quadIdx + i].set물리마법(2, 7 + i * 3);

		for (int i = 0; i < halfIdx; i++) {
			if (i % 4 == 0)
				itemArr[getEquipSIdx() + halfIdx + i].set물리마법(5 + (i / 4) * 3, 2 + i / 4);
			else
				itemArr[getEquipSIdx() + halfIdx + i].set물리마법(2 + (i / 4) * 2, 2 + i / 4);
		}

		// 장비종류설정
		for (int i = getEquipSIdx(); i < getEquipIdx() + halfIdx; i++)
			itemArr[i].setEType(시스템.장비종류.무기);

		for (int i = getEquipSIdx() + halfIdx; i < getEquipSIdx() + getEquipIdx(); i++)
			itemArr[i].setEType(get장비종류((i + 2) % 4 + 1));

		// 직업제한설정
		for (int i = getEquipSIdx() + 2; i < quadIdx; i++)
			itemArr[i].set직업제한(직업종류.검사);

		for (int i = getEquipSIdx() + quadIdx; i < getEquipSIdx() + halfIdx; i++)
			itemArr[i].set직업제한(직업종류.마법사);

		for (int i = 0; i < halfIdx; i++) {
			itemArr[getEquipSIdx() + i].set제한레벨((i % 8) * 9);
		}
		for (int i = 0; i < halfIdx; i++) {
			itemArr[getEquipSIdx() + halfIdx + i].set제한레벨((i / 4) * 12);
		}
	}

	public static int 랜덤아이템생성(용사 player) {
		int rand =  getRandInt(3);
		int n = 0;

		if (rand == 0)
			n = getRandInt(ConsumableIdx) + ConsumableSIdx;
		else if (rand == 1)
			n = getRandInt(PotionIdx) + PotionSIdx;
		else if (rand == 2) {
			int r = getRandInt(2);
			int i = 1;
			if (r == 0) // 방어구
			{
				i = _장비아이템가중치_(player.get스탯().getLV(), true);
				n = getRandInt(4) + (i * 4) + getEquipSIdx() + (getEquipIdx() / 2);
			} else // 무기
			{
				i = _장비아이템가중치_(player.get스탯().getLV(), false);
				n = getRandInt(2) * 8 + i + getEquipSIdx();
			}
		}

		return n;
	}

	static int _장비아이템가중치_(int _LV, boolean b) {
		if (b)
			return 장비아이템가중치_1(_LV); // 방어구
		else
			return 장비아이템가중치_2(_LV); // 무기
	}

	static int 장비아이템가중치_1(int _LV) {
		int lv = _LV / 12;
		int n = 시스템.getRandInt(100) + 1;

		if (0 < n && n <= 70)
			return lv % 4;
		else if (70 < n && n <= 80)
			return (lv + 1) % 4;
		else if (80 < n && n <= 90)
			return (lv + 2) % 4;
		else if (90 < n && n <= 100)
			return (lv + 3) % 4;
		return 0;
	}

	static int 장비아이템가중치_2(int _LV) {
		int lv = _LV / 12;
		int n = 시스템.getRandInt(100) + 1;

		if (0 < n && n <= 70)
			return lv % 8;
		else if (lv % 8 != n % 8)
			return n % 8;

		return lv / 8;
	}

	public static int 아이템수량생성(아이템종류 type) {

		int r = 5;
		if (type == 아이템종류.장비)
			r = 1;
		else if (type == 아이템종류.포션)
			r = 3;

		int n = getRandInt(r) + 1;

		return n;
	}

	public static int getilistIdx() {
		return itemlistIdx;
	}

	public static 아이템 get샘플아이템(int n) {
		return itemArr[n];
	}

	public static 아이템 get샘플아이템(String str) {
		for (int n = 0; n < itemlistIdx; n++)
			if (str.equals(strItemList[n]))
				return itemArr[n];
		return null;
	}

	public static 직업종류 get직업종류(int i) {
		return 시스템.직업종류.values()[i];
	}

	public static 장비종류 get장비종류(int i) {
		return 시스템.장비종류.values()[i];
	}

	static 포션종류 get포션종류(int idx) {
		return 시스템.포션종류.values()[idx];
	}

	public static String get아이템이름(int i) {
		return itemArr[i].getName();
	}

	////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////

	////////////////////////////////////////////////////////
	/////////////////////// 몬스터 //////////////////////////
	///////////////////////////////////////////////////////

	public static int getmlistIdx() {
		return monlistIdx;
	}

	public static int getMonIdx() {
		return monIdx;
	}

	public static int getmtypeIdx() {
		return montypeIdx;
	}

	public static 몬스터 get샘플몬스터(int n) {
		return new 몬스터(monArr[n]);
	}

	public static int get랜덤몬스터종류() {
		return 시스템.getRandInt(montypeIdx - 1);
	}

	public static int get랜덤몬스터() {
		return 시스템.getRandInt(monIdx - 1);
	}

	static void init몬스터설정() {
		// TODO Auto-generated method stub
		for (int i = 0; i < monlistIdx; i++) {
			int lv = (i / montypeIdx * 10) + (i % montypeIdx) + 3;
			if (i % monIdx == 5)
				lv = i + 3;
			monArr[i] = new 몬스터(strMonlist[i / monIdx][i % monIdx], i, lv, i / getMonSkillIdx());
			monArr[i].setItem(itemArr[i / montypeIdx]);
		}
		
		monArr[2].set속성(속성.바람);	// 숲토끼
		monArr[3].set속성(속성.대지);	// 사막토끼
		monArr[4].set속성(속성.물);	// 눈토끼
		monArr[8].set속성(속성.대지);	// 사막여우
		monArr[9].set속성(속성.물);	// 눈여우
		monArr[10].set속성(속성.불);	// 불여우
		monArr[13].set속성(속성.물);	// 블루슬라임
		monArr[14].set속성(속성.대지); // 브라운슬라임
		monArr[15].set속성(속성.불);	// 레드슬라임
		monArr[35].set속성(속성.불);	// 마왕
		
		monArr[30].set스킬(0);
		monArr[31].set스킬(1);
		monArr[32].set스킬(2);
		monArr[33].set스킬(3);
		monArr[34].set스킬(4);
		
		
		
		
		
		
	}

	////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////

	////////////////////////////////////////////////////////
	///////////////////////// 스킬 //////////////////////////
	////////////////////////////////////////////////////////

	static void init몬스터스킬설정() {
		for (int x = 0; x < getMonSkillIdx(); x++) {
			MonSkillArr[x] = new 스킬(strMonSkillList[x], x, 상태이상종류.정상, null);
		}
		
		MonSkillArr[4].setEffectType(상태이상종류.기절); 
		MonSkillArr[5].setEffectType(상태이상종류.화상); MonSkillArr[5].set속성(속성.불);
	}
	
	
	
	
	
	
	
	
	static void init용사스킬설정() {
		for (int x = 0; x < getSkilllistIdx(); x++) {
			skillArr[x] = new 스킬(strSkillList[x], x, ((x % 3) + 1) * 5, get직업종류(x / getSkillIdx()), 상태이상종류.정상, null);
		}
		for (int i = 0; i < 6; i++) {
			skillArr[i / getSkillIdx() + i % getSkillIdx()].setDmgType(데미지타입.물리);
		}
		for (int i = 6; i < 12; i++) {
			skillArr[i / getSkillIdx() + i % getSkillIdx()].setDmgType(데미지타입.마법);
		}
		int i = 0;
		//////////////////////////// 일반 스킬 /////////////////////////////////
		skillArr[i].setEffectType(상태이상종류.기절);
		skillArr[i].setDmg(20);
		i++;
		skillArr[i].setEffectType(상태이상종류.정상);
		skillArr[i].setDmg(40);
		i++;
		skillArr[i].setEffectType(상태이상종류.정상);
		skillArr[i].setDmg(60);
		i++;

		//////////////////////////// 검사 스킬 /////////////////////////////////
		skillArr[i].setEffectType(상태이상종류.정상);
		skillArr[i].setDmg(30);
		i++;
		skillArr[i].setEffectType(상태이상종류.정상);
		skillArr[i].setDmg(70);
		i++;
		skillArr[i].setEffectType(상태이상종류.정상);
		skillArr[i].set속성(속성.엘리멘탈);
		skillArr[i].setDmg(120);
		i++;

		//////////////////////////// 마법사 스킬 /////////////////////////////////
		skillArr[i].setEffectType(상태이상종류.정상);
		skillArr[i].set속성(속성.바람);
		skillArr[i].setDmg(40);
		i++;
		skillArr[i].setEffectType(상태이상종류.화상);
		skillArr[i].set속성(속성.불);
		skillArr[i].setDmg(80);
		i++;
		skillArr[i].setEffectType(상태이상종류.정상);
		skillArr[i].set속성(속성.물);
		skillArr[i].setDmg(120);
		i++;

		/////////////////////////// 마검사용 스킬 ////////////////////////////////
		skillArr[i].setEffectType(상태이상종류.화상);
		skillArr[i].set속성(속성.불);
		skillArr[i].setDmg(60);
		i++;
		skillArr[i].setEffectType(상태이상종류.마비);
		skillArr[i].set속성(속성.전기);
		skillArr[i].setDmg(100);
		i++;
		skillArr[i].setEffectType(상태이상종류.정상);
		skillArr[i].set속성(속성.엘리멘탈);
		skillArr[i].setDmg(200);
		i++;
	}
	
	public static int 상성속성판별(속성 src , 속성 dst )
	{
		if(dst == 속성.엘리멘탈)
		{
			if(src == 속성.엘리멘탈 || src == null) 	return 0;
			else								  	return -1;
		}
		
		if( src == 속성.엘리멘탈 )
		{
			if(dst != null ) 	return 1;
		}
		else if (src == null || dst == null) return 0;
		else if( src == 속성.불 && dst == 속성.바람) return 1;
		else if( src == 속성.바람 && dst == 속성.불) return -1;
		else if( src.ordinal() == dst.ordinal()-1) return -1;
		else if( src.ordinal() == dst.ordinal()+1) return 1;
		
		return 0;
	}

	public static 스킬 스킬이름으로_스킬구하기(String name) {
		for (스킬 s : skillArr) {
			if (s.get스킬이름().equals(name))
				return s;
		}
		return null;
	}

	public static boolean 마왕죽음여부(몬스터[] mon) {
		for (몬스터 m : mon) {
			if (m.getName().equals("마왕"))
				return devil.마왕죽음여부();
		}
		return false;
	}

	public static void missChoice(String s) {
		System.out.println("잘못입력하셨습니다." + s);
	}

	public static void missChoice() {
		System.out.println("잘못입력하셨습니다.");
	}

	////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////

	////////////////////////////////////////////////////////
	//////////////////////// 마왕성 /////////////////////////
	////////////////////////////////////////////////////////

	public static 마왕성 get마왕성() {
		return devil;
	}

	public static int getSkillIdx() {
		return skillIdx;
	}

	public static int getSkilltypeIdx() {
		return skilltypeIdx;
	}

	public static int getSkilllistIdx() {
		return skilllistIdx;
	}

	public static 스킬 get용사샘플스킬(int n) {
		return skillArr[n];
	}
	
	public static 스킬 get몬스터샘플스킬(int n) {
		return MonSkillArr[n];
	}

	public static 아이템[] getItemArr() {
		return itemArr;
	}

	public static void setItemArr(아이템[] itemArr) {
		시스템.itemArr = itemArr;
	}

	public static String getPath() {
		return PATH;
	}

	public static void 효과음(String str) {
		System.out.println("@" + str + "@");
	}
	////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////

	public static int getMonSkillIdx() {
		return MonSkillIdx;
	}

	public static String[] getStrMonSkillList() {
		return strMonSkillList;
	}

	public static void setStrMonSkillList(String[] strMonSkillList) {
		시스템.strMonSkillList = strMonSkillList;
	}

	public static 스킬[] getMonSkillArr() {
		return MonSkillArr;
	}

	public static void setMonSkillArr(스킬[] monSkillArr) {
		MonSkillArr = monSkillArr;
	}

	public static int getEquipSIdx() {
		return EquipSIdx;
	}

	public static int getEquipIdx() {
		return EquipIdx;
	}
}

class 마왕성 {
	Vector<몬스터>[] devil_monster;

	마왕성() {
		init();
	}

	void init() {
		int nR = 시스템.getRandInt(10) + 1;
		int hR = 시스템.getRandInt(10) + 1;
		devil_monster = new Vector[3];

		for (int i = 0; i < 3; i++)
			devil_monster[i] = new Vector<몬스터>();

		for (int i = 0; i < nR; i++) {
			int nRsam = 시스템.getRandInt(시스템.getmlistIdx() - 시스템.getMonIdx());
			devil_monster[0].add(new 몬스터(시스템.get샘플몬스터(nRsam)));
			devil_monster[0].get(i).몬스터생성();
		}

		for (int i = 0; i < hR; i++) {
			int hRsam = 시스템.getRandInt(시스템.getMonIdx() - 1);
			devil_monster[1].add(new 몬스터(시스템.get샘플몬스터(시스템.getmlistIdx() - 시스템.getMonIdx() + hRsam)));
			devil_monster[1].get(i).마족몬스터생성();
		}

		devil_monster[2].add(new 몬스터(시스템.get샘플몬스터(시스템.getmlistIdx() - 1)));
		devil_monster[2].get(0).마족몬스터생성();
	}

	public 몬스터 get보스몬스터() {
		return devil_monster[2].get(0);
	}

	public 몬스터[] get몬스터부대(int i) {
		몬스터[] mon = new 몬스터[devil_monster[i].size()];
		mon = (몬스터[]) devil_monster[i].toArray(mon);
		return mon;
	}

	public 마왕성 get마왕성() {
		return this;
	}

	public boolean 마왕죽음여부() {
		return devil_monster[2].get(0).is몬스터죽음();
	}

}

class DMG {
	private 시스템.데미지타입 dmgType;
	private 시스템.상태이상종류 effectType;
	private 시스템.속성 속성;
	private int dmg;

	public 시스템.상태이상종류 getEffectType() {
		return effectType;
	}

	public void setEffectType(시스템.상태이상종류 상태이상) {
		this.effectType = 상태이상;
	}

	public 시스템.데미지타입 getDmgType() {
		return dmgType;
	}

	public void setDmgType(시스템.데미지타입 dmgType) {
		this.dmgType = dmgType;
	}

	public int getDmg() {
		return dmg;
	}

	public void setDmg(int dmg) {
		this.dmg = dmg;
	}

	public 시스템.속성 get속성() {
		return 속성;
	}

	public void set속성(시스템.속성 속성) {
		this.속성 = 속성;
	}
};
