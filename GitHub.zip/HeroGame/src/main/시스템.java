package main;

import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

public class 시스템 {
	
	시스템() {
		init();
	}
	
	static enum 포션종류 { 힐링,마나,활력 }
	static enum 아이템종류 { 기타, 장비,소비, 포션 }
	private static Random rand = new Random();
	private static final int typeIdx = 4;
	private static final int itemIdx = 5;
	private static final int listIdx = typeIdx * itemIdx;
	private static String[][] strList = {
			{"고구마씨앗","싹이난감자","슬라임의방울","토끼가죽","여우의송곳니"},
			{"단검","롱소드","레이피어","방패","갑옷"},
			{"숫돌","물","감자","해독제","육포"},
			{"하급힐링포션","하급마나포션","중급힐링포션","중급마나포션","활력포션"}
			};
	
	private static 아이템[] itemArr = new 아이템[listIdx];
	private static Scanner sc = new Scanner(System.in);

	void init()
	{
		int recovery = 0;
		int type_po = 0;
		for ( int y = 0; y <  typeIdx ; y++ )
		{
			for ( int x = 0; x < itemIdx; x++)
			{
				if ( y == 아이템종류.포션.ordinal() ) 
				{
					recovery = 30 * (x % 2 + 1);
					type_po = (x+2) / 2 - 1;
				}
				itemArr[y*itemIdx+x] = new 아이템(strList[y][x], 아이템종류.values()[y] , type_po, recovery, y*itemIdx+x);
			}
		} 
	}
		
	public static String getInputString() {
		String str = "";
		try {
			str = sc.nextLine();
		} catch (InputMismatchException e) {
			System.out.println("문자를 입력해주세요");
		}
		return str;
	}

	public static int getInputInt() {
		int n = -1;
		try {
			n = sc.nextInt();
		} catch (InputMismatchException e) {
			System.out.println("숫자를 입력해주세요");
		}
		sc.nextLine();
		return n;
	}

	public static int getRandInt(int n) {
		return rand.nextInt(n);
	}
	
	
	public static int 랜덤아이템생성() {
		int n = getRandInt(listIdx);
		return n;
	}
	
	public static int 아이템수량생성(int iN)
	{
		int i = iN / itemIdx;
		int r = 5;
		if ( i == 아이템종류.장비.ordinal() ) r = 1;
		else if( i == 아이템종류.포션.ordinal() ) r = 3;
		
		int n = getRandInt(r) + 1;
		
		return n;
	}
	
	public static int getItemidx() {
		return itemIdx;
	}

	public static 아이템 get샘플아이템(int n)
	{
		return itemArr[n];
	}
	
	public static 아이템 get샘플아이템(String str)
	{
		int n = 0;
		for ( ; n < listIdx; n++)
			if ( str.equals(strList[n/itemIdx][n%itemIdx])) break;
		
		return itemArr[n];
	}
	
	
}