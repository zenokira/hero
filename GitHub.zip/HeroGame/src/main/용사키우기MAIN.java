package main;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import java.util.TreeSet;


public class 용사키우기MAIN {
	private 용사 player;
	private 마왕성 devil;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		용사키우기MAIN st = new 용사키우기MAIN();
		st.Start();
	}

	void Start() {
//		String name = Intro();
		String name = 시스템.getInputString();
		시스템.init();

		Initialize(name);

		System.out.println(player.getName() + "의 모험을 시작합니다.");
		System.out.println();
		System.out.println();

		player.get스탯().스탯창보기();

		while (true) {
			int choice = player.용사의선택();

			try {
				if (choice == 1)
					이벤트발생();
				else if (choice == 2)
					player.정비시간();
				else if (choice == 3)
					저장하기(player);
				else if (choice == 4)
					불러오기(player);
				else if (choice == 6)
					마왕성토벌();
				else if (choice == 5)
					수련(player);
				else if (choice == 999)
					player.getStatus().레벨업(100);
				else if (choice == 0)
					마을발견();
				else
					시스템.missChoice("\n");
			} catch (게임엔딩 e) {
				e.Ending용사의죽음(player);
			}

			if (devil.마왕죽음여부())
				Ending마왕의죽음(player);
			player.배고픔();
		}
	}

	void 저장하기(용사 player) {

		try {
			FileOutputStream fos = new FileOutputStream(new File(시스템.getPath() + player.getName()+".txt"));
			ObjectOutputStream oos = new ObjectOutputStream(fos);

			oos.writeObject(player.getName());
			oos.writeObject(player.getEquip());
			oos.writeObject(player.getSkill());
			oos.writeObject(player.getInv());
			oos.writeObject(player.get허기());
			oos.writeObject(player.get목마름());
			oos.writeObject(player.getStatus());

			oos.close();
			fos.close();
			System.out.println("성공적으로 저장을 마쳤습니다.");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	void 불러오기(용사 player) {
		System.out.print("불러올 용사의 이름을 입력해주세요 : ");
		try {
			String strName = 시스템.getInputString();
			String path = 시스템.getPath() + strName + ".txt";
			File file = new File(path);
			if(!file.exists()) 
			{
				System.out.println("해당 용사이름의 세이브파일이 존재하지않습니다.");
				return ;
			}
			FileInputStream fis = new FileInputStream(new File(path));
			ObjectInputStream ois = new ObjectInputStream(fis);

			player.setName((String) ois.readObject());
			player.setEquip((int[]) ois.readObject());
			player.setSkill((TreeSet<Integer>) ois.readObject());
			player.setInv((HashMap<Integer, Integer>) ois.readObject());
			player.set허기((int) ois.readObject());
			player.set목마름((int) ois.readObject());
			player.setStatus((스탯) ois.readObject());
			System.out.println("성공적으로 불러오기를 마쳤습니다.");
			player.스탯창보기();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	void 이벤트발생() throws 게임엔딩 {
		int event = 시스템.getRandInt(100) + 1;
		int total = 100;
		int var = total - 60 + player.get스탯().getLV();
		if (event > var && event <= total)
			몬스터발견();
		else if (event > 30 && event <= var)
			던전발견();
		else if (event > 20 && event <= 30)
			마을발견();
		else if (event > 0 && event <= 20)
			아이템발견();
	}

	private void 던전발견() throws 게임엔딩 {
		int t = 던전선택_1(player);
		if (t == -1 || t == 5)
			return;

		몬스터[] m = 던전몬스터발생(t);
		몬스터부대전투(player, m);
	}

	private void 마을발견() {
		시스템.직업종류 마을 = 랜덤마을생성();
		while (true) {
			int c = player.마을발견(시스템.직업종류.일반);

			if (c == 1) {
				if (마을 == 시스템.직업종류.일반) {
					마을에서휴식();
				} else {
					int n = 전직(마을);
					if (n == 1)
						player.전직(마을);
					else if (n == 2)
						System.out.println("전직을 포기하셨습니다.");
				}
				break;
			} else if (c == 2) {
				System.out.println("\n마을을 그냥 지나쳐다.\n");
				break;
			} else
				시스템.missChoice("\n");
		}
	}

	private void 마을에서휴식() {
		int r = 시스템.getRandInt(100);

		if (r % 10 == 5)
			player.온천에서회복한다();
		else
			player.마을에서회복한다();
	}

	private int 전직(시스템.직업종류 직업) {
		while (true) {
			int choice = player.마을발견(직업);

			if (choice == 3)
				시스템.missChoice();
			else if (choice == 1 || choice == 2)
				return choice;
		}
	}

	private 몬스터[] 던전몬스터발생(int 몬스터종류) {
		int r = 시스템.getRandInt(8) + 2;
		int 상세번호 = 시스템.getmtypeIdx();
		몬스터[] m = new 몬스터[r];
		for (int i = 0; i < r - 1; i++) {
			if (i % 상세번호 != 5)
				m[i] = new 몬스터(시스템.get샘플몬스터(몬스터종류 * 상세번호 + i % 상세번호));
			else
				m[i] = new 몬스터(시스템.get샘플몬스터(몬스터종류 * 상세번호 + 몬스터종류));
			m[i].몬스터생성();
		}
		m[r - 1] = new 몬스터(시스템.get샘플몬스터(몬스터종류 * 시스템.getMonIdx() + 시스템.getMonIdx() - 1));
		m[r - 1].던전보스몬스터생성();

		return m;
	}

	private void 용사일반공격(용사 p, 몬스터 m) {
		DMG dmg = p.공격();
		if (!p.is컨디션좋음()) {
			if (p.get허기() >= 80)
				System.out.print("허기 ");
			if (p.get목마름() >= 80)
				System.out.print("목마름 ");
			System.out.println("으로 인해 컨디션이 안좋습니다.");
			dmg.setDmg(dmg.getDmg() - dmg.getDmg() / 15);

		}
		System.out.println(p.getName() + " 이(가) 공격합니다");
		전투타격효과음(dmg.getDmgType());
		m.피격(dmg);
		System.out.println();
	}

	private boolean 용사스킬공격(용사 p, 몬스터 m) {

		int i = p.용사의스킬선택();
		if (i == -1)
			return false;
		스킬 skill = 시스템.get샘플스킬(i);
		System.out.println(p.getName() + " 이(가) " + skill.get스킬이름() + " 을(를) 사용합니다.");
		DMG dmg = p.스킬공격(skill);
		if (!p.is컨디션좋음())
			dmg.setDmg(dmg.getDmg() - dmg.getDmg() / 15);
		m.스킬피격(dmg);
		System.out.println();
		return true;
	}

	private void 몬스터턴(용사 p, 몬스터 m) {
		DMG dmg = m.공격();
		System.out.println(m.getName() + " 이(가) 공격합니다");
		p.피격(dmg);
		System.out.println();
	}

	private void 아이템발견() {
		int id = 시스템.랜덤아이템생성(player);

		아이템 item = new 아이템(시스템.get샘플아이템(id));
		int n = 시스템.아이템수량생성(item.getIType());

		while (true) {
			int c = player.아이템발견(item, n);
			if (c == 1) {
				player.아이템획득(id, n);
				break;
			} else if (c == 2) {
				System.out.println("아이템 획득을 포기했다.\n");
				break;
			} else
				시스템.missChoice();
		}
	}

	private void 몬스터발견() throws 게임엔딩 {
		int lv = player.getStatus().getLV() / 10;
		if (lv > 5)
			lv = 5;
		int type = lv; // 시스템.get랜덤몬스터종류();
		int src = 시스템.get랜덤몬스터();

		몬스터 mon = new 몬스터(시스템.get샘플몬스터(type * 시스템.getMonIdx() + src));
		mon.몬스터생성();

		while (true) {
			int c = player.몬스터발견(mon);

			if (c == 1) {
				전투하기_1(player, mon);
				break;
			} else if (c == 0) {
				System.out.println("성공적으로 도망쳤습니다.");
				break;
			} else
				시스템.missChoice();
		}
	}

	private void 마왕성토벌() throws 게임엔딩 {
		if (던전선택_1(player, true) == -1)
			return;
		마왕성전투시작(player, devil);
	}

	private void 마왕성전투시작(용사 p, 마왕성 devil) throws 게임엔딩 {
		int cnt = 0;
		while (true) {

			if (cnt == 0)
				System.out.println("마왕성의 문을 열고 들어갔다.\n");
			else if (cnt == 1)
				System.out.println("마왕성을 오르기 시작했다.\n");
			else if (cnt == 2) {
				System.out.println("마왕성을 오르기 시작했다.\n");
				sleep(1500);
				System.out.println("마왕의 방 입구의 문을 열었다.\n");
				sleep(1500);
				System.out.println("마왕이 등장했다.\n");
			}
			sleep(1500);

			마왕성전투(player, devil.get몬스터부대(cnt));
			if (devil.마왕죽음여부())
				break;
			cnt++;
		}
	}

	private void 부대전투하기(용사 p, 몬스터[] m) throws 게임엔딩 {
		for (몬스터 mon : m) {
			mon.스탯창보기();
			전투하기_2(p, mon);
			if (p.is용사죽음())
				throw new 게임엔딩();
		}
	}

	private void 몬스터부대전투(용사 p, 몬스터[] m) throws 게임엔딩 {
		부대전투하기(p, m);
	}

	private void 마왕성전투(용사 p, 몬스터[] m) throws 게임엔딩 {
		부대전투하기(p, m);
		if (m[0].is보스몬스터죽음())
			return;
		player.마왕성중간휴식();
	}

	void Initialize(String name) {
		player = new 용사(name);
		devil = 시스템.get마왕성();
	}

	public 시스템.직업종류 랜덤마을생성() {

		int rand = 시스템.getRandInt(100) + 1;

		if (rand > 30) 
			return 시스템.직업종류.일반;
		else if (rand > 15)  
			return 시스템.직업종류.검사;
		else
			return 시스템.직업종류.마법사;
	}

	boolean is공격가능상태(시스템.상태이상종류 상태이상) {
		switch (상태이상) {
		default:
			return true;
		case 기절:
			return false;
		case 마비:
			int rand = 시스템.getRandInt(100) + 1;
			return rand % 2 == 0;
		}
	}

	String Intro() {
		스토리String("마왕군과 대치중이던 용사가 단말마의 비명을 질렀다");
		스토리String("그와 함께 마왕 한마디 말을 내뱉으며 쓰러졌다");
		스토리String("마왕 : I will be back");
		스토리String("마왕이 쓰러지자 마왕군은 후퇴했고");
		스토리String("다시금 평화를 되찾았다");
		스토리String("평화롭게 지내는 500년의 시간이 흐르자 용사는 잊혀져갔다");
		스토리String("평화가 찾아오고 생산력이 복구되자 지배층의 욕심은 다시 생겨났다");
		스토리String("그로인해 다시금 전쟁이 시작되었다");
		스토리String("전쟁은 150년간 지속되었고");
		스토리String("인구는 마왕군과 전쟁했던 시대만큼 줄어버렸다");
		스토리String("심지어 마왕의 부활 필요한 대량의 피가 대지를 적셨고");
		스토리String("마왕의 부활이 임박해졌다");
		System.out.println("\n--------------------------\n");

		스토리String("용사가 마왕을 물리친지 666년이 지났다");
		스토리String("그동안의 거듭된 인간들의 전쟁으로 피가 필요했던 마왕은 결국 부활했고");
		스토리String("인간들은 전쟁을 멈추고 마왕군과 대적했다");
		스토리String("하지만 너무 많은 사람들이 전쟁으로 죽어버렸고");
		스토리String("마왕군과의 전투에서 항상 선두에서 싸우던 용사조차 이제는 없었다");
		스토리String("불리한 싸움을 거듭하던 그때 수도에 있던 성녀가 신탁을 받았다");
		스토리String("'지난번 마왕과 대적했던 용사 역시도 다시 태어났고");
		스토리String("다시금 그의 각성이 이루어져 인간들을 구원하리라' 라고");
		System.out.println("\n--------------------------\n");

		스토리String("신탁이 있은 후로부터 2년이 지났다.");
		스토리String("사람들은 신탁의 용사가 나타나기를 손꼽아 기다렸다");
		스토리String("이미 포기한 자들도 생겨났다");
		스토리String("성녀를 욕하는 자들 역시 날이 갈수록 늘어만 갔다");
		스토리String("절망의 나날이 흐르던 그때 다시금 성녀에게 신탁이 내려왔다");
		스토리String("'용사는 이미 각성하였고, 스스로 성장해나가고 있다' 라고");
		System.out.println("\n--------------------------\n");

		스토리String("어느 산골짜기 마을에 오크무리가 지나갔다");
		스토리String("마을의 모든 것이 부서져버렸으나 어린 생존자가 한명 있었다");
		스토리String("마을의 유일한 생존자인 당신에게");
		스토리String("하늘에서 강렬한 빛을 뿜는 존재가 내려와 말을 걸었다");

		System.out.println("당신의 이름은 무엇인가요? ");

		return 시스템.getInputString();
	}

	void sleep(int m) {
		try {
			Thread.sleep(m);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	void 스토리String(String str) {
		System.out.println("-" + str + "-");
		sleep(2000);
	}

	private void 전투하기_1(용사 p, 몬스터 m) throws 게임엔딩 {
		전투하기(p, m, true);
	}

	private void 전투하기_2(용사 p, 몬스터 m) throws 게임엔딩 {
		전투하기(p, m, false);
	}

	private void 전투하기(용사 p, 몬스터 m, boolean run) throws 게임엔딩 {
		boolean isRun = run;
		boolean isNoSkill = false;
		while (true) {
			if (isNoSkill) {
				if (생사결(p, m))
					continue;
				else
					break;
			}
			int menucount = 1;
			System.out.print("선택해주세요 ( ");
			System.out.print(menucount + ". 공격  ");
			++menucount;
			System.out.print(menucount + ". 스킬  ");
			++menucount;
			System.out.print(menucount + ". 아이템 사용하기  ");
			++menucount;
			System.out.print(menucount + ". 생사결  ");
			++menucount;

			if (isRun) {
				System.out.print("0. 도망");
			}
			System.out.println(" )");

			int choice = 시스템.getInputInt();
			System.out.println();
			if (choice == 0) {
				if (!isRun) {
					시스템.missChoice();
					continue;
				}
				System.out.println("성공적으로 도망쳤습니다.");
				break;
			}
			if (choice < 0 || choice > 4) {
				시스템.missChoice();
				continue;
			}

			if (p.is공격가능상태()) {
				if (choice == 1) {
					용사일반공격(p, m);
				} else if (choice == 2) {
					if (!용사스킬공격(p, m))
						continue;
				} else if (choice == 3) {
					p.아이템사용하기();
				} else if (choice == 4) {
					isNoSkill = true;
					continue;
				}

				if (m.is몬스터죽음()) {
					p.몬스터처치(m);
					break;
				}
			}
			sleep(1000);
			if (m.is공격가능상태()) {
				몬스터턴(p, m);
				if (p.is용사죽음())
					throw new 게임엔딩();
			}
			System.out.println();
			sleep(1000);
		}
	}

	boolean 생사결(용사 p, 몬스터 m) throws 게임엔딩 {
		if (p.is공격가능상태()) {
			용사일반공격(p, m);
			if (m.is몬스터죽음()) {
				p.몬스터처치(m);
				return false;
			}
		}
		sleep(500);

		if (m.is공격가능상태()) {
			몬스터턴(p, m);
			if (p.is용사죽음())
				throw new 게임엔딩();
		}
		sleep(500);
		return true;
	}

	int 던전선택_1(용사 p) {
		return 던전선택(p, false);
	}

	int 던전선택_1(용사 p, boolean is마왕성) {
		return 던전선택(p, is마왕성);
	}

	int 던전선택(용사 p, boolean is마왕성) {
		int lv = p.getStatus().getLV() / 10;
		int t = 0;
		if (lv > 4) {
			lv = 4;
			t = lv;
		} else
			t = 시스템.getRandInt(lv + 1);
		int idx = 시스템.getmtypeIdx();

		while (true) {
			if (is마왕성) {
				System.out.println("마왕성을 발견했다.\n");
				System.out.println("*주의* 입장시 포기 할 수 없습니다. (권장레벨 : 70 이상 )\n");
				t = 5;
			} else {
				System.out.println(시스템.get샘플몬스터(t * idx).getName() + "던전(난이도 : " + (t + 1) + " )을 발견했다.\n");
				System.out.println("*주의* 입장시 포기 할 수 없습니다. (권장레벨 : " + ((t + 1) * 10) + " )");
			}

			int choice = player.용사의던전선택();

			if (choice == 1)
				return t;
			else if (choice == 2)
				player.스탯창보기();
			else if (choice == 3) {
				if (t != 5)
					System.out.println("던전입장을 포기하셨습니다.\n");
				else if (t == 5)
					System.out.println("마왕성도전을 포기하셨습니다.\n");
				return -1;
			} else
				시스템.missChoice("\n");

		}
	}

	private void Ending마왕의죽음(용사 player) {

		시스템.직업종류 job = player.get스탯().getJob();

		if (job == 시스템.직업종류.일반)
			엔딩스토리_일반(player);
		else if (job == 시스템.직업종류.검사)
			엔딩스토리_검사(player);
		else if (job == 시스템.직업종류.마법사)
			엔딩스토리_마법사(player);
		else if (job == 시스템.직업종류.마검사)
			엔딩스토리_마검사(player);

		스토리String("----------< The End >----------");
		System.exit(0);
	}

	void 엔딩스토리_일반(용사 player) {
		스토리String("단순한 완력으로 마왕의 뿔을 부러뜨려버렸다");
		스토리String("단단해 보이던 한쪽팔도 뜯겨나갔고");
		스토리String("위용을 자랑하던 날개는 이미 처참하게 찢어졌다.");

		엔딩스토리(player);

		스토리String("산골짜기에서 나타난 용사 ( " + player.getName() + " ) 는 그렇게 허무하게 죽음을 맞이했다");
	}

	void 엔딩스토리_검사(용사 player) {
		스토리String("마왕의 몸에 수십개의 자상이 보이고");
		스토리String("한쪽 뿔은 잘려나가 반만 남았다");
		스토리String("기다란 롱소드는 마왕의 심장을 꿰뚫었고 결국");

		엔딩스토리(player);

		스토리String("왕의 외침을 들은 " + player.getName() + " (은)는 조용히 마나로 신체를 강화했다");
		스토리String("단숨에 온몸에 마나를 순환시키자 다시 한번 피를 토했다");
		스토리String("몸안에 있던 죽은 피와 독을 뱉아내고서 순식간에 왕의 앞으로 이동했다");
		스토리String("피를 토하던 용사가 눈앞으로 오자 왕은 뒷걸음질쳤고");
		스토리String(player.getName() + " 은(는) 그대로 롱소드에 오러를 감아 왕을 베었다");
		스토리String("마왕처럼 강인한 육체도 썰어버린 그 오러를 왕이 막아낼 순 없었고");
		스토리String("왕은 순식간에 2조각의 육체를 가지게 되었다");
		스토리String("이를 본 주변의 기사들이 전부 달려들었지만 순식간에 정리가 되었고");
		스토리String(player.getName() + " 은(는) 연회장을 뒤로 한 채 고향마을로 돌아갔다");
	}

	void 엔딩스토리_마법사(용사 player) {
		스토리String("수십번의 마법을 쏟아붇자 마왕이 무릎을 꿇었다");
		스토리String("용사의 마력도 다 떨어졌지만 결국");

		엔딩스토리(player);

		스토리String("왕의 외침을 들은 " + player.getName() + " (은)는 조용히 외쳤다");
		스토리String("큐어포이즌...");
		스토리String("순식간에 마법으로 해독 해버린 " + player.getName() + " 은(는) 서서히 일어났다");
		스토리String("그 모습을 본 왕이 기겁하며 도망치려하자 ");
		스토리String(player.getName() + " 은(는) 라이트닝 스피어를 왕에게 던졌다");
		스토리String("라이트닝 스피어에 직격당한 왕은 그자리에 새까맣게 타버렸다");
		스토리String("왕이 숯덩이가 되는 모습을 끝까지 지켜본 " + player.getName() + " 은(는) 자리에서 벗어났다");
		스토리String("용사는 그 길로 고향마을로 돌아가 조용히 삶을 보냈다");
	}

	void 엔딩스토리_마검사(용사 player) {
		스토리String("한손엔 롱소드를, 다른 한손엔 캐스팅된 마법을 사용하며 마왕과 싸웠다.");
		스토리String("마왕의 몸엔 롱소드로 만들어진 자상과");
		스토리String("파이어볼과 같이 마법에 당한 상처들이 보인다");
		스토리String("마왕의 상처들은 더는 회복 되지않았다.");

		엔딩스토리(player);

		스토리String("왕의 외침을 들은 " + player.getName() + " (은)는 조용히 외쳤다");
		스토리String("큐어포이즌...");
		스토리String("순식간에 마법으로 해독 해버린 " + player.getName() + " 은(는) 서서히 일어났다");
		스토리String("그 모습을 본 왕이 기겁하며 도망치려하자 ");
		스토리String(player.getName() + " 은(는) 한손엔 롱소드를, 한손엔 라이트닝 스피어를 쥐고 왕을 쫒아갔다");
		스토리String("단숨에 왕을 베어버리고 뒤따라 오던 기사들을 모조리 태워버리고는 고향마을로 돌아갔다");
	}

	void 엔딩스토리(용사 player) {
		스토리String(player.getName() + " 이(가) 마왕을 쓰러뜨렸다");
		스토리String(player.getName() + " 은(는) 지친 몸을 이끌고 왕국으로 돌아왔고");
		스토리String("대륙은 축제의 분위기에 휩싸였다");
		스토리String("하지만 왕은 자신보다 인기가 많아진 " + player.getName() + " 이(가) 마음에 들지않았다");
		스토리String("그래서 " + player.getName() + " 을(를) 위한 연회에서 용사의 술잔에 독을 탔다");
		스토리String("아직 마왕과의 전투에서 입은 부상들이 회복되지않은 상태에서");
		스토리String("극독을 마신 " + player.getName() + " 은(는) 피를 토하며 쓰러졌고");
		스토리String("왕이 소리쳤다");
		스토리String("마왕을 이긴 " + player.getName() + " 도 독 앞에선 별 수 없구나!!");
	}

	public void 수련(용사 player) {
		// TODO Auto-generated method stub
		System.out.println("----------------------------------------");
		System.out.println("목각인형으로 수련을 한다.");
		System.out.println("          #tip#       ");
		System.out.println("(숨겨진 급소를 정확히 때리면 보너스)");
		System.out.println("(보너스 위치는 매번 달라진다.)");
		System.out.println("----------------------------------------");
		System.out.println();

		while (true) {
			스탯 s = player.get스탯();
			if (s.getLV() >= 5)
				수련_효과없음();
			int exp = 수련_미니게임(player);

			if (exp == -1)
				return;
			else if (exp == 0)
				continue;

			player.get스탯().changeEXP(exp);
			System.out.printf("경험치가 %d 올랐다.\n\n", exp);

			if (s.is레벨업()) {
				s.레벨업();
				player.용사스탯창보기();
				System.out.println();
			}
		}
	}

	int 수련_미니게임_타격(int lv, boolean b) {
		int exp = 0;

		if (b)
			exp = 150;
		else
			exp = 50;

		if (lv >= 5)
			exp = 10;

		return exp;
	}

	void 수련_효과없음() {
		System.out.println("--------------------------------------");
		System.out.println("멈춰있는 상대를 정확하게 때릴 수 있게 되었습니다.");
		System.out.println("더이상 혼자 수련해도 효과가 미비합니다.");
		System.out.println("모험을 떠나는 것을 추천드립니다.");
		System.out.println("--------------------------------------");
		System.out.println();
		System.out.println();
	}

	int 수련_미니게임(용사 player) {

		int exp = 0;
		int r = 시스템.getRandInt(3) + 1;
		System.out.println("어디를 때릴까요? ( 1. 머리  2. 몸통  3. 어깨  4. 수련중단 ) : ");
		int c = 시스템.getInputInt();

		if (c < 0 || c > 4) {
			시스템.missChoice("\n");
			return 0;
		}

		if (c == 4)
			return -1;
		int 헛스윙 = 시스템.getRandInt(10) + 1;

		if (헛스윙 == 5) {
			int n = 시스템.getRandInt(3);
			if (n == 0)
				System.out.println("제대로 힘을 싣지 못했다");
			else if (n == 1)
				System.out.println("타점이 어긋났다");
			else if (n == 2) {
				System.out.println("스텝이 꼬여 넘어졌다");
				return 0;
			}
			exp = 10;
		}
		int lv = player.get스탯().getLV();
		if (r == c) {
			exp = 수련_미니게임_타격(lv, true);
			수련_목각인형타격음();
			System.out.println("!!!!!정확한 급소를 가격했다!!!!!");
		} else {
			exp = 수련_미니게임_타격(lv, false);
			수련_목각인형타격음();
			System.out.println("급소가 아닌 곳을 때렸다");
		}
		return exp;
	}

	void 수련_목각인형타격음() {
		int r = 시스템.getRandInt(5);

		if (r == 0)
			시스템.효과음("빠각");
		else if (r == 1)
			시스템.효과음("딱");
		else if (r == 2)
			시스템.효과음("으직");
		else if (r == 3)
			시스템.효과음("푸욱");
		else if (r == 4)
			시스템.효과음("까각");
	}

	void 전투타격효과음(시스템.데미지타입 type) {

		int rand = 시스템.getRandInt(5);
		if (type == 시스템.데미지타입.물리) {
			if (rand == 0)
				시스템.효과음("서걱");
			else if (rand == 1)
				시스템.효과음("빠각");
			else if (rand == 2)
				시스템.효과음("까드득");
			else if (rand == 3)
				시스템.효과음("으득");
			else if (rand == 4)
				시스템.효과음("푹");
		} else {
			if (rand == 0)
				시스템.효과음("피융");
			else if (rand == 1)
				시스템.효과음("화르륵");
			else if (rand == 2)
				시스템.효과음("찌리리릿");
			else if (rand == 3)
				시스템.효과음("콰드득");
			else if (rand == 4)
				시스템.효과음("푹");
		}
	}

}