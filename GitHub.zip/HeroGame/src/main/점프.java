package main;

public class 점프 extends Exception {
	private int 전투중; // 0 전투x  1 한마리  2 던전  3 마왕성
	private 몬스터[][] mon;
	
	점프()
	{
		
	}
	점프(몬스터[][] _mon, int _전투중)
	{
		setMon(_mon);
		set전투중(_전투중);
	}
	public int get전투중() {
		return 전투중;
	}
	public void set전투중(int 전투중) {
		this.전투중 = 전투중;
	}
	public 몬스터[][] getMon() {
		return mon;
	}
	public void setMon(몬스터[][] mon) {
		this.mon = mon;
	}
}
