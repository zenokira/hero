package main;

interface 직업 {
	
}
