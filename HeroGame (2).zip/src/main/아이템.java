package main;

public class 아이템 {
	private String name;
	private String type;
	private int count;
	private int HP;
	private int MP;
	
	public 아이템()
	{
		
	}
	public 아이템(String n, String type, int count)
	{
		this.name = n;
		this.type = type; 
		this.count = count;
	}
	
	public void Init아이템(String n, String type, int count)
	{
		this.name = n;
		this.type = type; 
		this.count = count;
	}
	
	public 아이템 getItem()
	{
		return this;
	}
	
	public String getName() {
		return this.name;
	}
	
	public void setName(String str) {
		this.name = str;
	}
	
	public int getCount() {
		return this.count;
	}
	public void setCount(int c) {
		this.count = c;
	}
	
	public void changeCount(int c) {
		this.count += c;
	}
	
	public void 아이템수량변경(int c)
	{
		this.count += c;
	}
	
	public boolean 소비아이템여부(String n)
	{
		if( name.contains(n))	return true;
		else					return false;
	}
	
	public void 아이템정보보이기() {
		System.out.println("\n아이템 이름 : " + name + "\t\t보유수량 : " + count );
	}
	
	public void 포션값세팅() {
		setHP(30); setMP(30);
	}

	
	@Override
	public String toString()
	{
		return this.name;
	}
	public int getMP() {
		return MP;
	}
	public void setMP(int mP) {
		MP = mP;
	}
	public int getHP() {
		return HP;
	}
	public void setHP(int hP) {
		HP = hP;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}

}