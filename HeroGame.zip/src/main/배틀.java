package main;

public class 배틀 {
	private 용사 hero;
	private 몬스터 mon;

	public 배틀(용사 hero, 몬스터 mon) {
		this.hero = hero;
		this.mon = mon;

	}

	public void 배틀시작() {

		while (true) {
			System.out.println("선택해주세요 ( 1. 공격 , 2. 도망 ) : ");
			int choice = 시스템.getInputInt();

			switch (choice) {
			case 1:
				공격턴();
				if ( mon.getHP() <= 0 ) {
					System.out.println(mon.getName() + " 을(를) 쓰러뜨렸습니다. \n<배틀종료>");
					return;
				}
				수비턴();
				break;
			case 2:
				break;
			}

		}

	}

	void 공격턴() {
		int dmg = hero.get상태창().get물리공격력() - mon.get물리방어력();

		if (dmg > mon.getHP() )
		{
			dmg = mon.getHP();
		}
		
		int hp = mon.getHP() - dmg;
		
		if (dmg > 0) {
			System.out.println(mon.getName() + "에게 " + dmg + "의 공격을 가했다. ");
			mon.setHP(hp);
			System.out.printf("%s ( %d / %d ) \n", mon.getName(), mon.getHP(), mon.getMaxHP());
		}
		else
		{
			
		}
	}

	void 수비턴() {
		int dmg = mon.get물리공격력() - hero.get상태창().get물리방어력();
		int hp = hero.get상태창().getHP() - dmg;

		if (dmg > 0) {
			System.out.println(hero.getName() + "는 " + dmg + "의 공격을 당했다. ");
			hero.get상태창().setHP(hp);
			System.out.printf("%s ( %d / %d ) \n", hero.getName(), hero.get상태창().getHP(), hero.get상태창().getMaxHP());
		} else {
			System.out.println(hero.getName() + "는 0의 공격을 당했다. ");
			System.out.printf("%s ( %d / %d ) \n", hero.getName(), hero.get상태창().getHP(), hero.get상태창().getMaxHP());
		}
	}

}
